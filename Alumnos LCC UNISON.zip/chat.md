# WhatsApp Chat Export: Alumnos LCC UNISON
Export date: September 24, 2026 at 3:33 PM

---

## July 7, 2026

[5:13 PM] __Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to learn more.__

---

## August 31, 2026

[1:25 PM] **+52 1 662 467 9029:** [Image] 🗣️🗣️🗣️🗣🗣🗣🗣🗣

🔴 Ya están los emparejamientos del torneo de Futbol 🗣

🔵 En el primer partido tendremos a los profes goleando a los de primero (o no)

🟢 En el tercero me veran a mi descalificando al Rodrigo y confinandolo a su puesto de árbitro.

🟡 Y en el cuarto partido los Legits van con los contendientes a la copa (segun ellos)

🟣 A las 5:00 en la cancha de psicología

Bracket:
https://challonge.com/es/k9wpsu13

Ubicación:
https://maps.app.goo.gl/iKJMhA8W1f2XRPak9

[1:27 PM] **+52 1 662 508 9779:** [GIF]

[1:29 PM] **+52 1 687 120 1981:** Ya están las apuestas en Caliente ?

[1:30 PM] **+52 1 662 467 9029:** Yaya

[1:37 PM] **+52 1 662 102 6188:** Quien se robo los chilaquiles

[1:43 PM] **+52 1 662 361 4760:**
> _+52 1 662 467 9029: Image: 🗣️🗣️🗣️🗣🗣🗣🗣🗣

🔴 Ya están los emparejamientos del torneo de Futbol 🗣

🔵 En el primer partido tendremos a los profes goleando a los de primero (o no)

🟢 En el tercero me veran a mi descalificando al Rodrigo y confinandolo a su puesto de árbitro.

🟡 Y en el cuarto partido los Legits van con los contendientes a la copa (segun ellos)

🟣 A las 5:00 en la cancha de psicología

Bracket:
https://challonge.com/es/k9wpsu13

Ubicación:
https://maps.app.goo.gl/iKJMhA8W1f2XRPak9_
Vodka juniors va a dar la sorpresa ojo con Vodka juniors siempre decia mi tata

[1:46 PM] **+52 1 662 369 5386:** 9/12

[1:52 PM] **+52 1 633 335 6651:** Se robaron unos chilaquiles

[1:52 PM] **+52 1 633 335 6651:** [Sticker]

[2:00 PM] **+52 1 662 340 5659:**
> _+52 1 633 335 6651: Se robaron unos chilaquiles_
ta dura la delincuencia

[2:05 PM] **+52 1 662 397 6279:**
> _+52 1 633 335 6651: Se robaron unos chilaquiles_
Se me hace una falta de respeto

[2:05 PM] **+52 1 662 397 6279:** [Sticker]

[2:18 PM] **+52 1 662 467 9029:** [Image] @⚽️futbol

Hola, para los que preguntan acerca de la lluvia. Tenemos la esperanza de que el pronóstico se cumpla y a las 5:00 termine la lluvia, y justo entonces empezaremos el partido.

Se cual sea el caso se improvisará. Pero por el momento no se cancelará el torneo.

[2:19 PM] **+52 1 662 340 5659:**
> _+52 1 662 467 9029: Image: @⚽️futbol

Hola, para los que preguntan acerca de la lluvia. Tenemos la esperanza de que el pronóstico se cumpla y a las 5:00 termine la lluvia, y justo entonces empezaremos el partido.

Se cual sea el caso se improvisará. Pero por el momento no se cancelará el torneo._
amén

[2:20 PM] **+52 1 631 125 1255:**
> _+52 1 633 335 6651: Se robaron unos chilaquiles_
en donde compañera?

[2:21 PM] **+52 1 662 467 9029:** A las 3:00 ire a ver la cancha y les dare otro aviso

[2:21 PM] **+52 1 662 177 6547:**
> _+52 1 633 335 6651: Se robaron unos chilaquiles_
perdon, no desayune :’(

[2:41 PM] **Carlos Mancillas:** Saben si sonia se encuentra en lcc ?

[2:48 PM] **+52 1 662 342 4670:**
> _Carlos Mancillas: Saben si sonia se encuentra en lcc ?_
Sí está caliyaaaa

[2:48 PM] **+52 1 662 397 6279:**
> _+52 1 631 125 1255: en donde compañera?_
En el centro de cómputo compañero, mientras hacían la búsqueda de tesoro

[2:48 PM] **+52 1 662 397 6279:** [Sticker]

[2:51 PM] **+52 1 662 206 2716:**
> _+52 1 662 397 6279: En el centro de cómputo compañero, mientras hacían la búsqueda de tesoro_
Capaz pensaron que el tesoro eran los chilaquiles

[2:53 PM] **+52 1 633 335 6651:**
> _+52 1 631 125 1255: en donde compañera?_
En el centro de computo compañero

[3:00 PM] **+52 1 662 450 9504:** Oigan no saben cuando abrirán el cc?

[3:01 PM] **+52 1 667 973 4142:** _This message was deleted_

[3:01 PM] **+52 1 662 450 9504:** Si lo leí we xd

[3:01 PM] **+52 1 667 973 4142:** XD

[3:01 PM] **+52 1 667 973 4142:** no se, segun iban a planear algo

[3:02 PM] **+52 1 662 268 7744:** hola

[3:02 PM] **+52 1 662 268 7744:** ya entregamos la carta

[3:02 PM] **+52 1 662 268 7744:** es solo esperar

[3:02 PM] **+52 1 662 268 7744:** a que lo abran

[3:02 PM] **+52 1 662 450 9504:** Chanfle

[3:04 PM] **+52 1 631 125 1255:** hasta el otro mes lo más probable

[3:05 PM] **+52 1 631 125 1255:** tiene que revisarla coordinacion, autorizarla, mandarla a coordinacion del departamento, autorizarla, mandarla a coordinacion de la division, aprobarla y a rectoria y aprobarla

[3:10 PM] **+52 1 631 125 1255:** que te causa risa compañera @~lu? es un tema de bastante seriedad el proceso que la universidad de sonora emplea, asi como la seriedad para atender este tipo de asuntos relacionados con su alumnado

[3:10 PM] **+52 1 631 125 1255:** jaja ni d pedo, a unison le valemos verga nomes le importa la feria

[3:11 PM] **+52 1 631 125 1255:** lo ve sonia y ella decide cuando nos da luz verde

[3:11 PM] **+52 1 631 125 1255:** [Sticker]

[3:13 PM] **+52 1 662 412 0821:**
> _+52 1 631 125 1255: lo ve sonia y ella decide cuando nos da luz verde_
Por eso, el mes que viene

[3:14 PM] **+52 1 631 125 1255:** no les mates las ilusiones w

[3:14 PM] **+52 1 631 125 1255:** [Sticker]

[3:37 PM] **+52 1 662 450 9504:** [Sticker]

[3:41 PM] **+52 1 662 848 3108:** [Sticker]

[3:46 PM] **+52 1 662 467 9029:** Hola, si están en el torneo se futbol porfavor metanse aquí:

https://chat.whatsapp.com/JVMihVcikYb4hy0SI485X0

[3:46 PM] **+52 1 662 467 9029:** Ahi comunicaremls qp con la lluvia y los turnos

[3:46 PM] **+52 1 633 335 6651:** _This message was deleted_

[3:46 PM] **+52 1 662 467 9029:** Es posible que Vodka Juniors y Los Cimalones jueguen antes

[3:52 PM] **+52 1 662 245 0227:** ¿si se va a hacer o nel?

[3:58 PM] **+52 1 55 5473 2571:**
> _+52 1 662 245 0227: ¿si se va a hacer o nel?_
si se va hacer

[4:13 PM] **+52 1 662 340 5659:**
> _+52 1 662 467 9029: Es posible que Vodka Juniors y Los Cimalones jueguen antes_
pq

[5:03 PM] **+52 1 662 342 4670:** [Video]

[5:07 PM] **+52 1 662 342 4670:** [Video]

[5:10 PM] __+52 1 662 138 8894 joined via invite link__

[5:43 PM] **+52 1 662 342 4670:** [Video]

[5:44 PM] **+52 1 662 245 0227:** [album message]

[5:44 PM] **+52 1 662 245 0227:** [Image]

[5:44 PM] **+52 1 662 245 0227:** [Image]

[5:44 PM] **+52 1 662 245 0227:** farmeando aura

[5:45 PM] **+52 1 662 476 3432:**
> _+52 1 662 245 0227: [album]_
Confiara con mi alma a ese portero

[5:45 PM] **+52 1 662 326 0064:** esta jugando mientras se fuma un cigarro?

[5:45 PM] **+52 1 662 326 0064:** que perro

[5:46 PM] **+52 1 662 360 3569:** [Sticker]

[5:47 PM] **+52 1 662 335 9011:** [Sticker]

[5:48 PM] **+52 1 662 245 0227:** no farmea aura, derrocha aura

[5:49 PM] **+52 1 662 426 8411:** El aura le persigue

[5:50 PM] **+52 1 662 326 0064:** y si hubo torneo de aura entonces?

[5:51 PM] **+52 1 662 326 0064:** porque si si}, todos ustedes estan fritos contra Eduardo

[5:53 PM] **+52 1 662 290 0527:**
> _+52 1 662 245 0227: [album]_
Ya lo fichó el real madrid por 3 cajetillas de cigarros

[6:22 PM] **+52 1 662 102 9392:** Como reporto si me esta afectando un clase para algun torneo?

[6:22 PM] **+52 1 662 102 9392:** Porque ya van 2 maestros que les pregunto y ni estaban enterados y van a dar su clase con normalidad

[6:28 PM] **+52 1 662 467 9029:**
> _+52 1 662 102 9392: Porque ya van 2 maestros que les pregunto y ni estaban enterados y van a dar su clase con normalidad_
Hola, se nos pasó enviar algunos de los correos, mil disculpas. Mañana iremos a hablar con esos profes. Me puedes pasar las clases, la hora y los nombres porfavor?

[6:33 PM] **+52 1 662 102 9392:**
> _+52 1 662 467 9029: Hola, se nos pasó enviar algunos de los correos, mil disculpas. Mañana iremos a hablar con esos profes. Me puedes pasar las clases, la hora y los nombres porfavor?_
Si ahi te los mando

[6:45 PM] **+52 1 662 307 4979:** Una pregunta

[6:46 PM] **+52 1 662 307 4979:** Si alguien me quebró el espejo lateral en el estacionamiento, no sé quién es pero sé cuál carro es

[6:46 PM] **+52 1 662 307 4979:** Hay algo que se pueda hacer al respecto?

[6:54 PM] **+52 1 633 335 6651:** Puedes hablar con los de seguridad

[6:54 PM] **+52 1 633 335 6651:** Ellos te pueden asesorar

[6:54 PM] **+52 1 631 125 1255:** reportar el carro y placas a seguridad

[7:09 PM] **+52 1 662 307 4979:** Muchas gracias🙏🏻

[8:37 PM] **+52 1 662 245 0227:** [album message]

[8:37 PM] **+52 1 662 245 0227:** [Image]

[8:37 PM] **+52 1 662 245 0227:** [Image]

[8:37 PM] **+52 1 662 245 0227:** [Image]

[8:37 PM] **+52 1 662 245 0227:** ánimo

[8:38 PM] **+52 1 662 245 0227:** [Sticker]

[8:38 PM] **+52 1 662 342 4670:**
> _+52 1 662 245 0227: [album]_
Puro papoi ahí

[8:38 PM] **+52 1 662 342 4670:** [Sticker]

[8:39 PM] **+52 1 662 467 9029:** Muchas gracias a todos los que estuvieron en el torneo

[8:39 PM] **+52 1 662 467 9029:** Espero que les gustará :]

[8:40 PM] **+52 1 662 467 9029:** Y felicidades a los winers

[8:40 PM] **+52 1 662 637 5722:** pero digan quién ganó

[8:40 PM] **+52 1 662 637 5722:** 👀

[8:40 PM] **+52 1 662 467 9029:** Aaa voy

[8:40 PM] **+52 1 662 245 0227:** _This message was deleted by admin +52 1 662 449 3477_

[8:41 PM] **+52 1 662 367 8720:**
> _+52 1 662 637 5722: pero digan quién ganó_
vayan a la premiacion del viernes

[8:41 PM] **+52 1 662 367 8720:** [Sticker]

[8:41 PM] **+52 1 662 449 3477:**
> _+52 1 662 637 5722: pero digan quién ganó_
el viernes sabrán!!!

[8:41 PM] **+52 1 662 449 3477:** [Sticker]

[8:41 PM] **+52 1 662 637 5722:** ya lo leí

[8:41 PM] **+52 1 662 637 5722:** [Sticker]

[8:42 PM] **+52 1 662 467 9029:** Igual si buscan el bracket que mandé ahí sale

[8:42 PM] **+52 1 662 350 5885:**
> _+52 1 662 245 0227: [album]_
ESOOOOOOOOOO EDEL GANADOR

[8:42 PM] **+52 1 662 467 9029:** Pero si, el viernes se premia

[8:42 PM] **+52 1 662 350 5885:** ALABIO ALABAO ALABIMBOMBAN EDEL EDEL RA RA RA

[8:42 PM] **+52 1 662 245 0227:**
> _+52 1 662 350 5885: ESOOOOOOOOOO EDEL GANADOR_
ya te la sabes

[8:42 PM] **+52 1 662 350 5885:** [Sticker]

[8:42 PM] **+52 1 662 350 5885:** [Sticker]

[8:42 PM] **+52 1 662 245 0227:** [Sticker]

[8:42 PM] **+52 1 662 467 9029:**
> _+52 1 662 245 0227: [album]_
MVP

[8:43 PM] **+52 1 662 245 0227:** Aram MVP

[8:43 PM] **+52 1 662 467 9029:** Se le acabó todo el aura en el ultimo partido pero antes Aram MVP

[8:43 PM] **+52 1 662 245 0227:** tengo una entrevista en exclusiva con el

[8:43 PM] **+52 1 662 245 0227:** [Sticker]

[8:43 PM] **+52 1 662 467 9029:** @~Miguel Rojas que decias de mi portero w?

[8:43 PM] **+52 1 662 467 9029:**
> _+52 1 662 245 0227: tengo una entrevista en exclusiva con el_
Real?

[8:44 PM] **+52 1 662 350 5885:**
> _+52 1 662 467 9029: @~Miguel Rojas que decias de mi portero w?_
AJAKAJSAKSJAKSJAKSJSJS DILE ALEX DILE

[8:44 PM] **+52 1 662 245 0227:**
> _+52 1 662 467 9029: @~Miguel Rojas que decias de mi portero w?_
que las paraba todas y le metieron todas?

[8:44 PM] **+52 1 662 245 0227:**
> _+52 1 662 467 9029: Real?_
así es

[8:44 PM] **+52 1 662 467 9029:**
> _+52 1 662 245 0227: así es_
Awebo ajajaja

[8:44 PM] **+52 1 55 5473 2571:**
> _+52 1 662 467 9029: @~Miguel Rojas que decias de mi portero w?_
joer, lo vi jugar y no supe si era el Aram o Courtois

[8:44 PM] **+52 1 662 467 9029:**
> _+52 1 662 245 0227: así es_
A el no se la mete nadie

[8:45 PM] **+52 1 662 467 9029:**
> _+52 1 55 5473 2571: joer, lo vi jugar y no supe si era el Aram o Courtois_
Les dije

[8:45 PM] **+52 1 662 245 0227:** yo pensé que era ochoa

[8:46 PM] **+52 1 662 467 9029:** Hasta vino como el

[8:54 PM] **+52 1 662 467 9029:** _This message was deleted by admin +52 1 662 449 3477_

[9:04 PM] **+52 1 662 361 4760:**
> _+52 1 662 361 4760: Vodka juniors va a dar la sorpresa ojo con Vodka juniors siempre decia mi tata_
Mi tata no se equivoco cuando dijo:

[9:12 PM] **+52 1 662 449 3477:** buen día para recordar que mañana inician las ponencias a las 9 am

[9:12 PM] **+52 1 662 449 3477:** también dará una el maestro eduardo (top profes)

[9:12 PM] **+52 1 662 449 3477:** [Sticker]

[9:18 PM] **+52 1 662 335 9011:**
> _+52 1 662 449 3477: también dará una el maestro eduardo (top profes)_
Pasen horaaaa

[9:18 PM] **+52 1 662 335 9011:** [Sticker]

[9:18 PM] **+52 1 662 449 3477:**
> _+52 1 662 335 9011: Pasen horaaaa_
nueve am inicia las ponencias 9:20 inicia el goat

[9:18 PM] **+52 1 662 449 3477:** [Sticker]

[9:18 PM] **+52 1 662 335 9011:** [Sticker]

[9:21 PM] **+52 1 662 245 0227:** [Video] @~😼 Alex CF el wey que barre

[9:31 PM] **+52 1 662 182 7287:** _This message was deleted_

[9:31 PM] **+52 1 662 182 7287:** _This message was deleted_

[9:35 PM] **+52 1 662 245 0227:** [Sticker]

[9:35 PM] **+52 1 662 327 9060:** Pasen los videos del futbol

[9:36 PM] **+52 1 662 467 9029:**
> _+52 1 662 245 0227: Video: @~😼 Alex CF el wey que barre_
me duele la espalda w

[9:36 PM] **+52 1 662 332 3680:** Mañana a qué hora es el de Voleibol?

[9:37 PM] **+52 1 662 449 3477:** 4

[9:38 PM] **+52 1 662 332 3680:**
> _+52 1 662 449 3477: 4_
[Sticker]

[9:38 PM] **+52 1 662 332 3680:** Gracias

[9:39 PM] **+52 1 662 245 0227:**
> _+52 1 662 467 9029: me duele la espalda w_
tardaste más barriendo que jugando

[9:39 PM] **+52 1 662 245 0227:** nosierto, te tkm

[9:39 PM] **+52 1 662 245 0227:** [Sticker]

[9:39 PM] **+52 1 631 125 1255:** adrianvo mvp

[9:41 PM] **+52 1 662 342 4670:**
> _+52 1 662 327 9060: Pasen los videos del futbol_
[album message]

[9:43 PM] **+52 1 662 353 5181:** [album message]

[9:43 PM] **+52 1 662 353 5181:** [Image] por si a alguien le interesa

[9:43 PM] **+52 1 662 353 5181:** [Image]

[9:43 PM] **+52 1 662 353 5181:** [Image]

[9:43 PM] **+52 1 662 353 5181:** [Image]

[9:50 PM] **+52 1 662 467 9029:**
> _+52 1 662 245 0227: tardaste más barriendo que jugando_
aporté mas en la barrida alch

[10:44 PM] **+52 1 662 522 5777:**
> _+52 1 662 307 4979: Hay algo que se pueda hacer al respecto?_
Reunir un grupo de personas y poncharles las llantas

[10:44 PM] **+52 1 662 522 5777:** O quitarle una

[10:53 PM] **+52 1 662 342 4670:**
> _+52 1 662 327 9060: Pasen los videos del futbol_
[Video] El último

---

## September 1, 2026

[6:32 AM] **+52 1 662 501 3191:** Alguien tiene solamente un Dock de switch que pueda prestar? dock y cable de corriente nada más

[6:32 AM] **+52 1 662 501 3191:** [Sticker]

[6:50 AM] **+52 1 667 973 4142:** habra Contexto Regional de 1 a 2?

[8:56 AM] **+52 1 662 426 8411:** CHICOS YA VAN A EMPEZAR LAS PONENCIAS

[8:58 AM] **+52 1 662 426 8411:** A LAS 9:00 EMPIEZAN TODOS AL AUDITORIO YA‼️‼️

[9:01 AM] **+52 1 662 326 0064:** oigan le dijeron al profe de analisis logico??

[9:01 AM] **+52 1 662 326 0064:** yo si quiero ir

[9:05 AM] **+52 1 662 476 3432:**
> _+52 1 662 326 0064: oigan le dijeron al profe de analisis logico??_
Ya le dijeron si

[9:05 AM] **+52 1 662 476 3432:** [Sticker]

[9:09 AM] **+52 1 662 426 8411:** Acaba de iniciar las ponencias, vengan todos ‼️‼️

[9:09 AM] **+52 1 662 426 8411:** Especialmente los de nuevo ingreso 👀

[9:12 AM] **+52 1 662 426 8411:** [Image]

[9:14 AM] **+52 1 662 463 6894:** Búsqueda del tesoro 🤪

[9:30 AM] **+52 1 662 450 9504:** Como que ponencias?

[9:34 AM] **+52 1 631 125 1255:** platicas vaya

[10:29 AM] **+52 1 662 450 9504:** Ah

[10:29 AM] **+52 1 662 450 9504:** Y en que acabo?

[11:21 AM] **+52 1 662 335 9011:** @~Jorge Luna

[12:32 PM] **+52 1 631 125 1255:** vuela alto cc

[12:32 PM] **+52 1 631 125 1255:** te ira mejor como un salon

[12:35 PM] **+52 1 662 450 9504:** Siempre si lo van a hacer salón?

[12:35 PM] **+52 1 662 476 3432:**
> _+52 1 631 125 1255: te ira mejor como un salon_
Que paso?

[12:35 PM] **+52 1 662 128 2906:**
> _+52 1 631 125 1255: te ira mejor como un salon_
No te tocaba carnal

[12:36 PM] **+52 1 662 341 2644:** aún le faltaban más fourlokos

[12:36 PM] **+52 1 662 426 8411:** Alguien agarro un cable VGA a VGA en el auditorio?

[12:36 PM] **+52 1 662 341 2644:** [Sticker]

[12:39 PM] **+52 1 662 426 8411:**
> _+52 1 662 426 8411: Alguien agarro un cable VGA a VGA en el auditorio?_
O alguien tiene?

[12:55 PM] **+52 1 662 467 9029:** Quien prestó una switch 2 ocupamos que se identifique porfa

[12:56 PM] **+52 1 662 476 3432:**
> _+52 1 662 467 9029: Quien prestó una switch 2 ocupamos que se identifique porfa_
El leinad

[1:36 PM] **+52 1 662 501 3191:** https://www.start.gg/tournament/rompehielos-lcc-2026/event/mario-kart-8-deluxe-4-players-ffa/brackets/2377123/3429879

[1:59 PM] **+52 1 662 467 9029:** Gente, el itinerario de hoy no se cambiará, volleyball a las 4:00. En todo caso avisaremos cualquier cambio.

No se preocupen si estan en ambos torneos, el de Mario Kart se pausará a tiempo y se continuará mañana

[1:59 PM] **+52 1 662 467 9029:** [Image] Oigan, ya se que están chiquitos pero paro no dejen abierta esta puerta, sentido comun porfavor

[2:04 PM] **+52 1 662 342 4670:** Hay crema para el café?

[2:04 PM] **+52 1 662 342 4670:** [Sticker]

[2:17 PM] **+52 1 662 385 5717:** Ei Sonia quiere un grupo para todos los del plan viejo q tengan materias atrasadas

[2:19 PM] **+52 1 662 385 5717:** https://chat.whatsapp.com/DpW7uEn8Pr34AFRlVma7eN?s=cl&p=a&mlu=4

[2:20 PM] **+52 1 662 385 5717:** O háganlo en la comunidad de aqui

[2:28 PM] **+52 1 662 467 9029:** @⚽️Volleyball

Buenas, el torneo de Volleyball se pospone para las 5:00

[2:33 PM] **+52 1 662 142 7436:** [Sticker]

[2:33 PM] **+52 1 662 467 9029:** @~Rodrigo Espinoza Garcia ignora este ping, es para q te ubique algjien

[2:34 PM] **+52 1 662 444 7675:** [Sticker]

[2:42 PM] **+52 1 662 476 3432:** [Sticker]

[3:16 PM] **+52 1 631 125 1255:** [Image] quien quiera q sea el dueño de esos termos y coca, que sepan q estan más pateados q balon de futbol

[3:16 PM] **+52 1 631 125 1255:** se les dijo q no dejaran cosas en la pasada y les valio monda

[3:19 PM] **+52 1 637 138 5080:** Ya hay bracket para el torneo de voley?

[3:19 PM] **+52 1 662 342 9577:**
> _+52 1 662 467 9029: @~Rodrigo Espinoza Garcia ignora este ping, es para q te ubique algjien_
Que

[3:22 PM] **+52 1 662 480 2261:**
> _+52 1 637 138 5080: Ya hay bracket para el torneo de voley?_
no

[3:23 PM] **+52 1 637 117 9366:** 😅

[3:35 PM] **+52 1 662 357 9360:** Los de voley q quieran ir practicando

[3:35 PM] **+52 1 662 357 9360:** Vayan

[3:37 PM] **+52 1 662 357 9360:** Ln no vengan hace un solaso

[3:38 PM] **+52 1 631 125 1255:**
> _+52 1 662 342 9577: Que_
so

[4:17 PM] **+52 1 662 421 5556:** [Image] Raza, alguien de casualidad tiene este libro que me venda?

[4:20 PM] **+52 1 662 342 4670:** [Image] Con el chico del cafeeee

[4:21 PM] **+52 1 662 342 4670:** [Sticker]

[4:21 PM] **+52 1 662 342 4670:** [Sticker]

[5:11 PM] **+52 1 631 125 1255:** rolen el horario de los equipos del volley

[5:11 PM] **+52 1 631 125 1255:** [Sticker]

[5:13 PM] **+52 1 662 431 3826:** Donde es lo de voley

[5:13 PM] **+52 1 662 431 3826:** ???

[5:13 PM] **+52 1 662 268 7744:** @all

[5:13 PM] **+52 1 662 268 7744:** quien tiene el orden de los equipos que juegan hoyyy

[5:13 PM] **+52 1 662 268 7744:** y donde es nmms

[5:14 PM] **+52 1 662 335 9011:**
> _+52 1 662 431 3826: Donde es lo de voley_
Cancha de física (creo)

[5:14 PM] **+52 1 662 335 9011:** [Sticker]

[5:14 PM] **+52 1 662 346 2643:** [Image]

[5:14 PM] **+52 1 662 346 2643:**
> _+52 1 662 268 7744: y donde es nmms_
Dónde daban laboratorio de fluidos y electro

[5:17 PM] **+52 1 631 125 1255:**
> _+52 1 631 125 1255: rolen el horario de los equipos del volley_
quiero saber cuando y con quien juego gachos

[5:20 PM] **+52 1 55 5473 2571:**
> _+52 1 631 125 1255: quiero saber cuando y con quien juego gachos_
hoy, contra su rival

[5:23 PM] **+52 1 662 394 7514:**
> _+52 1 55 5473 2571: hoy, contra su rival_
[Sticker]

[5:24 PM] **+52 1 631 125 1255:**
> _+52 1 55 5473 2571: hoy, contra su rival_
[Voice message]

[5:53 PM] **+52 1 662 522 5777:** Los que traen la Molten 5,00 0 les encargó la bola porfa 👏

[6:03 PM] **+52 1 662 450 9504:**
> _+52 1 631 125 1255: Voice message_
[Sticker]

[7:09 PM] **+52 1 662 342 4670:** Manden foto

[7:09 PM] **+52 1 662 342 4670:** Para ver quienes están

[7:09 PM] **+52 1 662 342 4670:** O video

[7:09 PM] **+52 1 662 342 4670:** [Sticker]

[7:41 PM] **+52 1 662 111 6493:** Que rollo, nadie agarró un celular en la cancha de voli? Es de mi compañero @~Chema Nuñez

[7:43 PM] **+52 1 662 268 7744:** no lo trae el wicho?

[7:43 PM] **+52 1 662 268 7744:** en su mochila? la dejo en el cc

[7:44 PM] **+52 1 662 373 9949:**
> _+52 1 662 111 6493: Que rollo, nadie agarró un celular en la cancha de voli? Es de mi compañero @~Chema Nuñez_
Márcale al Chema para avisarle que se le perdió

[7:44 PM] **+52 1 662 111 6493:**
> _+52 1 662 373 9949: Márcale al Chema para avisarle que se le perdió_
ya w, pero no responde el ondeado

[7:44 PM] **+52 1 662 342 4670:** Alguien de aquí jala jugar al loooool

[7:44 PM] **+52 1 662 365 9837:** [Sticker]

[7:44 PM] **+52 1 662 365 9837:** Mejor nadota

[7:44 PM] **+52 1 662 111 6493:**
> _+52 1 662 268 7744: no lo trae el wicho?_
@~Mr.Wicho

[7:45 PM] **+52 1 662 373 9949:**
> _+52 1 662 111 6493: ya w, pero no responde el ondeado_
Así como @~Chema Nuñez

[7:56 PM] **+52 1 662 102 3114:**
> _+52 1 662 111 6493: @~Mr.Wicho_
Tenia el del Roger

[7:56 PM] **+52 1 662 111 6493:** ya se encontró

[7:57 PM] **+52 1 662 341 2644:**
> _+52 1 662 342 4670: Alguien de aquí jala jugar al loooool_
Un valito

[7:57 PM] **+52 1 662 399 2340:**
> _+52 1 662 341 2644: Un valito_
Saca

[7:57 PM] **+52 1 662 342 4670:**
> _+52 1 662 341 2644: Un valito_
Como?, jaja

[7:57 PM] **+52 1 662 342 4670:** Aaah

[7:57 PM] **+52 1 662 342 4670:** No juego eso

[7:57 PM] **+52 1 662 342 4670:** Srry

[7:59 PM] **+52 1 662 426 6490:**
> _+52 1 662 341 2644: Un valito_
[Sticker]

[7:59 PM] **+52 1 637 117 9366:**
> _+52 1 662 341 2644: Un valito_
Valo valo

[8:00 PM] **+52 1 662 165 5994:**
> _+52 1 637 117 9366: Valo valo_
Valo valo

[8:00 PM] **+52 1 662 448 8831:** alguien juega cs2?😓😓

[8:00 PM] **+52 1 662 426 8411:** Un bedwars

[8:00 PM] **+52 1 662 426 6490:** malditos visios

[8:00 PM] **+52 1 662 426 6490:** [Sticker]

[8:00 PM] **+52 1 662 426 6490:** dejen el valo

[8:00 PM] **+52 1 662 165 5994:**
> _+52 1 662 426 6490: malditos visios_
[Sticker]

[8:00 PM] **+52 1 662 165 5994:**
> _+52 1 662 426 6490: dejen el valo_
N0

[8:02 PM] **+52 1 631 125 1255:** ola ya encontre mi cel

[8:02 PM] **+52 1 645 107 9121:**
> _+52 1 662 426 6490: dejen el valo_
un torneo de valo estaría bueno

[8:02 PM] **+52 1 662 225 5408:**
> _+52 1 662 426 6490: dejen el valo_
[Sticker]

[8:02 PM] **+52 1 631 125 1255:** se me metio en el fundio cuando se me rompio el short

[8:02 PM] **+52 1 645 107 9121:** si el de mario kart tuvo hype

[8:02 PM] **+52 1 637 117 9366:**
> _+52 1 645 107 9121: un torneo de valo estaría bueno_
Hay que hacerlo

[8:02 PM] **+52 1 637 117 9366:** [Sticker]

[8:02 PM] **+52 1 631 125 1255:**
> _+52 1 631 125 1255: se me metio en el fundio cuando se me rompio el short_
[Sticker]

[8:02 PM] **+52 1 662 426 6490:** [Sticker]

[8:03 PM] **+52 1 637 117 9366:**
> _+52 1 631 125 1255: se me metio en el fundio cuando se me rompio el short_
[Sticker]

[8:03 PM] **+52 1 645 107 9121:** imagínate a juanito262 en un 4v1

[8:03 PM] **+52 1 645 107 9121:** y ganándole a todos con su aim de monstruo y reflejos inhumanos

[8:05 PM] **+52 1 662 342 4670:**
> _+52 1 645 107 9121: un torneo de valo estaría bueno_
De loool

[8:05 PM] **+52 1 662 342 4670:** [Sticker]

[8:05 PM] **+52 1 662 342 4670:** [Sticker]

[8:05 PM] **+52 1 645 107 9121:**
> _+52 1 662 342 4670: De loool_
ahí nos vamos a topar al Faker

[8:06 PM] **+52 1 662 342 4670:** Sueñas

[8:06 PM] **+52 1 662 342 4670:** No tenemos tan alto nivel

[8:47 PM] **+52 1 662 367 0042:** saquen torneo de valo

[8:47 PM] **+52 1 662 367 0042:** [Sticker]

[8:48 PM] **+52 1 662 367 0042:** quien es inmortal? pa descalificar de una ve

[8:49 PM] **+52 1 662 420 8102:**
> _+52 1 662 367 0042: quien es inmortal? pa descalificar de una ve_
nomás llegué a asc 2 y dejé el juego después

[8:49 PM] **+52 1 662 420 8102:** [Sticker]

[8:50 PM] **+52 1 662 367 0042:** no cualquiera

[8:50 PM] **+52 1 662 367 0042:** [Sticker]

[9:00 PM] **+52 1 662 139 3528:** Mejor de lol

[9:00 PM] **+52 1 662 139 3528:** El próximo rompehielos quiero uno @~estrella

[9:00 PM] **+52 1 662 139 3528:** [Sticker]

[9:01 PM] **+52 1 662 426 8411:** Mejor un torneo de bedwars

[9:01 PM] **+52 1 662 426 8411:** O un UHC

[9:01 PM] **+52 1 662 426 8411:** En java pro favor

[9:01 PM] **+52 1 662 412 0821:** Porfin alguien que dice coherencias

[9:01 PM] **+52 1 662 245 0227:** uhc en 1.9

[9:01 PM] **+52 1 662 245 0227:** 1.8 es una mierda

[9:01 PM] **+52 1 662 426 8411:**
> _+52 1 662 245 0227: uhc en 1.9_
Esooo!!!!

[9:01 PM] **+52 1 662 426 8411:** A no wait

[9:01 PM] **+52 1 662 426 8411:** Me ondie

[9:01 PM] **+52 1 662 426 8411:** Nombre UHC en la 1.8 mejor

[9:01 PM] **+52 1 662 245 0227:** demasiado tarde

[9:02 PM] **+52 1 662 426 8411:** Si es 1.9 ya que sea en la última versión

[9:02 PM] **+52 1 644 422 2240:** El próximo año cambien el de Mario Kart al de la Wii, hay que aprovechar el recomp 🦅

[9:02 PM] **+52 1 662 245 0227:** jalapeños

[9:02 PM] **+52 1 662 245 0227:** hay que sacar del world

[9:02 PM] **+52 1 644 422 2240:**
> _+52 1 662 245 0227: hay que sacar del world_
no hay baro we perate

[9:02 PM] **+52 1 662 426 8411:** Torneo de geometry dash

[9:02 PM] **+52 1 662 245 0227:** [Video]

[9:02 PM] **+52 1 662 426 8411:** _This message was deleted_

[9:03 PM] **+52 1 644 422 2240:** Si we

[9:03 PM] **+52 1 644 422 2240:** Mejor no hubieras puesto nad

[9:03 PM] **+52 1 662 399 4928:**
> _+52 1 662 139 3528: El próximo rompehielos quiero uno @~estrella_
BALE SI

[9:05 PM] **+52 1 662 139 3528:**
> _+52 1 662 399 4928: BALE SI_
Siiiii

[9:05 PM] **+52 1 662 453 0888:**
> _+52 1 662 426 8411: Torneo de geometry dash_
Qn se pase primero un insane gana 🔥🔥🔥

[9:13 PM] **+52 1 662 299 4587:**
> _+52 1 644 422 2240: El próximo año cambien el de Mario Kart al de la Wii, hay que aprovechar el recomp 🦅_
uno de wii sports

[9:13 PM] **+52 1 662 201 5870:** Wii sports resort

[9:14 PM] **+52 1 631 125 1255:**
> _+52 1 662 201 5870: Wii sports resort_
HEY HEY HEY

[9:14 PM] **+52 1 631 125 1255:** ya estamos hablando como personas civilizadas

[9:15 PM] **+52 1 662 467 9029:**
> _+52 1 644 422 2240: El próximo año cambien el de Mario Kart al de la Wii, hay que aprovechar el recomp 🦅_
Nomas es conseguir los 4 emuladores

[9:15 PM] **+52 1 662 467 9029:** ☠️

[9:15 PM] **+52 1 662 467 9029:** Pero es posible

[9:15 PM] **+52 1 662 299 4587:** [GIF]

[9:15 PM] **+52 1 662 201 5870:** Un wii chipeado

[9:15 PM] **+52 1 662 201 5870:** 🤑

[9:15 PM] **+52 1 662 299 4587:**
> _+52 1 662 467 9029: Nomas es conseguir los 4 emuladores_
las wiis sobran

[9:16 PM] **+52 1 644 422 2240:**
> _+52 1 662 467 9029: Nomas es conseguir los 4 emuladores_
No es tan complicado, @~Angel sabe aventarse el proceso de esa madre

[9:16 PM] **+52 1 644 422 2240:** [Sticker]

[9:27 PM] **+52 1 984 522 6144:**
> _+52 1 644 422 2240: El próximo año cambien el de Mario Kart al de la Wii, hay que aprovechar el recomp 🦅_
GENIO

[9:27 PM] **+52 1 984 522 6144:** [Sticker]

[9:28 PM] **+52 1 662 637 5722:** uno de Catán

[9:29 PM] **+52 1 662 165 5994:**
> _+52 1 662 637 5722: uno de Catán_
Si jalo

[9:29 PM] **+52 1 662 637 5722:**
> _+52 1 662 165 5994: Si jalo_
tú no

[9:30 PM] **+52 1 662 165 5994:**
> _+52 1 662 637 5722: tú no_
Kyc

[9:30 PM] **+52 1 662 467 9029:** No he visto mucho el chat pero el Catan es la idea nueva más seria y buena de todas las q he visto

[9:30 PM] **+52 1 662 467 9029:** Pero esa es chamba de @tercero

[9:58 PM] **+52 1 631 193 8410:**
> _+52 1 662 467 9029: Nomas es conseguir los 4 emuladores_
Wey esa madre corre hasta en mi cel

[9:59 PM] **+52 1 631 193 8410:**
> _+52 1 662 299 4587: las wiis sobran_
Aparte

[9:59 PM] **+52 1 631 193 8410:** Pero cuando el torneo de pvz vs mode?

[9:59 PM] **+52 1 662 299 4587:**
> _+52 1 662 637 5722: uno de Catán_
@~AndresGtz

[10:00 PM] **+52 1 662 335 9011:**
> _+52 1 631 193 8410: Pero cuando el torneo de pvz vs mode?_
Saquen

[10:00 PM] **+52 1 662 335 9011:** [Sticker]

[10:01 PM] **+52 1 662 335 9011:** Pvz 1 vanilla vegezombies 2 con full setas de día Best of 5

[10:01 PM] **+52 1 662 335 9011:** [Sticker]

[10:41 PM] **+52 1 662 347 4679:** Oigan, a qué hora será el torneo de ping pong?

[10:42 PM] **+52 1 662 501 3191:**
> _+52 1 662 347 4679: Oigan, a qué hora será el torneo de ping pong?_
A las 9:00am estar ahí

[10:42 PM] **+52 1 662 299 4587:**
> _+52 1 631 125 1255: Image: Ya está el itinerario del rompe hielo junto con su registro para que se vayan apuntando a los torneos y también vayan a apoyar a sus compañeros!! 

a partir del 31 de agosto  

Torneo de voley
https://forms.gle/97LV4m9Sy28hbk2V7

Torneo de futbol
https://forms.gle/mpoEcVdtAVPdpNVi7

Torneo ajedrez
https://forms.gle/gopJFurJzh2HwswH7

Torneo de pingpong 
https://forms.gle/y6C5PCfMY3CPzyKs8

Búsqueda del tesoro
https://forms.gle/AeRLgVsjVUGYSm3b7

Torneo de Mario Kart
https://forms.gle/d3sCJ7RKBMKzZzF1A

Torneo de Smash
https://forms.gle/xZTvABqi5JZreYN47_
empieza a las 9

[10:42 PM] **+52 1 662 501 3191:** Y ya por las 9:10 se les estaría llamando

[10:42 PM] **+52 1 662 501 3191:** Será enfrente de la explanada de LCC

[10:42 PM] **+52 1 662 299 4587:** las partidas a veces son algo rápidas

[10:42 PM] **+52 1 662 299 4587:** para que estén atentos

[10:43 PM] **+52 1 662 367 8720:**
> _+52 1 662 501 3191: A las 9:00am estar ahí_
si alguieeeeen, respondieraaaaaaa

[10:43 PM] **+52 1 662 501 3191:**
> _+52 1 662 367 8720: si alguieeeeen, respondieraaaaaaa_
Pero no me han mandado mensaje we

[10:43 PM] **+52 1 662 501 3191:** [Sticker]

[10:43 PM] **+52 1 662 367 8720:** si we si we

[11:00 PM] **+52 1 662 396 3389:**
> _+52 1 662 426 8411: Nombre UHC en la 1.8 mejor_
We q pedo unos pvps en mimemen

[11:00 PM] **+52 1 662 396 3389:** Pura gente en mi casa

[11:00 PM] **+52 1 662 396 3389:** [Sticker]

[11:04 PM] **+52 1 662 522 5777:** nadie tomo video de los de voley?

[11:12 PM] **+52 1 662 467 9029:** Si, @~lu, @~Jazz  y @~S Payan fotos

[11:12 PM] **+52 1 662 467 9029:** No se si alguien mas

---

## September 2, 2026

[6:50 AM] **+52 1 662 467 9029:** Buenas. Solo para que quienes prestaron cosas y aún no las han identificado se comuniquen conmigo o con @~Angel porfavor

[6:50 AM] **+52 1 662 467 9029:** @~Angel onta mi control w

[6:50 AM] **+52 1 662 501 3191:**
> _+52 1 662 467 9029: @~Angel onta mi control w_
Tus dos controles en el cubículo de Eduardo

[7:29 AM] **+52 1 662 467 9029:** _This message was deleted_

[7:34 AM] **+52 1 662 467 9029:** Mentira, hay buen pronóstico

[7:40 AM] **+52 1 645 107 9121:** [Video]

[8:11 AM] **+52 1 662 449 3477:** les sirve el portal?

[8:12 AM] **+52 1 662 467 8870:**
> _+52 1 662 449 3477: les sirve el portal?_
No se

[8:12 AM] **+52 1 662 467 8870:** Nunca ha servido

[8:12 AM] **+52 1 662 467 8870:** [Sticker]

[8:13 AM] **+52 1 662 165 5994:**
> _+52 1 662 449 3477: les sirve el portal?_
si

[8:54 AM] **+52 1 662 467 9029:** [Forwarded] [Image] Estás serán las primeras 3 parejas en participar si pueden llegar a las 9 al  frente del edificio de lcc

[8:54 AM] **+52 1 662 467 9029:** Esta es el ultimo aviso relacionado a un torneo, si son jugadores porfavor metanse a los grupos de sus torneos

[8:54 AM] **+52 1 662 467 9029:**
> _+52 1 662 467 9029: 🗣🗣🗣🗣🗣

🔴 Hola, ya se pueden unir a los grupos de cada evento y torneo del rompehielos.

🔵 Si son participantes por favor unanse, ahí publicaremos cosas importantes que pueden llegar a necesitar.

🟢 Ahí se publicarán los brackets con anticipación y se publicarán reglas especiales para cada torneo.

🟡 Si no son participantes pero quieren chismear también se pueden unir :]

https://chat.whatsapp.com/F906QJRBBGgLRXXFyAlneN_
.

[9:15 AM] **+52 1 662 245 0227:** https://challonge.com/es/lgkkkwjp

[9:15 AM] **+52 1 662 245 0227:** la bracket

[9:26 AM] **+52 1 662 142 7436:** Oyee

[10:30 AM] **+52 1 662 341 2644:** [Image] @~Dania Vega

[10:30 AM] **+52 1 662 412 0821:**
> _+52 1 662 341 2644: Image: @~Dania Vega_
Otro artefacto maldito

[10:31 AM] **+52 1 662 449 3477:**
> _+52 1 662 341 2644: Image: @~Dania Vega_
qp no invitas

[10:32 AM] **+52 1 662 341 2644:** es q no te encontré w

[10:36 AM] **+52 1 662 295 4218:**
> _+52 1 662 341 2644: Image: @~Dania Vega_
Donde los compran?

[10:36 AM] **+52 1 662 341 2644:**
> _+52 1 662 295 4218: Donde los compran?_
Pregúntale a la paloma

[10:37 AM] **+52 1 662 341 2644:** ella los recomienda mucho en ig

[10:37 AM] **+52 1 662 295 4218:** Quien es paloma?

[10:41 AM] **+52 1 662 427 9029:** https://www.instagram.com/loschilaquillos?igsi=MXcyMDY1ZXB0cnM3bg==

[10:41 AM] **+52 1 662 467 8870:**
> _+52 1 662 449 3477: qp no invitas_
Por q lo vas a funar si no t gustan

[10:41 AM] **+52 1 662 467 8870:** [Sticker]

[10:42 AM] **+52 1 662 341 2644:** [Sticker]

[11:08 AM] **+52 1 662 469 3513:** alguien sabe si el maestro Adrián ha estado dando clases esta semana?

[11:21 AM] **+52 1 662 367 1384:** Dio clases el lunes, pero ayer no. Se suponía que sí iba a estar dando clases esta semana

[11:21 AM] **+52 1 662 361 1416:** Si el profe anda jugando ping pong

[11:30 AM] **+52 1 662 469 3513:** [Sticker]

[11:33 AM] **+52 1 637 117 9366:** _Waiting for this message. This may take a while._

[11:40 AM] **+52 1 662 467 9029:** Abre este enlace para unirte a mi grupo de WhatsApp: https://chat.whatsapp.com/Dsur1PHY5fkAX7l6sMmBRr

[11:51 AM] **+52 1 662 399 2340:**
> _+52 1 662 341 2644: Image: @~Dania Vega_
Los chilaquiles de la discordia

[12:07 PM] **+52 1 662 385 5717:** _This message was deleted_

[12:08 PM] **+52 1 662 385 5717:**
> _+52 1 662 385 5717: [unknown]_
Eeeee

[12:08 PM] **+52 1 662 467 9029:** @elias

[12:08 PM] **+52 1 662 467 9029:** Bruh

[12:08 PM] **+52 1 662 467 9029:** Elias tiene 4 minutos

[12:08 PM] **+52 1 662 385 5717:** Waissman dara clases

[12:08 PM] **+52 1 662 936 2004:** Hola Oliver

[12:14 PM] **+52 1 662 341 2644:**
> _+52 1 662 385 5717: Waissman dara clases_
Siempre si?

[12:14 PM] **+52 1 662 385 5717:** Aaa

[12:14 PM] **+52 1 662 385 5717:** Es pregunta

[12:14 PM] **+52 1 662 385 5717:** Fakk

[12:14 PM] **+52 1 662 385 5717:** Ando en mi casa we

[12:59 PM] **+52 1 662 501 3191:** CHICOS EL TORNEO DE MARIO KART YA VA A EMPEZAR

[1:01 PM] **+52 1 634 109 6592:**
> _+52 1 662 501 3191: CHICOS EL TORNEO DE MARIO KART YA VA A EMPEZAR_
Ya se puede entrar o todavía no??

[1:04 PM] **+52 1 662 360 3569:** ya pueden ir entrando al auditorio chicos!!!

[1:05 PM] **+52 1 662 426 8411:** Avisen cuando me toque

[1:05 PM] **+52 1 662 426 8411:** APLS

[1:05 PM] **+52 1 662 335 9011:** Siii

[1:06 PM] **+52 1 662 335 9011:**
> _+52 1 662 360 3569: ya pueden ir entrando al auditorio chicos!!!_
@all

[1:16 PM] **+52 1 662 360 3569:** vengan chicos! ya van a empezar las carreritas 👩‍🔧🍄🚗8️⃣!!

[1:52 PM] **+52 1 662 517 8362:** [Sticker]

[2:24 PM] **+52 1 662 467 9029:** Soy el we de las mesas

[2:24 PM] **+52 1 662 467 9029:** Soy el we de las mesas

[2:24 PM] **+52 1 662 467 9029:** Soy el we de las mesas

[2:24 PM] **+52 1 662 467 9029:** Soy el we de las mesas

[2:25 PM] **+52 1 631 125 1255:** Porfavor los vocales de cada generacion mandarme mensaje, solamente me han mandado mensaje 5 de los 10 que son

[2:25 PM] **+52 1 662 449 3477:**
> _+52 1 662 341 2644: es q no te encontré w_
oye y la de mandar un mensajito

[2:25 PM] **+52 1 662 449 3477:** me dejaste con hambre

[2:25 PM] **+52 1 662 449 3477:** [Sticker]

[2:25 PM] **+52 1 662 449 3477:**
> _+52 1 662 467 8870: Por q lo vas a funar si no t gustan_
yo nunca he echo eso compañerito

[2:25 PM] **+52 1 662 449 3477:** no sé de qué hablas

[2:25 PM] **+52 1 662 449 3477:** [Sticker]

[2:27 PM] **+52 1 662 467 8870:**
> _+52 1 662 449 3477: no sé de qué hablas_
[Sticker]

[2:28 PM] **Remil:**
> _+52 1 662 427 9029: https://www.instagram.com/loschilaquillos?igsi=MXcyMDY1ZXB0cnM3bg==_
OJO QUE ESOS SON LOS QUE DAN CHORRO

[2:49 PM] **+52 1 662 360 3569:** GRAN FINAL MARIO KART AHORA MISMO AUDITORIO!!! 🍄👩‍🔧🚗8️⃣

[2:53 PM] **+52 1 662 426 8411:** TEAM ANGEL

[2:54 PM] **+52 1 662 426 8411:** [Sticker]

[2:54 PM] **+52 1 662 341 2644:** TEAM EMI

[2:54 PM] **+52 1 662 341 2644:** [Sticker]

[2:54 PM] **+52 1 631 125 1255:** [Sticker]

[2:55 PM] **Laura Uni:** [Sticker]

[2:55 PM] **+52 1 662 847 7382:** [Sticker]

[2:55 PM] **+52 1 662 470 9935:** [Sticker]

[2:57 PM] **+52 1 662 373 9949:** No viejo

[2:57 PM] **+52 1 662 373 9949:** No tienen el OG

[2:57 PM] **+52 1 662 373 9949:** [Sticker]

[2:58 PM] **+52 1 662 426 8411:** [Sticker]

[2:58 PM] **+52 1 662 426 8411:** [Sticker]

[3:00 PM] **+52 1 633 335 6939:** [Sticker]

[3:01 PM] **+52 1 662 373 9949:** [Sticker]

[3:01 PM] **+52 1 662 268 7744:** [Sticker]

[3:03 PM] **Remil:** [Sticker]

[3:03 PM] **Remil:** [Sticker]

[3:03 PM] **Remil:** [Sticker]

[3:03 PM] **+52 1 633 335 6651:** [Sticker]

[3:03 PM] **+52 1 633 335 6651:** [Sticker]

[3:03 PM] **+52 1 633 335 6651:** [Sticker]

[3:03 PM] **+52 1 662 432 8446:** [Sticker]

[3:03 PM] **+52 1 662 373 9949:** [Sticker]

[3:05 PM] **+52 1 633 134 8806:** [Sticker]

[3:05 PM] **Remil:**
> _+52 1 662 847 7382: Sticker_
Pero el OG

[3:06 PM] **+52 1 662 847 7382:** Ven a la uni pues

[3:07 PM] **Remil:** Me chingaron

[3:07 PM] **Remil:** @~Rogelio Peralta el Jezzy Recursivo

[3:13 PM] **+52 1 662 341 2644:**
> _+52 1 662 449 3477: me dejaste con hambre_
Para la próxima te aviso

[3:16 PM] **+52 1 637 117 9366:** _This message was deleted_

[3:17 PM] **+52 1 637 117 9366:** [Sticker]

[3:17 PM] **+52 1 662 299 5544:** [Sticker]

[3:23 PM] **+52 1 631 125 1255:** Saquen el joycon que cambiaron por el joycon roto cabrones

[3:31 PM] **+52 1 662 395 2196:** Porfa, los puse para que puedan jugar, no sean culones

[3:57 PM] **+52 1 662 365 9837:** Ya aparecieron los joycon?

[3:57 PM] **+52 1 662 365 9837:** [Sticker]

[4:04 PM] **+52 1 662 347 4679:** _This message was deleted_

[4:04 PM] **+52 1 662 360 3569:** Chicos no se vale, el compañero puso su consola para que todos podamos disfrutar el evento como para que terminen haciendo eso 🙁

[4:05 PM] **Remil:** Alaverga que forma de cagar la vibra

[4:05 PM] **Remil:** Aplausos

[4:05 PM] **+52 1 662 448 8831:** No tienen cámaras en el auditorio?

[4:05 PM] **+52 1 662 448 8831:** La nt que mala onda

[4:05 PM] **Remil:**
> _+52 1 662 448 8831: No tienen cámaras en el auditorio?_
Si hay, así que mejor que el tipo los regrese antes de que se pase a mayores

[4:06 PM] **+52 1 662 347 4679:**
> _Remil: Si hay, así que mejor que el tipo los regrese antes de que se pase a mayores_
[Sticker]

[4:06 PM] **+52 1 631 125 1255:** ai les vas el duelo por el segundo lugar

[4:07 PM] **+52 1 631 125 1255:** [Video]

[4:12 PM] **+52 1 662 699 4499:** [Image]

[4:12 PM] **+52 1 662 335 9011:** [Sticker]

[4:14 PM] **+52 1 662 369 3580:**
> _+52 1 662 699 4499: Image_
[Sticker]

[4:27 PM] **+52 1 984 522 6144:**
> _+52 1 631 125 1255: Video_
Tremendos ganadores

[4:27 PM] **+52 1 984 522 6144:** [Sticker]

[5:40 PM] **+52 1 662 395 2196:**
> _+52 1 662 365 9837: Ya aparecieron los joycon?_
No

[5:40 PM] **+52 1 662 395 2196:** [Sticker]

[5:48 PM] **+52 1 662 295 0244:** 🐀🐀

[5:49 PM] **+52 1 662 201 5870:** [Sticker]

[6:10 PM] **+52 1 662 360 3569:** 🐁🐁🐁🐁

[6:11 PM] **+52 1 662 335 9011:** Días desde el último LCC en decadencia: 0

[6:11 PM] **+52 1 662 335 9011:** 😭

[6:11 PM] **+52 1 644 404 0378:** No hay camaras ahí adentro?

[6:16 PM] **+52 1 662 165 5994:**
> _+52 1 644 404 0378: No hay camaras ahí adentro?_
No

[6:16 PM] **+52 1 662 335 9011:** [Sticker]

[6:17 PM] **+52 1 662 699 4499:** por eso no abriran el cc nunca

[6:17 PM] **+52 1 662 699 4499:** [Sticker]

[6:26 PM] **+52 1 662 335 9011:**
> _+52 1 662 699 4499: por eso no abriran el cc nunca_
El cc fue un efecto Mandela colectivo 🦅🔥🦅🔥

[6:27 PM] **+52 1 662 165 5994:** A ver si no nos piden organizar una campaña universitaria contra el alcoholismo para recuperarlo

[6:28 PM] **+52 1 662 699 4499:**
> _+52 1 662 165 5994: A ver si no nos piden organizar una campaña universitaria contra el alcoholismo para recuperarlo_
contra el no ser 🐀

[6:28 PM] **+52 1 662 335 9011:** [Sticker]

[6:28 PM] **+52 1 662 165 5994:**
> _+52 1 662 699 4499: contra el no ser 🐀_
También

[6:45 PM] **+52 1 662 501 3191:** https://www.start.gg/tournament/rompehielos-lcc-2026/event/smash-bros-ultimate-singles/brackets

Buenas tardes mi gente, las brackets para el torneo de Smash Ultimate ya son públicas, pueden ir revisando ya su bracket.

[6:45 PM] **+52 1 662 501 3191:** [Image] Como hay mucha gente, este torneo estará dividido en 4 Pools, en el que cada Pool tendrá su respectivo horario, para el quien no tenga tiempo temprano pueda mas tarde o viceversa, si por alguna razon ustedes no pueden temprano o no pueden muy tarde, mandenme mensaje al privado para moverlos a una pool mas temprana o viceversa, para que todos puedan jugar sin tener broncas con las horas vaya.

[6:46 PM] **+52 1 662 501 3191:** revisen en que pool y bracket estaran, en la imagen estan las horas en la que empieza cada Pool
siendo Wave A - Pool A1, Wave B - Pool B1, Wave C - Pool C1, Wave D - Pool D1

[7:23 PM] **+52 1 662 637 5722:** me pasan el logo de lcc?

[8:00 PM] **+52 1 662 367 1384:** _This message was deleted_

[8:01 PM] **+52 1 662 367 1384:** [Image]

[9:02 PM] **+52 1 662 142 7436:**
> _+52 1 662 367 1384: Image_
?

[9:02 PM] **+52 1 645 107 9121:**
> _+52 1 662 142 7436: ?_
es una diferencia simétrica conjunto o igual a

[9:03 PM] **+52 1 662 142 7436:** [Image]

[9:03 PM] **+52 1 662 142 7436:** Un morro con sueter

[9:03 PM] **+52 1 645 107 9121:**
> _+52 1 662 142 7436: Image_
eres tú

[9:04 PM] **+52 1 645 107 9121:** chico misterioso performative

[9:04 PM] **+52 1 662 142 7436:** [Sticker]

[9:05 PM] **+52 1 662 517 8362:** [Sticker]

[9:05 PM] **+52 1 662 467 9029:**
> _+52 1 662 426 8411: Sticker_
YOOOOU

[9:18 PM] **+52 1 662 449 3477:** amigos aquí las fotos de ahorita en volley

[9:19 PM] **+52 1 662 449 3477:** [album message]

[9:19 PM] **+52 1 662 449 3477:** [Image]

[9:19 PM] **+52 1 662 449 3477:** [Image]

[9:19 PM] **+52 1 662 449 3477:** [Image]

[9:19 PM] **+52 1 662 449 3477:** [Image]

[9:19 PM] **+52 1 662 449 3477:** [Image]

[9:19 PM] **+52 1 662 449 3477:** [Image]

[9:19 PM] **+52 1 662 449 3477:** [Video]

[9:19 PM] **+52 1 662 449 3477:** [Image]

[9:19 PM] **+52 1 662 449 3477:** [Image]

[9:19 PM] **+52 1 662 449 3477:** [Image]

[9:31 PM] **+52 1 662 522 5777:** quien gano?

[9:31 PM] **+52 1 662 449 3477:** se sabrá el viernes!!

[9:31 PM] **+52 1 662 449 3477:** para que vayan a la premiacion a ver

[9:31 PM] **+52 1 662 449 3477:** [Sticker]

[10:56 PM] **+52 1 662 449 3477:** pinpong mañana a las 8 am @all

[10:56 PM] **+52 1 644 404 0378:** Porque

[10:59 PM] **+52 1 662 467 9029:** Cómo

[11:05 PM] **+52 1 662 342 4670:**
> _+52 1 662 449 3477: pinpong mañana a las 8 am @all_
Si tengo clases se justifica la falta?

[11:05 PM] **+52 1 662 342 4670:** O noup

[11:09 PM] **+52 1 662 341 2644:** Depende del maestro

[11:09 PM] **+52 1 662 341 2644:** algunos son medio mamones

---

## September 3, 2026

[7:49 AM] **+52 1 662 467 9029:** Ola, busco remplazo para jugar en mi lugar en ping pong, siempre y cuando no haya jugaso antes

[7:51 AM] **+52 1 662 426 8411:**
> _+52 1 662 467 9029: Ola, busco remplazo para jugar en mi lugar en ping pong, siempre y cuando no haya jugaso antes_
Dile al profe Daniel el de estadística

[7:51 AM] **+52 1 662 426 8411:** [Sticker]

[7:52 AM] **+52 1 662 467 9029:**
> _+52 1 662 426 8411: Dile al profe Daniel el de estadística_
El si jugó que no?

[7:52 AM] **+52 1 662 426 8411:** No

[7:52 AM] **+52 1 662 426 8411:** En el torneo no

[7:57 AM] **+52 1 662 335 9011:**
> _+52 1 662 426 8411: Dile al profe Daniel el de estadística_
Cabra 🦅

[8:20 AM] **+52 1 662 142 7436:**
> _+52 1 662 467 9029: Ola, busco remplazo para jugar en mi lugar en ping pong, siempre y cuando no haya jugaso antes_
Yoo

[8:21 AM] **+52 1 662 142 7436:** _This message was deleted_

[8:21 AM] **+52 1 662 142 7436:** Me inscribi y no sali en el torneo. 👎👎👎👎

[9:17 AM] **+52 1 662 296 4977:** Oigan si hay clases con el profe de estadística Daniel

[9:18 AM] **+52 1 662 335 9011:** [Sticker]

[9:20 AM] **+52 1 662 296 4977:** Al final la cancelo

[9:21 AM] **+52 1 662 296 4977:** Pero que mañana si hay

[9:35 AM] **+52 1 662 637 5722:** Los del Ajedrez ya pueden ir pasando

[9:46 AM] **+52 1 662 142 7436:**
> _+52 1 662 637 5722: Los del Ajedrez ya pueden ir pasando_
[Sticker]

[10:01 AM] **+52 1 662 102 6188:**
> _+52 1 662 296 4977: Pero que mañana si hay_
Examen?

[10:04 AM] **+52 1 662 171 1159:**
> _+52 1 662 102 6188: Examen?_
No

[10:39 AM] __[System notification]__

[11:54 AM] **+52 1 662 637 5722:** [album message]

[11:54 AM] **+52 1 662 637 5722:** [Image]

[11:54 AM] **+52 1 662 637 5722:** [Image]

[11:54 AM] **+52 1 662 637 5722:** [Image]

[12:05 PM] **+52 1 662 360 3569:** Hola chicos!! Les recordamos que hoy a partir de las 12 PM en el auditorio empezaremos con el torneo de Smash 👊💥.

No olviden checar las brackets para que vean a qué hora, contra quién y cuándo les toca jugar 👀👀.

También queremos decirles que somos flexibles con los horarios. Sabemos que algunos de ustedes tiene evaluaciones el dia de hoy. Si tienen algún percance y ven que no van a poder llegar justo a la hora de su partida, avísenos y veremos que podemos hacer para arreglarnos! De no avisar, será baja automáticamente. 

Igualmente, si alguien quiere adelantar alguna de sus partidas y ambos jugadores están disponibles, diganos y vemos cómo nos organizamos.

Ya pueden ir entrando 📍

Nos vemos y mucho éxito a todos!! 👊👊👊🔥

[12:33 PM] **+52 1 662 360 3569:**
> _+52 1 662 360 3569: Hola chicos!! Les recordamos que hoy a partir de las 12 PM en el auditorio empezaremos con el torneo de Smash 👊💥.

No olviden checar las brackets para que vean a qué hora, contra quién y cuándo les toca jugar 👀👀.

También queremos decirles que somos flexibles con los horarios. Sabemos que algunos de ustedes tiene evaluaciones el dia de hoy. Si tienen algún percance y ven que no van a poder llegar justo a la hora de su partida, avísenos y veremos que podemos hacer para arreglarnos! De no avisar, será baja automáticamente. 

Igualmente, si alguien quiere adelantar alguna de sus partidas y ambos jugadores están disponibles, diganos y vemos cómo nos organizamos.

Ya pueden ir entrando 📍

Nos vemos y mucho éxito a todos!! 👊👊👊🔥_
Empezando rn!!!

[12:33 PM] **+52 1 662 360 3569:** [Sticker]

[12:52 PM] **+52 1 662 360 3569:** https://www.start.gg/tournament/rompehielos-lcc-2026/event/smash-bros-ultimate-singles/overview

[2:58 PM] **+52 1 662 287 1326:** [Sticker]

[2:58 PM] **+52 1 662 287 1326:**
> _+52 1 662 360 3569: Hola chicos!! Les recordamos que hoy a partir de las 12 PM en el auditorio empezaremos con el torneo de Smash 👊💥.

No olviden checar las brackets para que vean a qué hora, contra quién y cuándo les toca jugar 👀👀.

También queremos decirles que somos flexibles con los horarios. Sabemos que algunos de ustedes tiene evaluaciones el dia de hoy. Si tienen algún percance y ven que no van a poder llegar justo a la hora de su partida, avísenos y veremos que podemos hacer para arreglarnos! De no avisar, será baja automáticamente. 

Igualmente, si alguien quiere adelantar alguna de sus partidas y ambos jugadores están disponibles, diganos y vemos cómo nos organizamos.

Ya pueden ir entrando 📍

Nos vemos y mucho éxito a todos!! 👊👊👊🔥_
Yo llegare unos 30 minutos tarde, soy madaramask de la pool c1 E

[3:08 PM] **+52 1 662 360 3569:**
> _+52 1 662 287 1326: Yo llegare unos 30 minutos tarde, soy madaramask de la pool c1 E_
okis, no te preocupes

[3:08 PM] **+52 1 662 360 3569:** [Sticker]

[3:39 PM] **+52 1 662 360 3569:**
> _+52 1 662 287 1326: Yo llegare unos 30 minutos tarde, soy madaramask de la pool c1 E_
Ya andas por aqui?

[3:47 PM] **+52 1 662 360 3569:**
> _+52 1 662 360 3569: Ya andas por aqui?_
[Sticker]

[3:50 PM] **+52 1 662 287 1326:**
> _+52 1 662 360 3569: Ya andas por aqui?_
YA LLEGUE VOY CORRIENDO

[3:50 PM] **+52 1 662 287 1326:** [Sticker]

[3:50 PM] **+52 1 662 287 1326:**
> _+52 1 662 360 3569: Sticker_
Aaa estoy afuera de mate ya

[3:50 PM] **+52 1 662 287 1326:** Ya voy llendo al auditorio

[3:50 PM] **+52 1 662 287 1326:** Estaba hasta la otra punta

[3:50 PM] **+52 1 662 287 1326:** [Sticker]

[3:52 PM] **+52 1 662 335 9011:**
> _+52 1 662 360 3569: Sticker_
🥀

[3:54 PM] **+52 1 662 360 3569:**
> _+52 1 662 287 1326: Estaba hasta la otra punta_
Okis

[3:54 PM] **+52 1 662 360 3569:** @~Rosario Luna vas contra él, andas aqui?

[3:54 PM] **+52 1 662 287 1326:** Ya llegue

[4:31 PM] **+52 1 662 501 3191:** EL POOL 4 YA VA A INICIAR, por favor de estar presentes

[4:31 PM] **+52 1 667 973 4142:** Mañana hay algo?

[4:33 PM] **+52 1 662 501 3191:**
> _+52 1 667 973 4142: Mañana hay algo?_
Sip, finalizar smash, trivia (que habrán premios igual) y premiaciones

[5:04 PM] **+52 1 662 367 8720:** Hola compañeros, para hacerles válido el culturest, favor de traer la hojita impresa que les da el portal en su registro para el día de mañana

[5:24 PM] **+52 1 644 462 3216:** A que hora se va a entregar eso?

[5:24 PM] **+52 1 662 449 3477:**
> _+52 1 662 367 8720: Hola compañeros, para hacerles válido el culturest, favor de traer la hojita impresa que les da el portal en su registro para el día de mañana_
a la hora de la premiacion tendremos la caja para que metan su papelito

[7:53 PM] **+52 1 662 360 3569:** Chicos muchísimas gracias por asistir al evento de hoy 🥹! Todo un éxito! 👊💥

Como sabrán, quedan por jugar algunas partidas de los brackets de hoy 🙂. Esas partidas se jugarán de 10am a 11am, favor de estar puntuales porfis! Tenemos el tiempo contado! ⏱️

De 11am a 2pm se jugará el top 8! Por favor asistan todos para apoyar a todos los jugadores, se va a poner bien curado jeje 🙂🍄!!!

[8:00 PM] **+52 1 662 367 8720:** Después del smash, recuerden que tenemos el kahoot/la trivia que también se va a premiar!

La premiacion sería justo después de eso. 
Quisiéramos apresurarla para estar a tiempo para la comida, no se vayan a ir a temprano. 😛

[8:01 PM] **+52 1 662 367 8720:** [Sticker]

[8:01 PM] **+52 1 662 412 0821:** De que es el kahoot? Osea de lcc, pero del lore? Materias?

[8:08 PM] **+52 1 662 501 3191:**
> _+52 1 662 412 0821: De que es el kahoot? Osea de lcc, pero del lore? Materias?_
De lcc y cosas de la unison en general

[8:12 PM] **+52 1 631 125 1255:** es de publico abierto?

[8:12 PM] **+52 1 631 125 1255:** o ya pasaron las inscripciones

[8:12 PM] **+52 1 631 125 1255:** [Sticker]

[8:13 PM] **+52 1 634 109 6592:** @~Chema Nuñez vas a vender chilaquiles en el kahoot?

[8:14 PM] **+52 1 662 467 9029:**
> _+52 1 631 125 1255: es de publico abierto?_
Si

[8:14 PM] **+52 1 631 125 1255:** [Sticker]

[8:14 PM] **+52 1 631 125 1255:** no vendo chilaquiles en general

[8:14 PM] **+52 1 631 125 1255:**
> _+52 1 662 467 9029: Si_
yyyyy mamaron

[8:14 PM] **+52 1 631 125 1255:** [Sticker]

[8:14 PM] **+52 1 662 501 3191:**
> _+52 1 631 125 1255: yyyyy mamaron_
prohibido la entrada a los cavernicolas de lcc

[8:14 PM] **+52 1 631 125 1255:** nomas llevo 7 semestres

[8:14 PM] **+52 1 631 125 1255:** en la uni si llevo 11 ya

[8:14 PM] **+52 1 631 125 1255:** pero equis

[8:14 PM] **+52 1 662 501 3191:**
> _+52 1 631 125 1255: en la uni si llevo 11 ya_
[Sticker]

[8:15 PM] **+52 1 631 125 1255:** de hecho me llamo chema unison

[8:24 PM] **+52 1 662 165 5994:** Que van a dar de comer mañana?

[8:25 PM] **+52 1 662 360 3569:**
> _+52 1 662 165 5994: Que van a dar de comer mañana?_
adivina 🙂

[8:25 PM] **+52 1 662 165 5994:**
> _+52 1 662 360 3569: adivina 🙂_
Pizza

[8:25 PM] **+52 1 662 431 2924:** den ceviche

[8:25 PM] **+52 1 662 332 3680:**
> _+52 1 662 165 5994: Que van a dar de comer mañana?_
Mandarinas

[8:27 PM] **+52 1 634 109 6592:** Agua chile

[8:27 PM] **+52 1 662 467 9029:**
> _+52 1 662 332 3680: Mandarinas_
AJJAJSJS

[8:30 PM] **+52 1 631 125 1255:**
> _+52 1 662 431 2924: den ceviche_
[Sticker]

[8:30 PM] **+52 1 631 125 1255:** [Sticker]

[8:30 PM] **+52 1 631 125 1255:** [Sticker]

[8:32 PM] **+52 1 662 476 3432:**
> _+52 1 662 431 2924: den ceviche_
De salchicha🥹

[8:32 PM] **+52 1 662 340 5659:**
> _+52 1 662 476 3432: De salchicha🥹_
nmms mejor den cagada

[8:32 PM] **+52 1 662 340 5659:** [Sticker]

[8:32 PM] **+52 1 662 367 8720:**
> _+52 1 662 165 5994: Pizza_
y papitas

[8:32 PM] **+52 1 662 367 8720:** [Sticker]

[8:33 PM] **+52 1 662 367 8720:**
> _+52 1 631 125 1255: es de publico abierto?_
público abierto lccianos

[8:33 PM] **+52 1 662 332 3680:** A qué hora comienzan las premiaciónes?

[8:33 PM] **+52 1 631 125 1255:** ya son w

[8:33 PM] **+52 1 631 125 1255:** correle al auditorio

[8:33 PM] **+52 1 662 367 8720:** pobre de la persona que meta a alguien del ith… @~Angel

[8:33 PM] **+52 1 631 125 1255:** ganaste premio al q más le quiero dar unos besotes

[8:34 PM] **+52 1 662 367 8720:**
> _+52 1 662 332 3680: A qué hora comienzan las premiaciónes?_
se tiene pensado a las 3, pero entre  antes mejor

[8:34 PM] **Remil:** Den premios tarjetas de la Play store

[8:34 PM] **+52 1 631 125 1255:** milagro no dijo d magic el cabron

[8:35 PM] **+52 1 662 501 3191:**
> _+52 1 662 367 8720: pobre de la persona que meta a alguien del ith… @~Angel_
We si lloro

[8:35 PM] **+52 1 662 501 3191:** [Sticker]

[8:36 PM] **+52 1 631 125 1255:** estaria muy wason q alguien del ith gane el kahoot d lcc y unison, en el rompehielos de lcc de unison

[8:37 PM] **+52 1 631 125 1255:** [Sticker]

[8:37 PM] **+52 1 662 449 3477:**
> _+52 1 662 165 5994: Que van a dar de comer mañana?_
mañana van a ver

[8:38 PM] **+52 1 662 449 3477:** ahorita acabo de terminar con sonia y le pusimos mucho corazón a todo

[8:38 PM] **+52 1 662 449 3477:** ojalá aprecien todo lo que se hace chicas

[8:38 PM] **+52 1 662 449 3477:** ojalá mañana puedas disfrutar todo

[8:38 PM] **+52 1 662 142 7436:**
> _+52 1 662 449 3477: ahorita acabo de terminar con sonia y le pusimos mucho corazón a todo_
Les goo

[8:38 PM] **+52 1 631 125 1255:** animo amiga, una pena por la ruptura de tu relación

[8:38 PM] **+52 1 631 125 1255:** [Sticker]

[8:38 PM] **+52 1 662 426 6410:** JAJAJAJAJJAAJJAJAJAJAJAJ

[8:39 PM] **+52 1 662 449 3477:** a

[8:39 PM] **+52 1 662 449 3477:** eres un tonto

[8:39 PM] **+52 1 631 125 1255:** JAJDAJDJAJDJAJDAJDJA

[8:39 PM] **+52 1 662 449 3477:** mañana pura nada te daré

[8:39 PM] **+52 1 662 449 3477:** [Sticker]

[8:39 PM] **+52 1 631 125 1255:** [Sticker]

[8:40 PM] **+52 1 662 165 5994:**
> _+52 1 662 367 8720: y papitas_
Y 4loko?

[8:40 PM] **+52 1 662 335 9011:**
> _+52 1 662 367 8720: pobre de la persona que meta a alguien del ith… @~Angel_
Okey Fer 🥀...

[8:40 PM] **+52 1 662 335 9011:** KSKSKAKAKAKAK

[8:40 PM] **+52 1 55 5473 2571:**
> _+52 1 662 165 5994: Y 4loko?_
joder q plan

[8:41 PM] **+52 1 662 399 2340:**
> _+52 1 662 165 5994: Que van a dar de comer mañana?_
Aguachile y camarones deshidratados

[8:42 PM] **+52 1 662 367 8720:**
> _+52 1 631 125 1255: animo amiga, una pena por la ruptura de tu relación_
wow

[8:42 PM] **+52 1 662 399 2340:**
> _+52 1 662 399 2340: Aguachile y camarones deshidratados_
Y de bebida tepache

[9:03 PM] **+52 1 662 332 3680:**
> _+52 1 631 125 1255: animo amiga, una pena por la ruptura de tu relación_
JAJDJAJSJDJAJJAD

[9:30 PM] **+52 1 662 501 3191:** Buenas noches compañeritos, quien va a participar en el Kahoot? La razón de la pregunta es porque es necesario comprar un plan para tener mayor capacidad de personas dentro del Kahoot, por lo tanto si es neceasario saber cuantas personas aproximadamente participaran para saber como administrar correctamente.

[9:31 PM] **+52 1 662 501 3191:** **Poll: Quien va a participar en el kahoot?**
- Yo
- No

[9:32 PM] **+52 1 662 367 8720:** puedo participar si yo hice las preguntas ?

[9:32 PM] **+52 1 662 637 5722:** Puedo participar de manera remota?

[9:32 PM] **+52 1 662 637 5722:** Chambeo a esa hora

[9:32 PM] **+52 1 662 367 8720:** do

[9:32 PM] **+52 1 662 367 8720:** es broma no se

[9:33 PM] **+52 1 662 367 8720:** tu si, pq nos diste tableros de ajedrez ❤️

[9:33 PM] **+52 1 662 206 2716:** Donde va a ser el precopeo para las premiaciones?

[9:33 PM] **+52 1 662 206 2716:** [Sticker]

[9:33 PM] **+52 1 662 367 8720:** ?

[9:33 PM] **+52 1 662 501 3191:**
> _+52 1 662 501 3191: [poll_creation]_
@~Dania Vega pon @all

[9:34 PM] **+52 1 662 332 3680:**
> _+52 1 662 206 2716: Donde va a ser el precopeo para las premiaciones?_
Afuera del CC

[9:34 PM] **+52 1 662 449 3477:**
> _+52 1 662 501 3191: [poll_creation]_
@all

[9:34 PM] **+52 1 662 637 5722:**
> _+52 1 662 206 2716: Donde va a ser el precopeo para las premiaciones?_
en el techo de lcc

[9:34 PM] __[System notification]__

[9:36 PM] **+52 1 633 134 8806:** @~Chema Nuñez QUE ESTA PASANDO

[9:37 PM] **+52 1 662 467 9029:**
> _+52 1 662 637 5722: Chambeo a esa hora_
Curiosamente creo q no seran cosas q podamos sacar de chatgpt

[9:37 PM] **+52 1 662 467 9029:** Asi q no deberia haber mucho problema

[9:38 PM] **+52 1 662 637 5722:** Ua entonces yo sí

[9:42 PM] **+52 1 662 467 9029:** Ya pueden desfijar el mensaje de los grupos de los concursos

[9:42 PM] **+52 1 662 637 5722:** Alguien sabe si Mireles va a dar clases mañana?

[10:08 PM] **+52 1 662 224 3927:**
> _+52 1 662 501 3191: Buenas noches compañeritos, quien va a participar en el Kahoot? La razón de la pregunta es porque es necesario comprar un plan para tener mayor capacidad de personas dentro del Kahoot, por lo tanto si es neceasario saber cuantas personas aproximadamente participaran para saber como administrar correctamente._
No lo compres!!!

[10:09 PM] **+52 1 662 224 3927:** Hay profes que tienen cuenta chila, checo si todavía está vigente la mía

[10:09 PM] **+52 1 662 224 3927:** Aguanta

[10:09 PM] **+52 1 662 501 3191:**
> _+52 1 662 224 3927: Hay profes que tienen cuenta chila, checo si todavía está vigente la mía_
Muchas gracias profesor ❤️❤️❤️

[10:09 PM] **+52 1 662 340 5659:** que raro, Eduardo carreando

[10:09 PM] **+52 1 662 340 5659:** nadie lo ve venir

[10:09 PM] **+52 1 662 340 5659:** [Sticker]

[10:10 PM] **+52 1 662 367 8720:** [Sticker]

---

## September 4, 2026

[7:46 AM] **+52 1 662 449 3477:** buen día gente por temas de tiempo, las horas de adelantarán:
1 kahoot 
2 premiacion
3 comida

[7:46 AM] **+52 1 662 449 3477:** [Sticker]

[7:46 AM] **+52 1 662 449 3477:** prefieren una hora antes o como estaba

[7:47 AM] **+52 1 662 637 5722:** como estaba

[7:47 AM] **+52 1 662 449 3477:** **Poll: que se adelante una hora los eventos?**
- si
- no

[7:51 AM] **+52 1 662 467 9029:**
> _+52 1 662 449 3477: [poll_creation]_
No qué? si de todos modos tienen clases desde las 9 por lo menos

[7:52 AM] **+52 1 662 367 8720:**
> _+52 1 662 467 9029: No qué? si de todos modos tienen clases desde las 9 por lo menos_
pues entonces para que es la pregunta

[8:01 AM] **+52 1 662 467 9029:** De buena onda

[8:10 AM] **+52 1 662 367 8720:** que bobo

[8:12 AM] **+52 1 662 476 3432:**
> _+52 1 662 367 8720: que bobo_
[GIF]

[8:44 AM] **+52 1 662 460 2019:**
> _+52 1 662 476 3432: Video_
[Sticker]

[8:45 AM] **+52 1 662 460 2019:** [sticker-pack message]

[8:45 AM] **+52 1 662 460 2019:** [Sticker]

[10:00 AM] **+52 1 662 467 9029:** Le debo $255 al Angel

[10:06 AM] **+52 1 662 360 3569:** HOY FINALES DE SMASH!!! 👊💥🍄👩‍🔧🦔⚔️

Chicos les recuerdo que hoy es la final del torneo de Smash Ultimate!!

Terminaremos el bracket de ayer a partir de las 10am, los que quedaron pendientes estén presentes a esa hora por favor 🙂👊! En caso de no poder estar presente en el tiempo acordado, avísenme y vemos qué show 🙂

Top 8 inicia mas tardar a las 11am, se jugará en varios setups para que vaya más fluido. Si vemos que vamos bien con el tiempo, intentaremos poner la mayoría de las partidas en la pantalla grande! 📺

Les agradecemos a todos de nuevo por haber participado 🥹! Mucho éxito a todos!! 🦔⚔️👩‍🔧🐢👾🎮👊🔥💥🙂

[10:07 AM] **+52 1 662 360 3569:** [Sticker]

[10:07 AM] **+52 1 662 467 9029:** [Sticker]

[10:16 AM] **+52 1 662 206 2716:** [Sticker]

[10:20 AM] **+52 1 662 412 0821:** [Sticker]

[10:23 AM] **+52 1 662 341 2644:** [Sticker]

[10:30 AM] **+52 1 662 467 9029:** Oigan ya soy admin y tengo q ser responsable, asi q no puedo spamear

[10:30 AM] **+52 1 662 467 9029:** Pero Team Angel

[10:30 AM] **+52 1 662 360 3569:** [Sticker]

[10:30 AM] **+52 1 662 467 9029:** (Team angel)⁸⁰

[10:30 AM] **+52 1 637 117 9366:** [Sticker]

[10:32 AM] **+52 1 662 467 9029:** Hey

[10:32 AM] **+52 1 662 467 9029:** Que grosero Chema

[10:34 AM] **+52 1 662 206 6192:** Ese golpe de estado q we

[10:35 AM] **+52 1 631 125 1255:** eres alumno activo de la carrera en ciencias de la computación?

[10:35 AM] **+52 1 662 206 6192:**
> _+52 1 631 125 1255: eres alumno activo de la carrera en ciencias de la computación?_
Denle un abrazo a este hombre si lo ven por el pasillo, necesita amor

[10:36 AM] **+52 1 662 373 9949:**
> _+52 1 631 125 1255: eres alumno activo de la carrera en ciencias de la computación?_
Yo si

[10:36 AM] **+52 1 662 373 9949:** Y me quitaste

[10:36 AM] **+52 1 662 206 6192:** Lmao

[10:36 AM] **+52 1 631 125 1255:** mmm ya

[10:36 AM] **+52 1 631 125 1255:** okei

[10:36 AM] **+52 1 631 125 1255:** y la otra

[10:36 AM] **+52 1 631 125 1255:** eres vocal designado por tu generación?

[10:36 AM] **+52 1 631 125 1255:** alguien quiteme el admin

[10:36 AM] **+52 1 662 467 9029:** Que bonita la gente responsable

[10:36 AM] **+52 1 631 125 1255:** [Sticker]

[10:37 AM] **+52 1 662 373 9949:**
> _+52 1 631 125 1255: eres vocal designado por tu generación?_
Lo eres tú?

[10:37 AM] **+52 1 662 467 9029:**
> _+52 1 631 125 1255: alguien quiteme el admin_
Tu eres vocal pero vocal griega

[10:37 AM] **+52 1 662 467 9029:** Eres la Alfa

[10:38 AM] **+52 1 662 373 9949:** Tocó reportar el chemangarro a rectoria

[10:38 AM] **+52 1 662 206 6192:** [Sticker]

[10:38 AM] **+52 1 662 206 6192:**
> _+52 1 662 206 6192: Sticker_
El chema:

[10:38 AM] **+52 1 631 125 1255:** ya no soy admin w

[10:38 AM] **+52 1 631 125 1255:** de q hablas

[10:38 AM] **+52 1 662 373 9949:**
> _+52 1 662 206 6192: El chema:_
Mucho pelo

[10:38 AM] **+52 1 662 206 6192:**
> _+52 1 662 373 9949: Mucho pelo_
Verdad

[10:38 AM] **+52 1 662 373 9949:**
> _+52 1 631 125 1255: ya no soy admin w_
Borra la cuenta

[10:39 AM] **+52 1 662 206 6192:** Grupo en decadencia

[10:40 AM] **+52 1 662 360 3569:** Alguien conoce a la persona con el nickname "Lio" en el torneo de smash??

[10:40 AM] **+52 1 662 360 3569:** [Sticker]

[11:33 AM] **+52 1 662 699 4499:** pregunta seria, puedo ir a comer aun que no me haya inscrito a nada?

[11:33 AM] **+52 1 662 699 4499:** [Sticker]

[11:33 AM] **+52 1 662 449 3477:**
> _+52 1 662 699 4499: pregunta seria, puedo ir a comer aun que no me haya inscrito a nada?_
Siiii

[11:34 AM] **+52 1 662 449 3477:** Son para todos los estudiantes de lcc

[11:34 AM] **+52 1 662 637 5722:**
> _+52 1 662 699 4499: pregunta seria, puedo ir a comer aun que no me haya inscrito a nada?_
Pide perdón,no permiso

[11:34 AM] **+52 1 662 699 4499:** donde sera lo de la comida

[11:43 AM] **+52 1 662 206 6192:**
> _+52 1 662 449 3477: Son para todos los estudiantes de lcc_
q hay d los egresados?

[11:46 AM] **+52 1 662 206 6192:** [Sticker]

[11:46 AM] **+52 1 662 335 9011:** [Sticker]

[11:54 AM] **+52 1 662 106 3537:**
> _+52 1 662 224 3927: Hay profes que tienen cuenta chila, checo si todavía está vigente la mía_
es usted alumno activo de ciencias de la computación?

[11:55 AM] **+52 1 662 360 3569:** Chicos, ya se está jugando la final del torneo de Smash!

[11:55 AM] **+52 1 662 360 3569:** [Sticker]

[11:55 AM] **+52 1 662 699 4499:**
> _+52 1 662 699 4499: donde sera lo de la comida_
de q en el auditorio o en el cc o donde

[11:55 AM] **+52 1 662 206 6192:** que se comunique con alguna cabecilla de esta organizacion

[11:56 AM] **+52 1 662 106 3537:**
> _+52 1 662 206 6192: que se comunique con alguna cabecilla de esta organizacion_
de esta mafia

[11:58 AM] **+52 1 662 206 6192:** al final si cambió la jerarquia de poder

[11:58 AM] **+52 1 662 206 6192:** [Sticker]

[12:02 PM] **+52 1 631 125 1255:** nomas estan ardidos pq los baketones ya no son el 70% de los admins del grupo

[12:02 PM] **+52 1 631 125 1255:** [Sticker]

[12:03 PM] **+52 1 662 206 6192:**
> _+52 1 631 125 1255: nomas estan ardidos pq los baketones ya no son el 70% de los admins del grupo_
eso q we

[12:13 PM] **+52 1 662 206 3493:**
> _+52 1 631 125 1255: nomas estan ardidos pq los baketones ya no son el 70% de los admins del grupo_
qué pasó Chema cómo amaneciste

[12:18 PM] **+52 1 662 402 3568:**
> _+52 1 631 125 1255: nomas estan ardidos pq los baketones ya no son el 70% de los admins del grupo_
y luego

[12:18 PM] **+52 1 631 125 1255:** ardido

[12:18 PM] **+52 1 631 125 1255:** m quitaron admin

[12:18 PM] **+52 1 631 125 1255:** grrrr

[12:19 PM] **+52 1 662 373 9949:**
> _+52 1 662 206 3493: qué pasó Chema cómo amaneciste_
Se levantó de la cama con el pelón izquierdo

[12:19 PM] **+52 1 662 149 5058:** Se preparó

[12:20 PM] **+52 1 662 106 3537:** neta chichi

[12:21 PM] **+52 1 645 107 9121:** por favor café afuera del auditorio

[12:21 PM] **+52 1 645 107 9121:** 😔😔

[12:21 PM] **+52 1 631 125 1255:** camara culeros, se pusieron de acuerdo más rapido los baketones pa tirarme tierra q pa una juntada

[12:21 PM] **+52 1 631 125 1255:** [Sticker]

[12:21 PM] **+52 1 644 404 0378:** A poco regalan cafe

[12:21 PM] **+52 1 633 134 8806:**
> _+52 1 631 125 1255: camara culeros, se pusieron de acuerdo más rapido los baketones pa tirarme tierra q pa una juntada_
Pelón

[12:26 PM] **+52 1 631 125 1255:** [Sticker]

[1:09 PM] **+52 1 662 402 3568:**
> _+52 1 631 125 1255: camara culeros, se pusieron de acuerdo más rapido los baketones pa tirarme tierra q pa una juntada_
vamos a san carlos we

[1:09 PM] **+52 1 631 125 1255:** bueno va

[1:22 PM] **+52 1 662 467 9029:** [Video]

[1:24 PM] **+52 1 662 360 3569:** Chicos, ya va a iniciar la trivia!!!

[1:24 PM] **+52 1 662 360 3569:** [Sticker]

[1:24 PM] **+52 1 662 360 3569:** [Sticker]

[1:24 PM] **+52 1 662 360 3569:** [Sticker]

[1:25 PM] **+52 1 662 360 3569:** En el auditorio de matematicas

[1:25 PM] **+52 1 662 360 3569:** [Sticker]

[1:47 PM] **+52 1 662 287 1326:** Buenas, alguien me podria decir si no es de afuerzas entregar hoy la hoja para los puntos culturest?

[1:47 PM] **+52 1 662 287 1326:** Por ejemplo si la podria entregar el lunes o asi

[2:56 PM] **+52 1 662 360 3569:** El lunes se entregará la caja, mientras siga en lcc podrán meter el papelito en la caja

[2:56 PM] **+52 1 662 360 3569:** 🙂

[2:56 PM] **+52 1 662 360 3569:** La pondremos en un lugar visible en el edificio

[4:11 PM] **+52 1 662 299 4587:** Alguien sigue en el edificio?

[4:11 PM] **+52 1 662 522 5777:**
> _+52 1 662 299 4587: Alguien sigue en el edificio?_
Por?

[4:11 PM] **+52 1 662 299 4587:** Queria saber si sigue abierto

[4:12 PM] **+52 1 662 335 9011:** Según yo sí (me fui como hace 15 mins hehehe)

[4:12 PM] **+52 1 662 335 9011:** [Sticker]

[6:04 PM] **+52 1 662 446 0922:**
> _+52 1 662 360 3569: El lunes se entregará la caja, mientras siga en lcc podrán meter el papelito en la caja_
Yo entrego la hoja el lunes entonces

[6:04 PM] **+52 1 662 446 0922:** [Sticker]

[7:35 PM] **+52 1 662 449 3477:** [Image] amigas checando los boletos de culturest algunos aparecen sin nombre, es un error que a veces sucede al momento de mandar a imprimir, y según yo no funcionan

[7:51 PM] **+52 1 662 449 3477:** llegando a mi casa les pongo que papelitos si tenían los nombres para los que están con pendiente

[7:51 PM] **+52 1 662 449 3477:** [Sticker]

[9:10 PM] **+52 1 662 165 5994:** Oigan, no era hoy el rompehielos?

[9:10 PM] **+52 1 662 165 5994:** O cambio la fecha?

[9:10 PM] **+52 1 662 449 3477:** nop se cambió de fecha

[9:10 PM] **+52 1 662 299 4587:** 18 septiembre

[9:10 PM] **+52 1 662 165 5994:** Ahhh bueno, más tiempo para conseguir la feria para que salga bien?

[9:10 PM] **+52 1 662 165 5994:** Aceptan donaciones?

[9:10 PM] **+52 1 662 341 2644:** van a dar las bebidas q preparan? O tenemos q llevar lo de nosotros

[9:11 PM] **+52 1 662 449 3477:**
> _+52 1 662 165 5994: Aceptan donaciones?_
SIIIIIIIII

[9:11 PM] **+52 1 662 449 3477:**
> _+52 1 662 341 2644: van a dar las bebidas q preparan? O tenemos q llevar lo de nosotros_
ustedes deben de llevar amigo

[9:11 PM] **+52 1 662 449 3477:** no somos fuente de sodas

[9:11 PM] **+52 1 662 449 3477:** [Sticker]

[9:11 PM] **+52 1 662 165 5994:** Y rocola?

[9:11 PM] **+52 1 662 412 8540:** No va a haber bartender?

[9:12 PM] **+52 1 634 109 6592:** No van a dar shots de bienvenida en la entrada??

[9:12 PM] **+52 1 662 165 5994:**
> _+52 1 662 412 8540: No va a haber bartender?_
que buen rompehielos fue ese

[9:12 PM] **+52 1 662 412 8540:**
> _+52 1 662 449 3477: no somos fuente de sodas_
pero si es fiesta ):

[9:12 PM] **+52 1 662 341 2644:** No van a dar nada?

[9:12 PM] **+52 1 662 341 2644:** [Sticker]

[9:12 PM] **+52 1 662 412 8540:**
> _+52 1 662 165 5994: que buen rompehielos fue ese_
La verdad es que si

[9:12 PM] **+52 1 634 109 6592:**
> _+52 1 662 165 5994: que buen rompehielos fue ese_
Ei

[9:12 PM] **+52 1 662 412 8540:** Y el tipo era bueno preparando bebidas

[9:12 PM] **+52 1 662 412 8540:** No podemos juntar dinero y contratarlo otra vez?

[9:13 PM] **+52 1 662 449 3477:** con todo gusto pueden organizar lo que quieran

[9:14 PM] **+52 1 662 399 2340:**
> _+52 1 662 449 3477: con todo gusto pueden organizar lo que quieran_
Siempre y cuando pongan la feria ustedes 🫪

[9:14 PM] **+52 1 662 341 2644:**
> _+52 1 662 449 3477: con todo gusto pueden organizar lo que quieran_
Pero q van a dar

[9:14 PM] **+52 1 662 341 2644:** [Sticker]

[9:14 PM] **+52 1 662 341 2644:**
> _+52 1 662 399 2340: Siempre y cuando pongan la feria ustedes 🫪_
pues por algo se cobraban los bazares no?

[9:14 PM] **+52 1 662 450 9504:** Yo puedo dar un hola

[9:14 PM] **+52 1 662 450 9504:** [Sticker]

[9:15 PM] **+52 1 662 399 2340:**
> _+52 1 662 341 2644: pues por algo se cobraban los bazares no?_
Estás viendo que la unison casi está haciendo cobro de piso

[9:16 PM] **+52 1 662 340 5659:**
> _+52 1 662 341 2644: Pero q van a dar_
unas aguas locas y shots de tonayan de bienvenida

[9:16 PM] **+52 1 662 165 5994:**
> _+52 1 662 340 5659: unas aguas locas y shots de tonayan de bienvenida_
Como todos los años

[9:16 PM] **+52 1 662 399 2340:**
> _+52 1 662 341 2644: Pero q van a dar_
Si topas los módulos de  hidratación de la uni así de dudosa procedencia

[9:17 PM] **+52 1 662 637 5722:**
> _+52 1 662 341 2644: van a dar las bebidas q preparan? O tenemos q llevar lo de nosotros_
un garrafón de agualoca

[9:19 PM] **+52 1 662 165 5994:** Muchas gracias por si gran esfuerzo en esta semana, se la rifaron con los eventos y los premios, pusieron bien alta la barra para la siguiente gene✨✨

[9:19 PM] **+52 1 662 142 7436:** Los de primero entran gratis

[9:19 PM] **+52 1 662 412 8540:**
> _+52 1 662 165 5994: Muchas gracias por si gran esfuerzo en esta semana, se la rifaron con los eventos y los premios, pusieron bien alta la barra para la siguiente gene✨✨_
Owen de que demonios hablas

[9:19 PM] **+52 1 662 412 8540:**
> _+52 1 662 142 7436: Los de primero entran gratis_
Hay cover?

[9:20 PM] **+52 1 662 332 3680:**
> _+52 1 662 412 8540: Hay cover?_
Si, 7000 peseis

[9:20 PM] **+52 1 662 399 2340:**
> _+52 1 662 412 8540: Hay cover?_
Robux

[9:25 PM] **+52 1 662 165 5994:**
> _+52 1 662 332 3680: Si, 7000 peseis_
De ahí sale toda la noche mexicana

[9:42 PM] **+52 1 662 102 6188:**
> _+52 1 662 412 8540: pero si es fiesta ):_
Yo todavía tengo pisto del año pasado

[9:43 PM] **+52 1 662 102 6188:** Añejado

[9:43 PM] **+52 1 662 165 5994:**
> _+52 1 662 102 6188: Yo todavía tengo pisto del año pasado_
Mejor jajajajaj

[9:44 PM] **+52 1 662 637 5722:**
> _+52 1 662 102 6188: Yo todavía tengo pisto del año pasado_
Yo aún tengo la botella que me dieron

[9:44 PM] **+52 1 662 165 5994:** Entonces será con temática tambien la fiesta de este año?

[9:44 PM] **+52 1 662 341 2644:**
> _+52 1 662 102 6188: Yo todavía tengo pisto del año pasado_
Lo hubieras dado para que se lo tomaran en la fiesta de prueba de hoy

[9:44 PM] **+52 1 662 341 2644:** q menso verdad

[9:45 PM] **+52 1 633 335 6651:** Rompe hielos sin raza de lcc

[9:45 PM] **+52 1 662 340 5659:**
> _+52 1 633 335 6651: Rompe hielos sin raza de lcc_
[Sticker]

[9:45 PM] **+52 1 633 335 6651:** Nadie invitado jajaja

[9:45 PM] **+52 1 662 341 2644:** es que es prueba pues

[9:45 PM] **+52 1 662 341 2644:** Para ver cómo sale el chilo

[9:46 PM] **+52 1 662 341 2644:** [Sticker]

[9:46 PM] **+52 1 662 341 2644:**
> _+52 1 662 341 2644: Para ver cómo sale el chilo_
(No va salir)

[9:46 PM] **+52 1 662 340 5659:** sale mal

[9:46 PM] **+52 1 662 340 5659:** no saben tomar

[9:48 PM] **+52 1 662 102 6188:** Galones de 4loko

[9:48 PM] **+52 1 662 165 5994:**
> _+52 1 662 102 6188: Galones de 4loko_
Nuevo trauma generacional

[9:48 PM] **+52 1 633 335 6651:** [Forwarded] Galones de 4loko

[9:56 PM] **+52 1 662 102 3114:** [Forwarded] Galones de 4loko

[9:57 PM] **+52 1 662 165 5994:** [Forwarded] Galones de 4loko

[10:00 PM] **+52 1 662 399 2340:** [Forwarded] Galones de 4loko

[10:09 PM] **+52 1 633 100 5991:** [Forwarded] Galones de 4loko

[10:10 PM] **+52 1 662 341 2644:** [Forwarded] Galones de 4loko

[10:19 PM] **+52 1 662 296 3657:**
> _+52 1 633 335 6651: Rompe hielos sin raza de lcc_
Uniendo el hielo 🔥

[10:20 PM] **+52 1 662 165 5994:**
> _+52 1 662 296 3657: Uniendo el hielo 🔥_
Ya llegamos al punto de hacer rompehielos secretos pa JAJAJ

[10:20 PM] **+52 1 662 296 3657:** [Sticker]

[10:23 PM] **+52 1 662 357 9360:**
> _+52 1 662 341 2644: Lo hubieras dado para que se lo tomaran en la fiesta de prueba de hoy_
Como, no invitaron a los demás?

[10:23 PM] **+52 1 662 357 9360:** [Sticker]

[10:23 PM] **+52 1 662 340 5659:** [Forwarded] Uniendo el hielo 🔥

[10:24 PM] **+52 1 662 341 2644:**
> _+52 1 662 357 9360: Como, no invitaron a los demás?_
no fuimos requeridos

[10:24 PM] **+52 1 633 335 6651:**
> _+52 1 662 357 9360: Como, no invitaron a los demás?_
No somos tan chilos

[10:24 PM] **+52 1 662 357 9360:**
> _+52 1 662 341 2644: no fuimos requeridos_
Yo pensé que si los invitaron

[10:24 PM] **+52 1 662 341 2644:** le debemos caer mal a la organizadora

[10:24 PM] **+52 1 662 357 9360:**
> _+52 1 662 341 2644: le debemos caer mal a la organizadora_
Ustedes yo no

[10:24 PM] **+52 1 662 357 9360:** [Sticker]

[10:24 PM] **+52 1 662 165 5994:**
> _+52 1 662 357 9360: Ustedes yo no_
A ti si te invitaron?

[10:25 PM] **+52 1 662 357 9360:** Si pero no pude ir

[10:25 PM] **+52 1 662 357 9360:** Pero tf pensé q si era para todos

[10:25 PM] **+52 1 662 357 9360:** Q bueno q no dije nada aca

[10:25 PM] **+52 1 662 397 6279:** Ojalá invitaran

[10:25 PM] **+52 1 662 340 5659:** _This message was deleted by admin +52 1 662 449 3477_

[10:26 PM] **+52 1 633 335 6651:** Ojalá invitran

[10:26 PM] **+52 1 662 341 2644:** Ojalá invitaran

[10:26 PM] **+52 1 662 165 5994:** Y ahí si estan dando alcohol, snacks y bebidas?

[10:26 PM] **+52 1 631 125 1255:** es q tienen q ser protas

[10:27 PM] **+52 1 631 125 1255:** la de los npc es la q es sin pisto

[10:27 PM] **+52 1 662 165 5994:** Ahhh con razón

[10:27 PM] **+52 1 631 125 1255:** aca tienen hasta fuente d 4loko

[10:27 PM] **+52 1 662 341 2644:**
> _+52 1 631 125 1255: la de los npc es la q es sin pisto_
La de nosotros pues

[10:27 PM] **+52 1 634 109 6592:** Lcc en separación??

[10:27 PM] **+52 1 633 335 6651:** Lcc separación y decadencia

[10:27 PM] **+52 1 633 335 6651:** [Sticker]

[10:27 PM] **+52 1 662 165 5994:**
> _+52 1 634 109 6592: Lcc en separación??_
Divorcio

[10:27 PM] **+52 1 631 125 1255:**
> _+52 1 634 109 6592: Lcc en separación??_
desde q entro nuestra gene w

[10:27 PM] **+52 1 631 125 1255:** [Sticker]

[10:28 PM] **+52 1 662 341 2644:** pq andan silenciando

[10:28 PM] **+52 1 662 341 2644:** [Sticker]

[10:28 PM] **+52 1 662 165 5994:** Pq borran la ubi?, ya estaba pidiendo mi uber

[10:28 PM] **+52 1 662 357 9360:** Pasaron ubi?

[10:29 PM] **+52 1 633 100 5991:** La borró la Dania

[10:29 PM] **+52 1 634 109 6592:**
> _+52 1 633 100 5991: La borró la Dania_
Xd

[10:29 PM] **+52 1 662 341 2644:** como si nuestros teléfonos no tuvieran auto guardado de imágenes

[10:29 PM] **+52 1 662 341 2644:** [Sticker]

[10:30 PM] **+52 1 631 125 1255:** qp gente, se estan ondiando por una fiesta q nada tenia q ver con el rompehielos

[10:30 PM] **+52 1 631 125 1255:** [Sticker]

[10:31 PM] **+52 1 662 332 3680:** Ya había durado buen rato lcc sin problemitas, 1 semanita, récord

[10:31 PM] **+52 1 662 332 3680:** [Sticker]

[10:34 PM] **+52 1 662 102 3114:** Ya duérmanse hdsptm (hijos de santo padre todo mundo)

[10:34 PM] **+52 1 662 102 3114:** Ya es bien noche

[10:34 PM] **+52 1 662 102 3114:** No tienes escuela o q

[10:34 PM] **+52 1 662 399 2340:**
> _+52 1 662 332 3680: Ya había durado buen rato lcc sin problemitas, 1 semanita, récord_
Ya rompan la carta compromiso mejor

[10:34 PM] **+52 1 633 335 6651:**
> _+52 1 662 102 3114: Ya duérmanse hdsptm (hijos de santo padre todo mundo)_
Amigo tu no eres de lcc

[10:34 PM] **+52 1 633 335 6651:** [Sticker]

[10:34 PM] **+52 1 633 335 6651:** [Sticker]

[10:34 PM] **+52 1 633 335 6651:**
> _+52 1 662 332 3680: Ya había durado buen rato lcc sin problemitas, 1 semanita, récord_
Aguanto

[10:35 PM] **+52 1 633 335 6651:** Hola soy el niño del poust

[10:35 PM] **+52 1 662 102 3114:**
> _+52 1 633 335 6651: Amigo tu no eres de lcc_
Amiga no estamos hablando de eso

[10:35 PM] **+52 1 662 102 3114:** [Sticker]

[10:35 PM] **+52 1 662 102 3114:** Mama dijo que ya no mencionaras eso

[10:35 PM] **+52 1 662 102 3114:** SI GENTE

[10:35 PM] **+52 1 662 102 3114:** SI

[10:35 PM] **+52 1 662 102 3114:** SOY ADOPTADO LCCIANO

[10:35 PM] **+52 1 662 102 3114:** Y Q?

[10:35 PM] **+52 1 662 399 2340:** El niño del post > chilaquiles > fiesta clandestina sin lcc

[10:36 PM] **+52 1 662 102 3114:** YO LO TENGO TATUADO EN EL CORAZON

[10:36 PM] **+52 1 662 102 3114:** PODRIAN CAMBIAR MI MATRICULA Y MI OLAN DE ESTUDIOS

[10:36 PM] **+52 1 662 102 3114:** PERO JAMAS DE DONDE VENGO

[10:36 PM] **+52 1 662 102 3114:** NI QUIENES SON LOS REALES

[10:36 PM] **+52 1 662 463 6894:** Cerote>

[10:37 PM] **+52 1 662 350 5885:**
> _+52 1 662 463 6894: Cerote>_
gran aporte amigo marco

[10:50 PM] **+52 1 631 125 1255:**
> _+52 1 662 463 6894: Cerote>_
este es su vocal gente (disfruten lo votado ylm)

[10:50 PM] **+52 1 631 125 1255:**
> _+52 1 662 102 3114: PERO JAMAS DE DONDE VENGO_
q tiene q ver Etchojoa aqui?

[11:17 PM] **+52 1 662 342 4670:** Eitaleee

[11:17 PM] **+52 1 662 342 4670:** Entonces el viernes 18 será el rompehielos??

[11:18 PM] **+52 1 662 342 4670:** [Sticker]

[11:18 PM] **+52 1 662 342 4670:** [Sticker]

[11:18 PM] **+52 1 662 332 3680:** _This message was deleted by admin +52 1 662 268 7744_

[11:19 PM] **+52 1 662 342 4670:** Voy a pedir que te saquen del grupo verás

[11:19 PM] **+52 1 662 342 4670:** [Sticker]

[11:19 PM] **+52 1 662 332 3680:**
> _+52 1 662 342 4670: Voy a pedir que te saquen del grupo verás_
[Sticker]

[11:32 PM] **+52 1 662 350 4258:**
> _+52 1 662 102 3114: YO LO TENGO TATUADO EN EL CORAZON_
tomenle captura y mandenselo al chat de ISI

[11:32 PM] **+52 1 662 350 4258:** [Sticker]

[11:48 PM] **+52 1 662 467 9029:** [Sticker]

[11:49 PM] **+52 1 662 467 9029:** Justo a tiempo

---

## September 5, 2026

[12:17 AM] **+52 1 662 102 3114:**
> _+52 1 662 350 4258: tomenle captura y mandenselo al chat de ISI_
No tienen

[12:18 AM] **+52 1 662 102 3114:** [Sticker]

---

## September 7, 2026

[10:30 AM] **+52 1 662 102 6188:** Hola, Soy el que anduvo tomando fotos unos días la semana pasada, les comparto las fotos que estuve tomando en la búsqueda del tesoro y el torneo de fútbol. Cualquier comentario o si quieren que quite una foto de ustedes del drive me mandan mensaje.

Búsqueda del tesoro:
https://drive.google.com/drive/folders/14jGZIU7vxQibY1-bTgEH-iU9F_flo_k5
Futbol:
https://drive.google.com/drive/folders/17fcQQVQcPSHLy11gju9bQIjOT14MHZYs

[11:09 AM] **+52 1 662 224 3927:** Como si necesitara presentación este criminal

[11:09 AM] **+52 1 662 224 3927:** Larga vida al Santi

[11:09 AM] **+52 1 662 224 3927:** [Sticker]

[11:09 AM] **+52 1 662 224 3927:** [Sticker]

[12:25 PM] **+52 1 662 467 9029:**
> _+52 1 662 102 6188: Hola, Soy el que anduvo tomando fotos unos días la semana pasada, les comparto las fotos que estuve tomando en la búsqueda del tesoro y el torneo de fútbol. Cualquier comentario o si quieren que quite una foto de ustedes del drive me mandan mensaje.

Búsqueda del tesoro:
https://drive.google.com/drive/folders/14jGZIU7vxQibY1-bTgEH-iU9F_flo_k5
Futbol:
https://drive.google.com/drive/folders/17fcQQVQcPSHLy11gju9bQIjOT14MHZYs_
De donde salen estos ganadores

[12:45 PM] **+52 1 662 508 9779:**
> _+52 1 662 102 6188: Hola, Soy el que anduvo tomando fotos unos días la semana pasada, les comparto las fotos que estuve tomando en la búsqueda del tesoro y el torneo de fútbol. Cualquier comentario o si quieren que quite una foto de ustedes del drive me mandan mensaje.

Búsqueda del tesoro:
https://drive.google.com/drive/folders/14jGZIU7vxQibY1-bTgEH-iU9F_flo_k5
Futbol:
https://drive.google.com/drive/folders/17fcQQVQcPSHLy11gju9bQIjOT14MHZYs_
[Sticker]

[12:46 PM] **+52 1 662 449 3477:** [Image]

[12:46 PM] **+52 1 662 449 3477:** [Image] necesito a esta gente donde andan?

[12:47 PM] **+52 1 662 365 9837:** USB 32G

[12:47 PM] **+52 1 662 365 9837:** [Sticker]

[12:47 PM] **+52 1 662 365 9837:** Si no la reclaman es mis

[12:47 PM] **+52 1 662 365 9837:** Mia

[12:48 PM] **+52 1 662 365 9837:** [Sticker]

[12:48 PM] **+52 1 662 449 3477:** es tu momento

[12:48 PM] **+52 1 662 449 3477:** andaré en las mesitas de afuera

[1:16 PM] **+52 1 631 125 1255:**
> _+52 1 662 365 9837: Si no la reclaman es mis_
va a estafarlos con una identidad falsa

[1:46 PM] **+52 1 662 295 0244:** Creo que deje

[1:46 PM] **+52 1 662 295 0244:** Un termo

[1:46 PM] **+52 1 662 295 0244:** En las banquitas afuera de lcc

[1:47 PM] **+52 1 662 295 0244:** Si alguien me lo pudiera guardar lo agradecería

[1:47 PM] **+52 1 662 295 0244:** Es negro

[3:10 PM] **+52 1 662 295 4218:**
> _+52 1 662 449 3477: Image: necesito a esta gente donde andan?_
Hay sorteo?

[3:11 PM] **+52 1 662 637 5722:**
> _+52 1 662 449 3477: Image: necesito a esta gente donde andan?_
se puede comprar la camiseta? Quiero una

[3:12 PM] **+52 1 662 449 3477:** tengo planeado cotizar en lugares

[3:12 PM] **+52 1 662 449 3477:** y luego les pasaría la info para quien quiera una

[3:12 PM] **+52 1 662 449 3477:** [Sticker]

[3:12 PM] **+52 1 662 295 4218:**
> _+52 1 662 637 5722: se puede comprar la camiseta? Quiero una_
Yo compro igual

[3:16 PM] **+52 1 662 412 0821:**
> _+52 1 662 449 3477: y luego les pasaría la info para quien quiera una_
[Sticker]

[3:41 PM] **+52 1 662 138 7071:** Hola

[3:41 PM] **+52 1 662 138 7071:** Alguien vio un llavero de rilakuma?

[3:41 PM] **+52 1 662 138 7071:** Ahí en el salón de al lado del cc

[3:52 PM] **+52 1 662 449 3477:** amigas todavía pueden entregar su hoja de culturest

[3:52 PM] **+52 1 662 449 3477:** mañana se irá a dejar la caja

[3:53 PM] **+52 1 662 449 3477:** [Sticker]

[4:15 PM] **+52 1 662 476 3432:**
> _+52 1 662 449 3477: y luego les pasaría la info para quien quiera una_
Yo compro tmbn

[4:15 PM] **+52 1 662 476 3432:** [Sticker]

[4:17 PM] **+52 1 634 113 0073:**
> _+52 1 662 449 3477: y luego les pasaría la info para quien quiera una_
Me interesa

[4:17 PM] **+52 1 634 113 0073:** [Sticker]

[4:22 PM] **+52 1 662 326 0064:** [Sticker]

[4:37 PM] **+52 1 662 522 5777:**
> _+52 1 662 637 5722: se puede comprar la camiseta? Quiero una_
Se pueden comprar también las camisetas de dragoncito 👉👈

[4:37 PM] **+52 1 644 422 2240:** [Sticker]

[4:39 PM] **+52 1 662 350 4258:** saquen la linea de camisetas de waissman de una vez

[4:39 PM] **+52 1 662 350 4258:** pa ir con uniforme  a la uni

[4:39 PM] **+52 1 662 350 4258:** [Sticker]

[4:39 PM] **+52 1 662 449 3477:**
> _+52 1 662 522 5777: Se pueden comprar también las camisetas de dragoncito 👉👈_
@~G_U

[4:39 PM] **+52 1 662 522 5777:**
> _+52 1 662 350 4258: pa ir con uniforme  a la uni_
Marca lcc

[5:21 PM] **+52 1 662 206 6192:**
> _+52 1 662 449 3477: @~G_U_
Srry, ya no soy una cabecilla de LCC 🥴

[5:26 PM] **+52 1 662 224 3927:** Se le subió al Jehu

[5:26 PM] **+52 1 662 224 3927:** Igual que al Braulio

[5:26 PM] **+52 1 662 224 3927:** Nomas entran al posgrado

[5:38 PM] **+52 1 662 206 6192:**
> _+52 1 662 224 3927: Nomas entran al posgrado_
Ahora solo les consigo camisas a los de la MCD

[5:38 PM] **+52 1 662 206 6192:** Donde si soy alumno activo

---

## September 8, 2026

[8:09 AM] **+52 1 662 342 9577:** Alguien se quedó con las raquetas de pingpong con las que se estaba jugando el viernes?

[8:50 AM] **+52 1 662 449 3477:** a las 11 ire q dejar la caja de culturest por si alguien tiene su papelito que me lo dé ahorita

[9:17 AM] **+52 1 662 449 3477:** José alberto vázquez cruz y joaquín alfredo castro cordova repórtese

[9:17 AM] **+52 1 662 449 3477:** _This message was deleted_

[9:57 AM] **+52 1 662 399 2340:**
> _+52 1 662 449 3477: José alberto vázquez cruz y joaquín alfredo castro cordova repórtese_
@~Joaquin Alf 👀

[11:54 AM] **+52 1 662 467 9029:** @~Dania Vega ella es la del grupo de mujeres lcc

[12:07 PM] **+52 1 662 341 2644:** oigan

[12:07 PM] **+52 1 637 117 9366:**
> _+52 1 662 341 2644: oigan_
No

[12:08 PM] **+52 1 662 341 2644:** Me dijo una amiga que el baño de mujeres huele a mota

[12:08 PM] **+52 1 662 341 2644:** [Sticker]

[12:08 PM] **+52 1 662 341 2644:** de q machin

[12:08 PM] **+52 1 662 432 8446:** El del vatos medio olía también

[12:08 PM] **+52 1 662 341 2644:** Qr

[12:08 PM] **+52 1 662 341 2644:** O sea así quieren pedir el cc?

[12:08 PM] **+52 1 662 165 5994:**
> _+52 1 662 432 8446: El del vatos medio olía también_
[Sticker]

[12:08 PM] **Remil:** Es en el espacio que hay entre LCC y la calle

[12:08 PM] **+52 1 662 165 5994:**
> _Remil: Es en el espacio que hay entre LCC y la calle_
Smn, luego se ponen ahí a fumar

[12:09 PM] **Remil:**
> _+52 1 662 341 2644: O sea así quieren pedir el cc?_
Nah, me a tocado ver que casi siempre no son de la carrera

[12:09 PM] **+52 1 662 476 3432:**
> _+52 1 662 341 2644: Me dijo una amiga que el baño de mujeres huele a mota_
Bai bai cc serás extrañado

[12:09 PM] **+52 1 662 463 0131:**
> _+52 1 662 341 2644: Me dijo una amiga que el baño de mujeres huele a mota_
las ventanas están abiertas y siempre fuman atrás de los baños

[12:10 PM] **+52 1 662 467 9029:**
> _+52 1 631 125 1255: qp gente, se estan ondiando por una fiesta q nada tenia q ver con el rompehielos_
This

[12:11 PM] **+52 1 662 467 9029:** Se metió un niño de secundaria o porq hacen un chisme tan forzado?

[12:11 PM] **+52 1 662 467 9029:** Fue una fiesta completamente ajena a lcc y cada quien pagó lo suyo con su propio bolsillo

[12:11 PM] **+52 1 631 125 1255:** okei alex

[12:11 PM] **+52 1 631 125 1255:** volviendo a lo de la mota

[12:11 PM] **+52 1 631 125 1255:** pueden ir a seguridad y reportarlo

[12:11 PM] **+52 1 662 467 9029:** A prdon

[12:11 PM] **+52 1 662 467 9029:** No leí todo

[12:11 PM] **+52 1 631 125 1255:** llegan en greña

[12:13 PM] **+52 1 662 431 2924:**
> _+52 1 662 341 2644: Me dijo una amiga que el baño de mujeres huele a mota_
si

[12:16 PM] **+52 1 662 467 9029:** Se fueron :(

[12:16 PM] **+52 1 662 522 5777:**
> _+52 1 662 467 9029: @~Dania Vega ella es la del grupo de mujeres lcc_
Porque no hay grupo de hombres lcc?

[12:17 PM] **+52 1 662 467 9029:** Es cierto

[12:17 PM] **+52 1 662 467 9029:** 🎉

[12:17 PM] **+52 1 662 671 6226:**
> _+52 1 662 522 5777: Porque no hay grupo de hombres lcc?_
🗣️

[12:18 PM] **Remil:** [Sticker]

[12:34 PM] **+52 1 662 412 0821:**
> _+52 1 662 522 5777: Porque no hay grupo de hombres lcc?_
"Los blancos tambien sufren racismo" typa shit 🥀

[12:35 PM] **+52 1 662 335 9011:**
> _+52 1 662 522 5777: Porque no hay grupo de hombres lcc?_
[Sticker]

[12:36 PM] **+52 1 662 426 8411:**
> _+52 1 662 412 0821: "Los blancos tambien sufren racismo" typa shit 🥀_
JDJDHD

[12:36 PM] **+52 1 687 120 1981:**
> _+52 1 662 522 5777: Porque no hay grupo de hombres lcc?_
[GIF]

[3:15 PM] **+52 1 645 340 8495:**
> _+52 1 662 522 5777: Porque no hay grupo de hombres lcc?_
Haz uno pues

[3:20 PM] **+52 1 662 412 0821:**
> _+52 1 645 340 8495: Haz uno pues_
Fiesta de salchichas

[3:30 PM] **+52 1 662 450 9504:** [Sticker]

[3:43 PM] **+52 1 662 449 3477:** [Image] Buen día gente, ando cotizando las camisas, este es el diseño, quien quisiera alguna? el precio ronda en 150 @all

[3:43 PM] **+52 1 662 449 3477:** **Poll: quien quiere camisa**
- yo
- yo no

[3:44 PM] **+52 1 662 463 6894:** Mmm q no que solo los primeros lugares?

[3:44 PM] **+52 1 662 463 6894:** [Sticker]

[3:44 PM] **+52 1 662 206 2716:**
> _+52 1 662 463 6894: Mmm q no que solo los primeros lugares?_
Para ellos fueron gratis 👀

[3:44 PM] **Remil:** Hay tamaño bk?

[3:46 PM] **+52 1 662 449 3477:**
> _Remil: Hay tamaño bk?_
puedo preguntar si tienen xxxxs

[3:52 PM] **+52 1 631 125 1255:**
> _+52 1 662 449 3477: puedo preguntar si tienen xxxxs_
[Sticker]

[3:53 PM] **+52 1 634 113 0073:**
> _+52 1 662 206 2716: Para ellos fueron gratis 👀_
Yo no tengo 👀

[3:56 PM] **+52 1 662 295 0244:** Negras ?

[3:56 PM] **+52 1 662 295 0244:** O es nomas el diseño

[3:59 PM] **+52 1 662 399 2340:**
> _+52 1 662 449 3477: puedo preguntar si tienen xxxxs_
Hay talla estudiante de computación osea 5XL en plan así

[3:59 PM] **+52 1 662 449 3477:**
> _+52 1 662 399 2340: Hay talla estudiante de computación osea 5XL en plan así_
cuestan extra las 2xl para adelante

[3:59 PM] **+52 1 645 107 9121:**
> _+52 1 662 399 2340: Hay talla estudiante de computación osea 5XL en plan así_
como yo bro

[4:03 PM] **+52 1 662 295 0244:**
> _+52 1 662 399 2340: Hay talla estudiante de computación osea 5XL en plan así_
[Sticker]

[4:03 PM] **+52 1 662 412 0821:**
> _+52 1 662 295 0244: Sticker_
Quien me tomó foto

[4:08 PM] **+52 1 631 125 1255:**
> _+52 1 662 295 0244: Sticker_
el usuaria de arch en mejor forma

[4:08 PM] **+52 1 662 295 4218:**
> _+52 1 662 399 2340: Hay talla estudiante de computación osea 5XL en plan así_
Ni q fuera tinaco we

[4:10 PM] **+52 1 662 399 2340:**
> _+52 1 662 295 4218: Ni q fuera tinaco we_
No te quejes we te sirve de camiseta y de lona para el techo

[4:10 PM] **+52 1 645 107 9121:**
> _+52 1 662 295 0244: Sticker_
i use arch btw

[4:10 PM] **+52 1 645 107 9121:** nmap

[4:11 PM] **+52 1 645 107 9121:** sudo opsec

[4:11 PM] **+52 1 645 107 9121:** hyprland

[4:11 PM] **+52 1 645 107 9121:** niri

[4:11 PM] **+52 1 645 107 9121:** dwm

[4:11 PM] **+52 1 645 107 9121:** i3

[4:11 PM] **+52 1 645 107 9121:** sway

[4:11 PM] **+52 1 631 193 8410:** Sudo rm -rf /

[4:11 PM] **+52 1 645 107 9121:**
> _+52 1 631 193 8410: Sudo rm -rf /_
--no-preserve-root

[4:11 PM] **+52 1 645 107 9121:** importante

[4:11 PM] **+52 1 662 450 9504:** El para que cosa de quien?

[4:11 PM] **+52 1 662 399 2340:**
> _+52 1 645 107 9121: hyprland_
hyprland = 💩

[4:11 PM] **+52 1 662 295 4218:** No se acepta taka taka

[4:12 PM] **+52 1 645 107 9121:**
> _+52 1 662 399 2340: hyprland = 💩_
me gusta más sway

[4:12 PM] **+52 1 645 107 9121:** i3 pero en wayland

[4:12 PM] **+52 1 631 193 8410:**
> _+52 1 645 107 9121: importante_
Canon

[4:12 PM] **+52 1 645 107 9121:** un dwm con quickshell

[4:12 PM] **+52 1 645 107 9121:** fedora atomic desktop >>>>>>

[4:13 PM] **+52 1 662 522 5777:** Para cuándo las se dragoncito 👉👈 maraca waisman

[4:13 PM] **+52 1 662 399 2340:**
> _+52 1 645 107 9121: me gusta más sway_
Si los que mantienen hyprland fueran responsables y no lo rompieran con cada actualización sería otra historia

[4:13 PM] **+52 1 645 107 9121:**
> _+52 1 662 399 2340: Si los que mantienen hyprland fueran responsables y no lo rompieran con cada actualización sería otra historia_
la vdd q si

[4:13 PM] **+52 1 645 107 9121:** cuando actualizaron el hypr config

[4:13 PM] **+52 1 645 107 9121:** con su nuevo formato

[4:13 PM] **+52 1 645 107 9121:** me perdí

[4:13 PM] **+52 1 645 107 9121:** y no quise otra vez usar hyprland

[4:13 PM] **+52 1 645 107 9121:** luego arch no es tan inestable

[4:13 PM] **+52 1 645 107 9121:** depende de ti

[4:14 PM] **+52 1 645 107 9121:** pero mejor fedora server y le metes lo q quieras

[4:14 PM] **+52 1 645 107 9121:** o fedora no se q pero lo haces desde cero

[4:14 PM] **+52 1 645 107 9121:** desde el sismo live boot como arch

[4:14 PM] **+52 1 645 107 9121:** pero con ui

[4:36 PM] **+52 1 662 295 4218:**
> _+52 1 662 449 3477: Image: Buen día gente, ando cotizando las camisas, este es el diseño, quien quisiera alguna? el precio ronda en 150 @all_
Se puede pedir mas de una?

[4:37 PM] **+52 1 662 142 7436:**
> _+52 1 662 449 3477: Image: Buen día gente, ando cotizando las camisas, este es el diseño, quien quisiera alguna? el precio ronda en 150 @all_
Aceptan 20 pesos?

[4:55 PM] __[System notification]__

[5:02 PM] **+52 1 662 637 5722:** Habrá en otro color? O sólo negro/verde?

[5:05 PM] **+52 1 662 467 9029:**
> _+52 1 662 463 6894: Sticker_
Que es esto

[5:06 PM] **+52 1 662 449 3477:**
> _+52 1 662 637 5722: Habrá en otro color? O sólo negro/verde?_
ese color nomas manejamos amigo

[5:39 PM] **+52 1 662 342 4670:** Hola, alguien sabe pq Yeomans está haciendo llamadas en el grupo de Lenguajes?

[5:39 PM] **+52 1 662 342 4670:** [Sticker]

[5:40 PM] **+52 1 662 332 3680:**
> _+52 1 662 342 4670: Hola, alguien sabe pq Yeomans está haciendo llamadas en el grupo de Lenguajes?_
Son grabaciones

[5:40 PM] **+52 1 662 332 3680:** Por si te pierdes algo

[5:40 PM] **+52 1 662 154 6723:** @~Eduardo que pedo we

[5:40 PM] **+52 1 662 299 4587:** son las clases pasadas

[5:41 PM] **+52 1 662 299 4587:** Se hacen notas de la clase usando llms para que cheques lo que hicimos sin ver la grabación

[5:41 PM] **+52 1 662 501 3191:**
> _+52 1 662 342 4670: Hola, alguien sabe pq Yeomans está haciendo llamadas en el grupo de Lenguajes?_
Hay un prófugo en lcc y nos tienen bajo vigilancia

[5:41 PM] **+52 1 631 125 1255:** @~Eduardo hola

[5:46 PM] **+52 1 662 335 9011:**
> _+52 1 662 501 3191: Hay un prófugo en lcc y nos tienen bajo vigilancia_
Te escapaste Angel w

[5:46 PM] **+52 1 662 335 9011:** por eso ahora nos traen checaditos

[5:46 PM] **+52 1 662 335 9011:** [Sticker]

[10:31 PM] **+52 1 662 224 3927:** Hola

[10:31 PM] **+52 1 662 224 3927:** Toquen pasto

[10:31 PM] **+52 1 662 224 3927:** Duerman

[10:32 PM] **+52 1 662 224 3927:** 🤟🐧🤟

[10:32 PM] **+52 1 662 206 6192:** no

[10:32 PM] **+52 1 662 224 3927:** Jehu

[10:32 PM] **+52 1 662 637 5722:** no

[10:32 PM] **+52 1 662 206 6192:** [Sticker]

[10:32 PM] **+52 1 662 224 3927:** Tienes suerte de que recientemente perdí mis stickers

[10:32 PM] **+52 1 662 206 6192:** [Sticker]

[10:35 PM] **+52 1 662 335 9011:**
> _+52 1 662 224 3927: Toquen pasto_
Ando atrapado en cc profe 
Le falle 🥀

[10:37 PM] **+52 1 667 973 4142:** Vegeta, what does the scouter say about his power level?

[10:39 PM] **+52 1 662 450 9504:** It's above of 8000!

---

## September 9, 2026

[9:43 AM] **+52 1 662 449 3477:** hola amigas podrían rellenar este documento con sus cumpleaños? y con los que conozcan de la carrera, con nombre y apellido plis  

https://docs.google.com/document/d/1g2r0Tu-bUJri1O58U-owV54jTjCiy7-Np7pJaPcmk-M/edit?usp=drivesdk

[9:43 AM] **+52 1 662 449 3477:** [Sticker]

[9:46 AM] **+52 1 631 125 1255:** vamos a revivir el calendario de la carrera?

[9:46 AM] **+52 1 631 125 1255:** [Sticker]

[9:48 AM] **+52 1 662 449 3477:**
> _+52 1 662 449 3477: hola amigas podrían rellenar este documento con sus cumpleaños? y con los que conozcan de la carrera, con nombre y apellido plis  

https://docs.google.com/document/d/1g2r0Tu-bUJri1O58U-owV54jTjCiy7-Np7pJaPcmk-M/edit?usp=drivesdk_
en orden si pueden de que por número si alguien cumple el 8 póngalo antes del cinco y así

[9:48 AM] **+52 1 662 449 3477:** [Sticker]

[9:54 AM] **+52 1 662 102 6188:**
> _+52 1 631 125 1255: vamos a revivir el calendario de la carrera?_
Nunca fue de la carrera we

[9:55 AM] **+52 1 631 125 1255:** como chingados no

[9:55 AM] **+52 1 631 125 1255:** habian fechas de cumpleaños de todos, maestros incluidos

[9:55 AM] **+52 1 631 125 1255:** y tenia fotos de los de la carrera

[11:06 AM] **+52 1 662 467 9029:**
> _+52 1 631 125 1255: y tenia fotos de los de la carrera_
Y que le pasó?

[1:43 PM] **+52 1 667 973 4142:** .

[1:45 PM] **+52 1 662 339 4302:** .

[1:45 PM] **+52 1 662 476 3432:** Angel Ortega
Maria Fernanda 
Dania Noriega
Miguel Flores
Julian Patricio
Ivana Chenoweth
david angulo
Cruz Duarte
Denzel Rivera
ariana villaba
Mario Ocejo
Johanna Reyes

[2:01 PM] **+52 1 662 339 4302:**
> _+52 1 662 476 3432: Angel Ortega
Maria Fernanda 
Dania Noriega
Miguel Flores
Julian Patricio
Ivana Chenoweth
david angulo
Cruz Duarte
Denzel Rivera
ariana villaba
Mario Ocejo
Johanna Reyes_
.

[2:20 PM] **+52 1 662 522 5777:**
> _+52 1 662 476 3432: Angel Ortega
Maria Fernanda 
Dania Noriega
Miguel Flores
Julian Patricio
Ivana Chenoweth
david angulo
Cruz Duarte
Denzel Rivera
ariana villaba
Mario Ocejo
Johanna Reyes_
?

[2:21 PM] **+52 1 662 476 3432:**
> _+52 1 662 476 3432: Angel Ortega
Maria Fernanda 
Dania Noriega
Miguel Flores
Julian Patricio
Ivana Chenoweth
david angulo
Cruz Duarte
Denzel Rivera
ariana villaba
Mario Ocejo
Johanna Reyes_
Presentación de contexto regional

[2:56 PM] **+52 1 645 107 9121:** @~Ángel @~Emiliano @~Juan @~Leo @~Leo Z. @~Luis SG @~Ossiel @~richardo 🦦 @~Santi Q.C

[2:56 PM] **+52 1 645 107 9121:** ellos son de presentación de contexto urbano

[3:02 PM] **+52 1 662 327 9060:** De que hablas licenciado

[3:08 PM] **+52 1 662 295 4218:**
> _+52 1 645 107 9121: @~Ángel @~Emiliano @~Juan @~Leo @~Leo Z. @~Luis SG @~Ossiel @~richardo 🦦 @~Santi Q.C_
[Sticker]

[3:08 PM] **+52 1 662 142 7436:**
> _+52 1 645 107 9121: @~Ángel @~Emiliano @~Juan @~Leo @~Leo Z. @~Luis SG @~Ossiel @~richardo 🦦 @~Santi Q.C_
Yo soy ese

[3:08 PM] **+52 1 662 142 7436:** Para q soy bueno?

[3:12 PM] **+52 1 662 119 6538:**
> _+52 1 645 107 9121: ellos son de presentación de contexto urbano_
Que

[3:13 PM] **+52 1 662 327 9060:** Saquenlo del sistema solar

[3:15 PM] **+52 1 631 125 1255:**
> _+52 1 662 119 6538: Que_
so

[3:15 PM] **+52 1 631 125 1255:** [Sticker]

[3:18 PM] **+52 1 645 107 9121:**
> _+52 1 631 125 1255: so_
[Sticker]

[3:23 PM] **+52 1 662 119 6538:**
> _+52 1 631 125 1255: so_
Rra

[3:32 PM] **+52 1 631 125 1255:** tu mamá w

[3:33 PM] **+52 1 631 125 1255:** danza trolistica

[3:33 PM] **+52 1 631 125 1255:** [Sticker]

[3:33 PM] **+52 1 662 411 2084:**
> _+52 1 645 107 9121: @~Ángel @~Emiliano @~Juan @~Leo @~Leo Z. @~Luis SG @~Ossiel @~richardo 🦦 @~Santi Q.C_
[Sticker]

[3:33 PM] **+52 1 645 107 9121:** mucha drama ya besense mejor

[7:33 PM] **+52 1 662 296 3657:** alguien tiene una imagen de las reglas del centro de computo?

[7:38 PM] **+52 1 662 350 4258:**
> _+52 1 662 296 3657: alguien tiene una imagen de las reglas del centro de computo?_
no robar, no mentir, no traicionar, y cederle las mesas largas a los baquetones

[7:38 PM] **+52 1 662 450 9504:** Yo te la puedo dar ahorita

[7:38 PM] **+52 1 662 450 9504:** Aqui ando en la uni todavia

[7:43 PM] **+52 1 662 296 3657:**
> _+52 1 662 350 4258: no robar, no mentir, no traicionar, y cederle las mesas largas a los baquetones_
De cabrones

[7:43 PM] **+52 1 662 296 3657:**
> _+52 1 662 450 9504: Yo te la puedo dar ahorita_
Porfavor

[7:58 PM] **+52 1 984 522 6144:**
> _+52 1 662 350 4258: no robar, no mentir, no traicionar, y cederle las mesas largas a los baquetones_
No wacarear fourloko (obligatorio)

[8:06 PM] **+52 1 662 399 2340:**
> _+52 1 662 350 4258: no robar, no mentir, no traicionar, y cederle las mesas largas a los baquetones_
No ser el niño del post, no usar cuentas "oficiales" para quejarse de negocios, no wakariar four loko

[10:24 PM] **+52 1 662 522 5777:**
> _+52 1 662 399 2340: No ser el niño del post, no usar cuentas "oficiales" para quejarse de negocios, no wakariar four loko_
No subirse a los techos

[10:27 PM] **+52 1 662 637 5722:**
> _+52 1 662 522 5777: No subirse a los techos_
no fumar mota

[10:28 PM] **+52 1 634 109 6592:**
> _+52 1 662 637 5722: no fumar mota_
No robarse termos

---

## September 10, 2026

[8:25 AM] **+52 1 662 449 3477:** hola compañeras buenos días

[8:26 AM] **+52 1 662 449 3477:** los vengo a invitar a la semana de matemáticas, por si están interesados aquí les dejo el link de la página

[8:26 AM] **+52 1 662 449 3477:** https://semana.mat.uson.mx/semanaxxxv/index.php

[9:01 AM] **+52 1 662 449 3477:** [Forwarded] [Image]

[10:02 AM] **+52 1 667 973 4142:**
> _+52 1 662 476 3432: Angel Ortega
Maria Fernanda 
Dania Noriega
Miguel Flores
Julian Patricio
Ivana Chenoweth
david angulo
Cruz Duarte
Denzel Rivera
ariana villaba
Mario Ocejo
Johanna Reyes_
.

[10:06 AM] **+52 1 662 341 2644:** [Forwarded] https://forms.gle/cVmzYVC73XEeFQy96

[10:07 AM] **+52 1 662 341 2644:** [Forwarded] Puedes contestar la encuesta y pasarla con tus compañeros plis

[11:51 AM] **+52 1 667 973 4142:** El profe de Contexto Regional 1pm-2pm llegará pasada de la 1pm por una reunión

[12:45 PM] **+52 1 662 268 7744:** Hola compañeros, el día de hoy tuvimos una junta con sonia y hemos llegado a un acuerdo.
El día Lunes 14 de Septiembre se hará una junta a las 11:00AM, es de extrema importancia y urgencia que asistan ya que ahí se discutirá todo el tema del centro de cómputo y quien no esté presente no se enterará de los requerimientos para entrar ya que sea abierto, esperamos su asistencia

[2:18 PM] **+52 1 662 449 3477:**
> _+52 1 662 449 3477: https://semana.mat.uson.mx/semanaxxxv/index.php_
si están interesados estar en lo logístico del evento me mandan mensajito

[2:18 PM] **+52 1 662 637 5722:**
> _+52 1 662 449 3477: si están interesados estar en lo logístico del evento me mandan mensajito_
hay pago?

[2:20 PM] **+52 1 662 449 3477:** no moi

[2:35 PM] **+52 1 662 522 5777:** Pasen el video del burbuja cantando

[2:35 PM] **+52 1 662 449 3477:**
> _+52 1 662 449 3477: Image: Buen día gente, ando cotizando las camisas, este es el diseño, quien quisiera alguna? el precio ronda en 150 @all_
[Image] amigos también cotice manga larga por si están interesados también en una así me dijo que salían en $135

[2:54 PM] **+52 1 662 449 3477:**
> _+52 1 662 449 3477: Image: amigos también cotice manga larga por si están interesados también en una así me dijo que salían en $135_
160 las 2xl y 3xl

[4:01 PM] **+52 1 662 467 9029:** Le debo $205 al @+52 1 662 202 9887

[4:01 PM] **+52 1 662 467 9029:** Le debo $100 al @~Mcgrew Valenzuela 

[4:01 PM] **+52 1 662 335 9011:** 🫪

[4:38 PM] **+52 1 662 449 3477:** buen día gente, aquí está el forms para las playeras
 https://forms.gle/gYKNWawtf56PnWFq8  @all

[4:38 PM] __[System notification]__

[4:38 PM] **+52 1 662 699 4499:** dejen de abusar el all, respetuosamente

[4:38 PM] **+52 1 662 699 4499:** gracias

[4:39 PM] **+52 1 662 501 3191:** @everyone

[4:39 PM] **+52 1 662 637 5722:**
> _+52 1 662 449 3477: buen día gente, aquí está el forms para las playeras
 https://forms.gle/gYKNWawtf56PnWFq8  @all_
Es sólo para las manga corta o también la larga?

[4:39 PM] **+52 1 662 449 3477:**
> _+52 1 662 637 5722: Es sólo para las manga corta o también la larga?_
las dos

[4:41 PM] **+52 1 667 973 4142:** ㅤ

[4:42 PM] **+52 1 644 422 2240:**
> _+52 1 662 449 3477: buen día gente, aquí está el forms para las playeras
 https://forms.gle/gYKNWawtf56PnWFq8  @all_
Hola Dania Vega, cuál es el último día para poder contestar la encuesta/hacer el pago?

[4:42 PM] **+52 1 644 422 2240:** [Sticker]

[4:43 PM] **+52 1 662 449 3477:**
> _+52 1 644 422 2240: Hola Dania Vega, cuál es el último día para poder contestar la encuesta/hacer el pago?_
la próxima semana

[4:56 PM] **+52 1 662 467 9029:**
> _+52 1 662 449 3477: la próxima semana_
Prestame $120

[4:56 PM] **+52 1 662 501 3191:**
> _+52 1 662 467 9029: Prestame $120_
BanCoppel te da eso y lo pagas en cuotas de 800 meses

[4:57 PM] **+52 1 662 501 3191:** Más intereses

[5:41 PM] **+52 1 662 426 8411:**
> _+52 1 662 449 3477: buen día gente, aquí está el forms para las playeras
 https://forms.gle/gYKNWawtf56PnWFq8  @all_
Dania una preguntita, sabes masomenos que día llegarían?

[5:41 PM] **+52 1 662 449 3477:** me dijeron que tardarían aproximadamente 7 días hábiles

[5:42 PM] **+52 1 662 476 3432:** muchas gracias dania

[5:42 PM] **+52 1 662 467 9029:** Diavlo

[5:42 PM] **+52 1 662 476 3432:** [Sticker]

[6:05 PM] **+52 1 662 449 3477:** por cierto las coticé porque se esperaban unas 100, si en el registro hay menos de 50 subiría unos pesitos el precio

[6:36 PM] **+52 1 662 467 9029:** Le debo $20 al @~Zathquiel

[8:10 PM] **+52 1 662 637 5722:** raza, qué profe era el que empezaba a penalizar cuando tenías más de 10 faltas?

[8:13 PM] **+52 1 662 350 4258:**
> _+52 1 662 637 5722: raza, qué profe era el que empezaba a penalizar cuando tenías más de 10 faltas?_
villa

[8:16 PM] **+52 1 662 399 2340:**
> _+52 1 662 637 5722: raza, qué profe era el que empezaba a penalizar cuando tenías más de 10 faltas?_
@Villa

[8:33 PM] **+52 1 662 295 4218:** Villa

[8:41 PM] **+52 1 662 102 6188:** VS

[9:00 PM] **+52 1 662 295 0244:**
> _+52 1 662 637 5722: raza, qué profe era el que empezaba a penalizar cuando tenías más de 10 faltas?_
Segun yo eran 8

[9:00 PM] **+52 1 662 399 2340:**
> _+52 1 662 295 0244: Segun yo eran 8_
En mis tiempos eran 12

[9:01 PM] **+52 1 662 295 0244:** Varia me imagino

[9:48 PM] **+52 1 662 342 4670:** No habrá clases de Lenguajes de P mañana🫩

[9:48 PM] **+52 1 662 335 9011:** 🥀

[9:48 PM] **+52 1 662 501 3191:** Dios nos ha abandonado

[9:48 PM] **+52 1 662 342 4670:** [Sticker]

[9:51 PM] **+52 1 662 335 9011:** _This message was deleted_

[9:51 PM] **+52 1 662 335 9011:** 🔥🦅

[9:51 PM] **+52 1 662 501 3191:**
> _+52 1 662 335 9011: Pero entra a la clase w_
Borra tu mensaje, no lo debe de saber el espía americano

[9:52 PM] **+52 1 662 335 9011:** [Sticker]

[9:52 PM] **+52 1 662 342 4670:**
> _+52 1 662 501 3191: Borra tu mensaje, no lo debe de saber el espía americano_
Igual sale porque tú le respondiste o sea, JAJAJAJAJJAJA

[9:52 PM] **+52 1 662 342 4670:** Ah, ya sé quitó xd

[9:52 PM] **+52 1 644 422 2240:**
> _+52 1 662 501 3191: Borra tu mensaje, no lo debe de saber el espía americano_
[Sticker]

[9:53 PM] **+52 1 662 342 4670:** [Sticker]

[9:53 PM] **+52 1 662 342 4670:** [Sticker]

[9:53 PM] **+52 1 662 335 9011:** [GIF]

[9:55 PM] **+52 1 662 469 3513:** @~Dania Vega te mandamos dinero

[9:55 PM] **+52 1 662 469 3513:** o cuando se cierre el form?

[9:58 PM] **+52 1 662 449 3477:** para mandar el forms te pide el comprobante de pago hermana

[9:58 PM] **+52 1 662 449 3477:** es que no los quiero andar correteando para que paguen después

[9:58 PM] **+52 1 662 449 3477:** [Sticker]

[10:00 PM] **+52 1 662 469 3513:** pero si no se llegan a llenar los que tenías contemplado va a subir el precio

[10:00 PM] **+52 1 662 469 3513:** Entonces para darte ya el final

[10:00 PM] **+52 1 662 469 3513:** pq no sabremos si te daremos un solo depósito o dos depósitos

[10:00 PM] **+52 1 662 469 3513:** por eso te pregunto

[10:01 PM] **+52 1 662 367 8720:** el ángel paga

[10:01 PM] **+52 1 662 449 3477:** ahh yo digo que mejor irlo haciendo y ya si sube pues ni al caso pueden hacer otro

[10:01 PM] **+52 1 662 367 8720:** [Sticker]

[10:01 PM] **+52 1 662 449 3477:** [Sticker]

[10:01 PM] **+52 1 662 476 3432:**
> _+52 1 662 367 8720: el ángel paga_
el vazques supongo que dices

[10:01 PM] **+52 1 662 476 3432:** [Sticker]

[10:01 PM] **+52 1 662 431 2924:** manden a hacer hoodies en tiempo de frio

[10:01 PM] **+52 1 662 431 2924:** [Sticker]

[10:02 PM] **+52 1 662 449 3477:**
> _+52 1 662 431 2924: manden a hacer hoodies en tiempo de frio_
cuándo es ese tiempo?

[10:02 PM] **+52 1 662 367 8720:**
> _+52 1 662 476 3432: el vazques supongo que dices_
vázques JAJAJAJAJAJ mínimo no le dijiste valdez

[10:02 PM] **+52 1 662 420 8102:**
> _+52 1 662 449 3477: cuándo es ese tiempo?_
1 día al año y si es que hay suerte

[10:02 PM] **+52 1 662 449 3477:**
> _+52 1 662 367 8720: vázques JAJAJAJAJAJ mínimo no le dijiste valdez_
supéralo hermano

[10:02 PM] **+52 1 662 501 3191:**
> _+52 1 662 476 3432: el vazques supongo que dices_
Nadie le atina a mi apellido

[10:02 PM] **+52 1 662 335 9011:**
> _+52 1 662 367 8720: el ángel paga_
El Angel paga 🔥

[10:02 PM] **+52 1 662 476 3432:**
> _+52 1 662 501 3191: Nadie le atina a mi apellido_
[Sticker]

[10:02 PM] **+52 1 662 367 8720:**
> _+52 1 662 449 3477: supéralo hermano_
[Sticker]

[10:02 PM] **+52 1 662 431 2924:**
> _+52 1 662 449 3477: cuándo es ese tiempo?_
le bajamos al aire para tener frio

[10:03 PM] **+52 1 662 501 3191:**
> _+52 1 662 449 3477: supéralo hermano_
Te queremos mucho compañerita Dania, aunque nos confundas de nombres y no nos topes

[10:03 PM] **+52 1 662 449 3477:**
> _+52 1 662 501 3191: Te queremos mucho compañerita Dania, aunque nos confundas de nombres y no nos topes_
estás muy equivocado valdez yo me sé todos los nombres

[10:03 PM] **+52 1 662 476 3432:**
> _+52 1 662 501 3191: Te queremos mucho compañerita Dania, aunque nos confundas de nombres y no nos topes_
si compañerita dania gracias por todo aunque llevemos 5 semestres juntos y no sepas que uso lentes ❤️

[10:04 PM] **+52 1 662 449 3477:** oigan uno es humano y tiene errores

[10:04 PM] **+52 1 662 449 3477:** [Sticker]

[10:04 PM] **+52 1 662 367 8720:** si verdad, diana

[10:04 PM] **+52 1 662 367 8720:** no pasa nada

[10:04 PM] **+52 1 662 501 3191:**
> _+52 1 662 449 3477: estás muy equivocado valdez yo me sé todos los nombres_
[Sticker]

[10:04 PM] **+52 1 662 476 3432:** una cosa es un error y otra cosa es pasarte de lanza

[10:05 PM] **+52 1 662 476 3432:** [Sticker]

[10:05 PM] **+52 1 662 420 8102:**
> _+52 1 662 367 8720: si verdad, diana_
diana paloma?

[10:05 PM] **+52 1 662 420 8102:** o cómo era

[10:05 PM] **+52 1 662 420 8102:** [Sticker]

[10:05 PM] **+52 1 662 501 3191:**
> _+52 1 662 449 3477: oigan uno es humano y tiene errores_
No te preocupes Diana Verga ❤️

[10:05 PM] **+52 1 662 367 8720:**
> _+52 1 662 501 3191: No te preocupes Diana Verga ❤️_
ay ya no dio risa we

[10:05 PM] **+52 1 662 476 3432:** yo si me reí angel

[10:05 PM] **+52 1 662 501 3191:** Dos caras de una misma moneda

[10:06 PM] **+52 1 662 449 3477:**
> _+52 1 662 501 3191: No te preocupes Diana Verga ❤️_
eyeye no menciones tu comida en el grupo

[10:06 PM] **+52 1 662 420 8102:** es q traía hambre el pobrecito

[10:06 PM] **+52 1 662 420 8102:** q alguien le dé

[10:07 PM] **+52 1 662 501 3191:**
> _+52 1 662 420 8102: q alguien le dé_
Ouh wow

[10:07 PM] **+52 1 662 476 3432:** el mario dice que te quiere dar de su chocolate

[10:07 PM] **+52 1 662 420 8102:** [Sticker]

[10:08 PM] **+52 1 662 399 2340:**
> _+52 1 662 420 8102: diana paloma?_
No le digas paloma a la paloma pasan cosas

---

## September 11, 2026

[12:20 AM] **+52 1 662 446 0922:**
> _+52 1 662 399 2340: No le digas paloma a la paloma pasan cosas_
Confirmo (Recuerdos de Vietnam )

[12:21 AM] **+52 1 662 446 0922:** [Sticker]

[7:52 AM] **+52 1 644 422 2240:**
> _+52 1 662 420 8102: q alguien le dé_
Yo le doy

[7:52 AM] **+52 1 644 422 2240:** [Sticker]

[8:10 AM] **+52 1 662 467 8870:**
> _+52 1 662 449 3477: oigan uno es humano y tiene errores_
No fuera la d los chilaquiles

[8:10 AM] **+52 1 662 467 8870:** [Sticker]

[8:27 AM] **+52 1 662 449 3477:** no sé de qué hablas amigo

[8:48 AM] **+52 1 662 224 3927:** Buenos días

[8:49 AM] **+52 1 662 224 3927:** La profesora Olivia Gutú no podrá impartir clases el día de hoy

[8:49 AM] **+52 1 662 224 3927:** Me pidió que les comentara por este grupo

[8:52 AM] **+52 1 662 467 8870:**
> _+52 1 662 224 3927: Buenos días_
Ola eduardO from LCC

[8:52 AM] **+52 1 662 467 8870:** T kierO

[8:52 AM] **+52 1 662 467 8870:** [Sticker]

[8:52 AM] **+52 1 662 431 2924:**
> _+52 1 662 224 3927: Me pidió que les comentara por este grupo_
graciass profe

[8:52 AM] **+52 1 662 431 2924:** _This message was deleted_

[9:05 AM] **+52 1 662 401 6648:**
> _+52 1 662 224 3927: La profesora Olivia Gutú no podrá impartir clases el día de hoy_
muchas gracias!

[9:21 AM] **+52 1 662 206 6192:**
> _+52 1 662 224 3927: Buenos días_
ola profesor eduardo

[9:32 AM] **+1 (702) 203-9803:** _This message was deleted_

[10:18 AM] **+52 1 662 449 3477:** alguien ha visto a adrianvo

[10:18 AM] **+52 1 662 449 3477:** [Sticker]

[10:22 AM] **+52 1 662 476 3432:**
> _+52 1 662 449 3477: alguien ha visto a adrianvo_
Si lo encuentras

[10:22 AM] **+52 1 662 476 3432:** Dile que no de clases

[10:22 AM] **+52 1 662 476 3432:** [Sticker]

[10:25 AM] **+52 1 662 446 0922:** Clases ?
No era hoy el examen ?

[10:25 AM] **+52 1 662 446 0922:** [Sticker]

[10:59 AM] **+52 1 662 476 3432:**
> _+52 1 662 446 0922: Clases ?
No era hoy el examen ?_
Nop

[10:59 AM] **+52 1 662 476 3432:** El martes

[11:00 AM] **+52 1 662 446 0922:** Disculpa, hablaba de mi grupo, votamos para este viernes

[11:00 AM] **+52 1 662 446 0922:** [Sticker]

[11:06 AM] **+52 1 662 467 9029:**
> _+52 1 662 446 0922: Disculpa, hablaba de mi grupo, votamos para este viernes_
Wtf

[11:07 AM] **+52 1 662 446 0922:** Ya me ando preocupando we, será que ando confundido 
@~Corgais en la clase de Adrián, teníamos el examen para hoy que no??

[11:07 AM] **+52 1 662 446 0922:** [Sticker]

[11:07 AM] **+52 1 662 446 0922:** 12-1

[11:07 AM] **+52 1 662 335 9011:** Yup

[11:07 AM] **+52 1 662 335 9011:** [Sticker]

[1:01 PM] **+52 1 637 117 9366:** [Forwarded] Oye, no llego a clases pero deje el examen en el Teams

[1:01 PM] **+52 1 637 117 9366:** [Forwarded] Se cierra el examen a las 3 y una vez que lo inicien tienen una hora

[1:01 PM] **+52 1 637 117 9366:** Reconocimiento de patrones con waissman

[4:10 PM] **+52 1 662 467 9029:** Le debo al Miguel de Mate mas o menos $79

[6:42 PM] **+52 1 662 522 5777:**
> _+52 1 662 467 9029: Le debo al Miguel de Mate mas o menos $79_
Y a mí la bola de voley

[7:46 PM] **+52 1 662 467 9029:** Ke

---

## September 12, 2026

[9:26 AM] **+52 1 662 467 9029:** _Waiting for this message. This may take a while._

[9:27 AM] **+52 1 662 335 9011:** [Sticker]

[10:05 AM] **+52 1 662 637 5722:**
> _+52 1 662 467 9029: Video_
gpi

[12:01 PM] **+52 1 645 107 9121:**
> _+52 1 662 467 9029: Video_
y no invitan

[12:01 PM] **+52 1 645 107 9121:** [Sticker]

[12:04 PM] **+52 1 662 357 9360:**
> _+52 1 645 107 9121: y no invitan_
Es d hace dos años

[12:09 PM] **+52 1 662 432 8446:**
> _+52 1 662 467 9029: Video_
@Remil ya no te he visto así

[1:39 PM] **+52 1 662 467 9029:**
> _+52 1 662 637 5722: gpi_
Es del rompehielos de cuando los de 5to eramos de 1ro

[1:45 PM] **+52 1 631 125 1255:** la rokola iphone a la 1am🔥🔥🔥

[1:53 PM] **+52 1 662 149 5058:**
> _+52 1 631 125 1255: la rokola iphone a la 1am🔥🔥🔥_
@~Omar P

[2:35 PM] **+52 1 662 476 3432:** [Document] Tareas Contexto e Historia Regional_Misiones(2).docx

[2:35 PM] **+52 1 662 476 3432:** Los que van en contexto regional de 1pm a 2pm

[2:35 PM] **+52 1 662 476 3432:** Aqui estan los temas

[2:35 PM] **+52 1 662 476 3432:** Ya esta agarrado el sistema de misiones jesuitas

[2:39 PM] **+52 1 662 449 3477:**
> _+52 1 662 476 3432: Document: Tareas Contexto e Historia Regional_Misiones(2).docx_
La vida cotidiana y el trabajo dentro de la mision en la sección la vida en la misión

[2:39 PM] **+52 1 662 449 3477:** [Sticker]

[2:43 PM] **+52 1 662 367 8720:** ?

[2:43 PM] **+52 1 662 367 8720:** son tres equipos dania, punto 1,2 y 3

[2:44 PM] **+52 1 662 449 3477:** [Sticker]

[2:44 PM] **+52 1 662 367 8720:** punto 1 el sistema de misiones
punto 2 comunidad indigena y mision
punto 3 gobierno de la comunidad indigena

[2:45 PM] **+52 1 662 449 3477:** pero no somos como 10 gentes?

[2:45 PM] **+52 1 662 367 8720:** somos 12

[2:47 PM] **+52 1 662 367 8720:**
> _+52 1 662 476 3432: Angel Ortega
Maria Fernanda 
Dania Noriega
Miguel Flores
Julian Patricio
Ivana Chenoweth
david angulo
Cruz Duarte
Denzel Rivera
ariana villaba
Mario Ocejo
Johanna Reyes_
.

[2:48 PM] **+52 1 662 367 8720:** lo ideal serían equipos de 4 y escogen su tema

[2:55 PM] **+52 1 662 426 8411:**
> _+52 1 662 476 3432: Document: Tareas Contexto e Historia Regional_Misiones(2).docx_
De dónde sacaste eso?

[2:55 PM] **+52 1 662 426 8411:** No lo veo en el teams

[2:55 PM] **+52 1 662 476 3432:** Me lo paso el profe por correo

[2:56 PM] **+52 1 644 422 2240:** Formen los equipos para ver que punto agarra cada uno

[2:56 PM] **+52 1 644 422 2240:** [Sticker]

[2:57 PM] **+52 1 662 476 3432:** TEMA: sistema de misiones jesuitas
ANGEL ORTEGA
MARIA FERNANDA HERNANDEZ
MARIO OCEJO 
DENZEL RIVERA

[2:57 PM] **+52 1 662 450 9504:** Mi pregunta es por que llevan historia en la carrera

[2:58 PM] **+52 1 644 422 2240:**
> _+52 1 662 450 9504: Mi pregunta es por que llevan historia en la carrera_
[Sticker]

[2:58 PM] **+52 1 644 422 2240:** No lo entenderías...

[3:06 PM] **+52 1 662 449 3477:** punto 2: comunidad indigena y mision
Angel vázquez
Dania Vega 
Julián ibarra

[3:07 PM] **+52 1 644 422 2240:** Punto 3: Gobierno de la comunidad indigena
David Angulo
Ivana Chenoweth
Jovanna Reyes
Axel Sanchez

[3:07 PM] **+52 1 644 422 2240:**
> _+52 1 662 449 3477: comunidad indigena y mision
punto
Angel valdez
Dania Vega 
Julián patricio_
Ay el Valdez...

[3:08 PM] **+52 1 667 973 4142:**
> _+52 1 662 449 3477: comunidad indigena y mision
punto
Angel valdez
Dania Vega 
Julián patricio_
me les puedo unir?

[3:09 PM] **+52 1 662 449 3477:**
> _+52 1 644 422 2240: Ay el Valdez..._
ni idea de que hablas amigo

[3:26 PM] **+52 1 662 446 0922:**
> _+52 1 662 467 9029: Video_
@~Chema Nuñez esos si son compás
Con el puto abrazo se vio

[3:47 PM] **+52 1 631 125 1255:** quite el vídeo a los 3 segundos d abrirlo

[3:48 PM] **+52 1 631 125 1255:** pura raza jaladora o q mal pedo q la raza sea asi

[3:48 PM] **+52 1 631 125 1255:** depende de cual sirva mejor

[3:48 PM] **+52 1 631 125 1255:** [Sticker]

[8:29 PM] **+52 1 662 342 4670:** Alguien de aquí jala a jugar al lol ?

[8:29 PM] **+52 1 662 342 4670:** Soy buen support y jungla

[8:29 PM] **+52 1 662 342 4670:** [Sticker]

[8:29 PM] **+52 1 662 342 4670:** [Sticker]

[8:32 PM] **+52 1 662 139 3528:** Hay grupo de lol

[8:33 PM] **+52 1 662 139 3528:** https://chat.whatsapp.com/KJkHQVZtTmrJHurZGG54gv?s=cl&p=i&mlu=4&ilr=4

[8:34 PM] **+52 1 662 342 4670:** A no mames jajajaja

[8:35 PM] **+52 1 662 342 4670:** Tqm jajajajaj

[8:35 PM] **+52 1 662 342 4670:** [Sticker]

---

## September 13, 2026

[5:19 PM] **+52 1 662 501 3191:** [Image] Que se hace aqui ?

[5:19 PM] **+52 1 662 501 3191:** [Sticker]

[5:22 PM] **+52 1 662 501 3191:**
> _+52 1 662 501 3191: Image: Que se hace aqui ?_
4 reacciones, me odian 💔

[5:22 PM] **+52 1 662 142 7436:**
> _+52 1 662 501 3191: Image: Que se hace aqui ?_
Ingaturoña

[5:23 PM] **+52 1 644 422 2240:**
> _+52 1 662 501 3191: Image: Que se hace aqui ?_
Ya lo dieron de baja ♥️

[5:23 PM] **+52 1 644 422 2240:** [Sticker]

[6:10 PM] **+52 1 662 369 5386:**
> _+52 1 662 501 3191: Image: Que se hace aqui ?_
date de baja

[6:15 PM] **+52 1 631 125 1255:** [Forwarded] [Image]

[6:15 PM] **+52 1 631 125 1255:** feliz dia del programador gente y asi, q turing les haya traido desodorante y jabon y cosas asi

[7:08 PM] **+52 1 645 107 9121:**
> _+52 1 662 139 3528: Hay grupo de lol_
hay de geometry dash?

[7:08 PM] **+52 1 645 107 9121:** y de osu?

[7:14 PM] **+52 1 662 426 8411:**
> _+52 1 645 107 9121: hay de geometry dash?_
[Sticker]

---

## September 14, 2026

[7:03 AM] **+52 1 662 467 9029:** Me podrían pasar el documento del reglamento del CC que está pegado en la pared?

[7:39 AM] **+52 1 662 142 7436:** [Sticker]

[7:39 AM] **+52 1 662 142 7436:** _This message was deleted_

[8:36 AM] **+52 1 662 637 5722:** para cuándo quedó la peda de este año ajena a la universidad?

[8:39 AM] **+52 1 662 449 3477:** _This message was deleted_

[8:43 AM] **+52 1 662 412 8540:**
> _+52 1 662 637 5722: para cuándo quedó la peda de este año ajena a la universidad?_
Este vienes

[8:43 AM] **+52 1 662 341 2644:** A donde voy

[9:01 AM] **+52 1 662 341 2644:** [Image]

[9:01 AM] **+52 1 662 341 2644:** lol

[9:03 AM] **+52 1 662 412 0821:**
> _+52 1 662 341 2644: Image_
Y donde esta el de no tomar four lokos?

[9:10 AM] **Amado Rosas:**
> _+52 1 662 341 2644: Image_
hay que tumbarlo

[9:10 AM] **+52 1 662 450 9504:**
> _+52 1 662 412 0821: Y donde esta el de no tomar four lokos?_
Me dijeron que mañana lo ponen afuera del cc

[9:14 AM] **+52 1 662 395 2865:**
> _+52 1 662 637 5722: para cuándo quedó la peda de este año ajena a la universidad?_
irás moi?

[9:14 AM] **+52 1 662 395 2865:** [Sticker]

[9:14 AM] **+52 1 662 637 5722:**
> _+52 1 662 395 2865: irás moi?_
sí

[9:16 AM] **+52 1 662 637 5722:**
> _+52 1 662 412 8540: Este vienes_
va a haber concurso de comida?

[9:16 AM] **+52 1 662 449 3477:** siii

[9:16 AM] **+52 1 662 449 3477:** sigue en pie

[9:16 AM] **+52 1 662 637 5722:**
> _+52 1 662 449 3477: siii_
q hay de premio

[9:17 AM] **+52 1 662 637 5722:** 👀

[9:17 AM] **+52 1 662 449 3477:** cuando ganes te darás cuenta

[9:17 AM] **+52 1 662 449 3477:** [Sticker]

[9:17 AM] **+52 1 662 637 5722:**
> _+52 1 662 449 3477: cuando ganes te darás cuenta_
pa ver si me interesa ganar o no ps

[10:31 AM] **+52 1 662 450 9504:**
> _+52 1 662 637 5722: q hay de premio_
Que no te cobren lq comida we

[11:01 AM] **+52 1 662 467 9029:** Gente, ya va a iniciar la junta en el auditorio para atender el tema del Centro de Computo

[11:07 AM] **+52 1 662 467 9029:** [Image]

[11:07 AM] **+52 1 662 467 9029:** Si quieren volver a entrar al cc tienen que volvet a la platica y firmar un documento

[11:20 AM] **+52 1 662 522 5777:**
> _+52 1 662 341 2644: Image_
[Sticker]

[11:21 AM] __[System notification]__

[11:49 AM] **+52 1 662 637 5722:** [Image]

[11:52 AM] **+52 1 662 699 4499:**
> _+52 1 662 637 5722: Image_
fourloko 🚫

[11:59 AM] **+52 1 662 463 6894:** portense bien

[11:59 AM] **+52 1 662 463 6894:** 🤓

[12:06 PM] **+52 1 662 373 9949:**
> _+52 1 662 637 5722: Image_
[Sticker]

[12:48 PM] **+52 1 687 120 1981:**
> _+52 1 662 637 5722: Image_
Pórtese serio…

[12:49 PM] **+52 1 662 448 5902:**
> _+52 1 662 637 5722: Image_
[Sticker]

[1:03 PM] **+52 1 662 476 3432:**
> _+52 1 662 637 5722: Image_
Ni pa que entro

[1:21 PM] **+52 1 662 467 9029:** A quien le deba dinero busqueme en la tiendita o a las 2 en el edificio

[1:24 PM] **+52 1 662 350 4258:**
> _+52 1 662 467 9029: A quien le deba dinero busqueme en la tiendita o a las 2 en el edificio_
@TesoreriaDeLaUnison

[1:42 PM] **+52 1 662 224 3927:** EH PLEBES!!!!

[1:42 PM] **+52 1 662 224 3927:** ALTO AHI

[1:42 PM] **+52 1 662 224 3927:** [Sticker]

[1:43 PM] **+52 1 662 224 3927:** [Image]

[1:43 PM] **+52 1 662 224 3927:** @todos

[1:43 PM] **+52 1 662 224 3927:** Me pidieron que les extendiera esta invitación

[1:49 PM] **+52 1 662 224 3927:** Van a ir saliendo otros de estos eventos

[1:49 PM] **+52 1 662 224 3927:** Esto se va a descontrolar

[1:50 PM] **+52 1 662 446 0922:** [Sticker]

[2:53 PM] **+52 1 662 449 3477:** amigas de primero para lo de las libretas nos vemos mañana a las 11, nomas se les entregaría una y no puedes recoger el de otra persona

[2:58 PM] __+52 1 662 731 4067 joined via invite link__

[3:46 PM] **+52 1 662 341 2644:**
> _+52 1 662 449 3477: amigas de primero para lo de las libretas nos vemos mañana a las 11, nomas se les entregaría una y no puedes recoger el de otra persona_
Van a realizar la lista para los de otros semestres?

[3:46 PM] **+52 1 662 341 2644:** O están contadas para los de primeros

[3:46 PM] **+52 1 662 341 2644:** [Sticker]

[4:49 PM] **+52 1 662 449 3477:** tu que crees hermanito

[4:52 PM] **+52 1 662 224 3927:** Apartada una si sobra

[4:52 PM] **+52 1 662 224 3927:** Primix

[4:53 PM] **+52 1 662 467 9029:** Va a haber lista vd?

[4:53 PM] **+52 1 662 467 9029:** Impriman la hoja con mi nombre de una porfa

[4:59 PM] **+52 1 631 125 1255:**
> _+52 1 662 449 3477: tu que crees hermanito_
que como en años pasados, hay alumnos de primero que no van/no quieren su libreta, y se hara una lista para las personas interesadas en una

[4:59 PM] **+52 1 631 125 1255:** [Sticker]

[5:02 PM] **+52 1 662 224 3927:**
> _+52 1 662 224 3927: Primix_
☝️

[5:02 PM] **+52 1 662 224 3927:** En LCC es cosa de usos y costumbres respetar el primix

[5:02 PM] **+52 1 662 224 3927:** Desde el inicio del programa educativo

[5:03 PM] **+52 1 662 224 3927:** [Sticker]

[5:03 PM] **+52 1 662 341 2644:**
> _+52 1 662 449 3477: tu que crees hermanito_
no leo mentes

[5:04 PM] **+52 1 662 341 2644:** [Sticker]

[5:06 PM] **+52 1 662 449 3477:**
> _+52 1 631 125 1255: que como en años pasados, hay alumnos de primero que no van/no quieren su libreta, y se hara una lista para las personas interesadas en una_
este año no se manejará así

[5:13 PM] **+52 1 662 341 2644:**
> _+52 1 662 224 3927: En LCC es cosa de usos y costumbres respetar el primix_
Parece q no le va tocar

[5:13 PM] **+52 1 662 341 2644:** [Sticker]

[5:55 PM] **+52 1 662 449 3477:** con lo del centro de cómputo los que no fueron/no pudieron firmar que prosigue

[5:55 PM] **+52 1 662 449 3477:** @~lu @~Zuko

[5:55 PM] **+52 1 662 449 3477:** [Sticker]

[6:00 PM] **+52 1 662 296 3657:** No entran

[6:01 PM] **+52 1 662 296 3657:** Usen el sentido común

[6:02 PM] **+52 1 631 125 1255:** los vamos a linchar

[6:05 PM] **+52 1 662 948 4424:** Ah quién le interesa un cómic de Spider-Man? 👀

[6:05 PM] **+52 1 662 449 3477:**
> _+52 1 662 296 3657: Usen el sentido común_
ohh okay gracias

[6:08 PM] **+52 1 631 125 1255:** probablemente se deje una hoja para firmar antes de entrar los q no firmaron

[6:08 PM] **+52 1 662 367 1384:** ¿Cómo saben quién sí y quien no? O sea, ya se que la maestra Sonia tiene una hoja con las firmas, pero en la práctica del día a día, ¿como saben quien sí y quien no debe estar adentro? ¿Y si alguien que no debe estar está, cómo lo van a sacar?

[6:09 PM] **+52 1 631 125 1255:** o lo de al entrar al cc se toma como que aceptan los lineamientos del mismo

[6:09 PM] **+52 1 631 125 1255:** de igual, la omisión del conocimiento de los lineamientos no implica la omision del cumplimiento del mismo

[6:09 PM] **+52 1 631 125 1255:** aka, no saber el reglamento no significa q no los saquen o amonesten si no lo cumplen

[6:10 PM] **+52 1 631 125 1255:**
> _+52 1 662 367 1384: ¿Cómo saben quién sí y quien no? O sea, ya se que la maestra Sonia tiene una hoja con las firmas, pero en la práctica del día a día, ¿como saben quien sí y quien no debe estar adentro? ¿Y si alguien que no debe estar está, cómo lo van a sacar?_
los vamos a poner como en rateros del oxxo

[6:10 PM] **+52 1 662 350 4258:**
> _+52 1 631 125 1255: los vamos a linchar_
yo pongo la cinta pa' que parezcan disfraz de cachora

[7:31 PM] **+52 1 662 296 3657:**
> _+52 1 662 367 1384: ¿Cómo saben quién sí y quien no? O sea, ya se que la maestra Sonia tiene una hoja con las firmas, pero en la práctica del día a día, ¿como saben quien sí y quien no debe estar adentro? ¿Y si alguien que no debe estar está, cómo lo van a sacar?_
Lo que realmente importa es que se comporten

---

## September 15, 2026

[5:57 AM] **+52 1 662 467 9029:** Le debo $0 a todos

[6:45 AM] **+52 1 637 117 9366:** [Forwarded] [Image]

[6:45 AM] **+52 1 637 117 9366:** [Forwarded] [Image]

[11:47 AM] __[System notification]__

[4:27 PM] **+52 1 662 449 3477:** amigas buen día

[4:27 PM] **+52 1 662 449 3477:** conocen a alguien que tenga el servicio de renta de mesas y sillas

[4:34 PM] **+52 1 662 342 4670:**
> _+52 1 662 449 3477: conocen a alguien que tenga el servicio de renta de mesas y sillas_
[Contact: BEGIN:VCARD
VERSION:3.0
N:;Nancy;;;
FN:Nancy
TEL;type=CELL;type=VOICE;waid=5216628483271:+52 662 848 3271
END:VCARD]

[4:34 PM] **+52 1 662 342 4670:**
> _+52 1 662 449 3477: amigas buen día_
Amigos*

[4:34 PM] **+52 1 662 342 4670:**
> _+52 1 662 342 4670: BEGIN:VCARD
VERSION:3.0
N:;Nancy;;;
FN:Nancy
TEL;type=CELL;type=VOICE;waid=5216628483271:+52 662 848 3271
END:VCARD_
Le puedes preguntar a ella, una vez le renté

[4:34 PM] **+52 1 662 342 4670:** [Sticker]

[4:44 PM] **+52 1 662 450 9504:** https://www.instagram.com/reel/DdUVNPCkvvX/?stkn=MTRjdmx2YW8wMXJ6bQ== awiwis mi primera huelga

[4:44 PM] **+52 1 662 450 9504:** _This message was deleted_

[4:45 PM] **+52 1 662 335 9011:**
> _+52 1 662 450 9504: https://www.instagram.com/reel/DdUVNPCkvvX/?stkn=MTRjdmx2YW8wMXJ6bQ== awiwis mi primera huelga_
[Sticker]

[4:47 PM] **+52 1 631 125 1255:**
> _+52 1 662 450 9504: https://www.instagram.com/reel/DdUVNPCkvvX/?stkn=MTRjdmx2YW8wMXJ6bQ== awiwis mi primera huelga_
ptm

[4:48 PM] **+52 1 631 125 1255:** despues de la 5ta a uno deja de parecerle gracioso

[4:48 PM] **+52 1 631 125 1255:** [Sticker]

[4:48 PM] **+52 1 662 335 9011:** tf gente, apenas me iba recuperando de las anteriores 🥀

[4:50 PM] **+52 1 662 341 2644:** algo mal

[4:57 PM] **+52 1 984 522 6144:**
> _+52 1 662 450 9504: https://www.instagram.com/reel/DdUVNPCkvvX/?stkn=MTRjdmx2YW8wMXJ6bQ== awiwis mi primera huelga_
[Sticker]

[5:06 PM] **+52 1 687 120 1981:**
> _+52 1 662 450 9504: https://www.instagram.com/reel/DdUVNPCkvvX/?stkn=MTRjdmx2YW8wMXJ6bQ== awiwis mi primera huelga_
[Sticker]

[5:59 PM] **+52 1 662 453 0888:**
> _+52 1 662 450 9504: https://www.instagram.com/reel/DdUVNPCkvvX/?stkn=MTRjdmx2YW8wMXJ6bQ== awiwis mi primera huelga_
[Sticker]

[6:28 PM] **+52 1 662 350 4258:**
> _+52 1 662 450 9504: https://www.instagram.com/reel/DdUVNPCkvvX/?stkn=MTRjdmx2YW8wMXJ6bQ== awiwis mi primera huelga_
y justo el semestre que me inscribí a eléctro

[6:33 PM] **+52 1 662 224 3927:** Eh plebes de 5to muchas gracias por la libreta está genial ✨

[6:35 PM] **+52 1 662 326 0064:** Denada :D

[6:35 PM] **+52 1 662 326 0064:** Que bueno que le gusto profe

[6:45 PM] **+52 1 662 460 2019:**
> _+52 1 662 450 9504: https://www.instagram.com/reel/DdUVNPCkvvX/?stkn=MTRjdmx2YW8wMXJ6bQ== awiwis mi primera huelga_
[Sticker]

[6:45 PM] **+52 1 662 460 2019:** Eso es real?

[6:45 PM] **+52 1 662 460 2019:** [Sticker]

[6:46 PM] **+52 1 634 113 0073:** Una pregunta, las libretas... van a dar otro día? Es que no fui por la mía

[6:47 PM] **+52 1 631 125 1255:** tu que crees hermanito

[6:47 PM] **+52 1 631 125 1255:** ahhhh t creas

[6:47 PM] **+52 1 631 125 1255:** @organizadores

[6:55 PM] **+52 1 662 245 0227:**
> _+52 1 634 113 0073: Una pregunta, las libretas... van a dar otro día? Es que no fui por la mía_
nt

[6:55 PM] **+52 1 634 113 0073:**
> _+52 1 662 245 0227: nt_
Si

[9:54 PM] **+52 1 662 449 3477:**
> _+52 1 634 113 0073: Una pregunta, las libretas... van a dar otro día? Es que no fui por la mía_
otro día será el día viernes igual a las 11. Quien no las pueda recoger ese día ya no se podrán recoger después

---

## September 16, 2026

[5:14 PM] **+52 1 662 449 3477:** hola gente andamos viendo aprox cuánta gente irá el viernes a la fiesta ajena a la universidad

[5:15 PM] **+52 1 662 449 3477:** **Poll: quien irá, viernes 18**
- yo
- yo no

[5:15 PM] **+52 1 662 449 3477:** por si nos pueden ayudar votando si irán de los agradecería

[5:15 PM] **+52 1 662 127 2301:** Por las libretas o a clases?

[5:15 PM] **+52 1 662 127 2301:** [Sticker]

[5:16 PM] **+52 1 662 449 3477:**
> _+52 1 662 127 2301: Por las libretas o a clases?_
a la fiesta mi vida

[5:16 PM] **+52 1 662 367 8720:** cena mexicana

[5:16 PM] **+52 1 662 367 8720:** jeje

[5:16 PM] **+52 1 662 127 2301:** Aah JAJAJA

[5:16 PM] **+52 1 662 127 2301:** [Sticker]

[5:18 PM] **+52 1 662 449 3477:**
> _+52 1 662 449 3477: [poll_creation]_
no hay que pagar nada, es el 18 a las 8 pm, por el norte de la ciudad

[5:31 PM] **+52 1 662 395 2865:** [Sticker]

[6:09 PM] __[System notification]__

[7:51 PM] **+52 1 662 431 3826:**
> _+52 1 662 449 3477: no hay que pagar nada, es el 18 a las 8 pm, por el norte de la ciudad_
todavía no van a enviar la dirección exacta? o ya la enviaron y no la vi?

---

## September 17, 2026

[10:57 AM] **+52 1 662 127 2301:** Holaa, oigan, los que falten en firmar la hoja del cc, estoy afuera de el 3k4, en una banca al lado de la calle, recibiendo firmas de 11 am a 12 pm y de nuevo de 3pm a 4pm, los que quieran firmar pasen conmigo por favor

[11:05 AM] **+52 1 662 288 0177:** [Image] hola dejaron esto tirado por si alguien lo está buscando

[11:06 AM] **+52 1 662 326 0064:**
> _+52 1 662 127 2301: Holaa, oigan, los que falten en firmar la hoja del cc, estoy afuera de el 3k4, en una banca al lado de la calle, recibiendo firmas de 11 am a 12 pm y de nuevo de 3pm a 4pm, los que quieran firmar pasen conmigo por favor_
que implica eso?

[12:18 PM] **+52 1 662 463 6894:**
> _+52 1 662 326 0064: que implica eso?_
La firma es para tener acceso al cc cuando lo abran de nuevo

[12:18 PM] **+52 1 662 463 6894:** Tuvimos junta el lunes 🤓

[12:20 PM] **+52 1 662 450 9504:** Cuando lo abrirán?

[12:20 PM] **+52 1 662 326 0064:**
> _+52 1 662 463 6894: Tuvimos junta el lunes 🤓_
gracias, yo no puedo atender esas juntas porque tengo actividades de una beca... Sonia sabe.

[12:21 PM] **+52 1 662 446 0922:**
> _+52 1 662 326 0064: que implica eso?_
Tengo entendido que solo te comprometes a seguir las reglas ya existentes del cc

[12:21 PM] **+52 1 662 463 6894:** Aaa okey, sí es nomás para que pongas que sabes el reglamento y así

[12:21 PM] **+52 1 662 326 0064:** oki doks, gracias. ya firme

[12:21 PM] **+52 1 662 463 6894:**
> _+52 1 662 450 9504: Cuando lo abrirán?_
No sabemos aún

[12:24 PM] **+52 1 662 142 7436:** [Sticker]

[12:26 PM] **+52 1 662 385 5717:** [Image] Eee alguien a visto el derecho de este audífono? Se me perdio hoy

[12:26 PM] **+52 1 662 385 5717:** [Sticker]

[1:20 PM] **+52 1 662 405 5709:**
> _+52 1 662 127 2301: Holaa, oigan, los que falten en firmar la hoja del cc, estoy afuera de el 3k4, en una banca al lado de la calle, recibiendo firmas de 11 am a 12 pm y de nuevo de 3pm a 4pm, los que quieran firmar pasen conmigo por favor_
mañana todavia podemos firmar?

[1:21 PM] **+52 1 662 127 2301:** Hoy es el último día, para poder darle la lista a Sonia lo antes posible

[1:21 PM] **+52 1 662 405 5709:** ni tenia ganas de entrar al cc

[1:21 PM] **+52 1 662 405 5709:** [Sticker]

[1:26 PM] **+52 1 662 127 2301:** [Sticker]

[2:03 PM] **+52 1 662 467 9029:** No van hacer tutorial de como no fumar mota en el baño?

[3:01 PM] **+52 1 662 467 9029:** Le debo un boing de guayaba a la Juliana

[4:10 PM] **+52 1 662 460 2019:**
> _+52 1 662 467 9029: No van hacer tutorial de como no fumar mota en el baño?_
[Sticker]

[8:00 PM] **+52 1 662 342 4670:**
> _+52 1 662 467 9029: No van hacer tutorial de como no fumar mota en el baño?_
Llevarán al rompehielos?, para ver si vale la pena ir

[8:01 PM] **+52 1 662 449 3477:** compañera sería preferible que no anden fumando esas cosas

[8:02 PM] **+52 1 662 342 4670:** Sarcasmo x1000 xd

[8:02 PM] **+52 1 662 342 4670:** Puro fourloko, perdonen

[8:02 PM] **+52 1 662 365 9837:** Cómo que era sacarsmo

[8:02 PM] **+52 1 662 342 4670:** [Sticker]

[8:02 PM] **+52 1 662 365 9837:** Ya me había emocionado

[8:02 PM] **+52 1 662 365 9837:** [Sticker]

[8:02 PM] **+52 1 662 476 3432:**
> _+52 1 662 449 3477: compañera sería preferible que no anden fumando esas cosas_
ni pa que voy

[8:02 PM] **+52 1 662 342 4670:**
> _+52 1 662 365 9837: Ya me había emocionado_
Hay que organizar after pues

[8:04 PM] **+52 1 662 342 4670:** Presto mi casa para el after

[8:04 PM] **+52 1 662 365 9837:** [Sticker]

[8:04 PM] **+52 1 662 342 4670:** O una casa en el Villa de sería, más cercas

[8:04 PM] **+52 1 662 365 9837:** Yo pongo mota

[8:05 PM] **+52 1 662 342 4670:** Saquen el viviooooo

[8:05 PM] **+52 1 662 365 9837:** [Sticker]

[8:05 PM] **+52 1 662 342 4670:** Yo pongo fourloko

[8:05 PM] **+52 1 662 342 4670:** Pa que no falten

[8:05 PM] **+52 1 662 365 9837:** Afuera de la casa del estudiante es un punto de venta de mota

[8:05 PM] **+52 1 662 365 9837:** Nomás digo

[8:06 PM] **+52 1 662 365 9837:** [Sticker]

[8:06 PM] **+52 1 662 637 5722:**
> _+52 1 662 342 4670: Llevarán al rompehielos?, para ver si vale la pena ir_
si voy, sí

[8:06 PM] **+52 1 662 342 4670:**
> _+52 1 662 365 9837: Afuera de la casa del estudiante es un punto de venta de mota_
Aquí hay cerca de mi casa bro, en casi todos mis alrededores vivo en Gala, enseguida de la nuevo XD

[8:07 PM] **+52 1 662 342 4670:**
> _+52 1 662 365 9837: Yo pongo mota_
Amistad es compartir

[8:07 PM] **+52 1 662 365 9837:**
> _+52 1 662 342 4670: Aquí hay cerca de mi casa bro, en casi todos mis alrededores vivo en Gala, enseguida de la nuevo XD_
Precio y pq tan caro

[8:07 PM] **+52 1 662 365 9837:** [Sticker]

[8:07 PM] **+52 1 662 637 5722:**
> _+52 1 662 637 5722: si voy, sí_
junto con un pozole pa bajar avión

[8:08 PM] **+52 1 662 342 4670:**
> _+52 1 662 637 5722: si voy, sí_
No faltes bro, muy importante que vengas

[8:08 PM] **+52 1 662 342 4670:** Pues fuera de cura sí puedo poner mi casa 🏠, si gustan hacer after en mi casita están invitados.

[8:08 PM] **+52 1 662 365 9837:** [Sticker]

[8:08 PM] **+52 1 662 342 4670:** O en el Villa de Seris vive mi abuela ahí y es terreno grande

[8:08 PM] **+52 1 662 365 9837:** Ya dijo

[8:08 PM] **+52 1 662 365 9837:** Tomen cap

[8:08 PM] **+52 1 662 476 3432:** culo el que no lleve mota

[8:09 PM] **+52 1 662 342 4670:**
> _+52 1 662 365 9837: Precio y pq tan caro_
Bara, bara pa que salga

[8:09 PM] **+52 1 662 365 9837:**
> _+52 1 662 342 4670: Bara, bara pa que salga_
Presupuesto

[8:09 PM] **+52 1 662 365 9837:** 2500

[8:09 PM] **+52 1 662 365 9837:** [Sticker]

[8:10 PM] **+52 1 662 342 4670:** Cerrada Empalme #261

[8:10 PM] **+52 1 662 342 4670:** Aquí andaré en mi casita para el que le quiera caer

[8:10 PM] **+52 1 662 342 4670:** [Sticker]

[8:10 PM] **+52 1 662 365 9837:**
> _+52 1 662 342 4670: Aquí andaré en mi casita para el que le quiera caer_
[Sticker]

[8:10 PM] **+52 1 662 365 9837:** No sé quién eres

[8:10 PM] **+52 1 662 342 4670:** Pd: sin mot4 no entran

[8:10 PM] **+52 1 662 365 9837:** Pero ahí estare

[8:10 PM] **+52 1 662 365 9837:** [Sticker]

[8:13 PM] **+52 1 662 342 4670:** A mi ya me dieron luz verde en la casa

[8:14 PM] **+52 1 662 342 4670:** Tráiganse bocinaaas

[8:14 PM] **+52 1 662 342 4670:** Yo pondré algo de pisto

[8:14 PM] **+52 1 662 342 4670:** [Sticker]

[8:14 PM] **+52 1 662 342 4670:** [Sticker]

[8:19 PM] **+52 1 631 125 1255:** pero pasen la ubi pues

[8:19 PM] **+52 1 662 637 5722:**
> _+52 1 662 342 4670: Cerrada Empalme #261_
[Image] acá?

[8:23 PM] **+52 1 662 342 4670:**
> _+52 1 662 637 5722: Image: acá?_
Shiiiii

[8:23 PM] **+52 1 662 342 4670:**
> _+52 1 631 125 1255: pero pasen la ubi pues_
Cerrada Empalme #261

[8:24 PM] **+52 1 662 637 5722:**
> _+52 1 662 342 4670: Shiiiii_
ta muy lejos, el rompehielos dijeron sería al norte, no?

[8:24 PM] **+52 1 662 342 4670:** Pues pueden ir a donde gusten

[8:24 PM] **+52 1 662 342 4670:** Aquí puede ser el after

[8:24 PM] **+52 1 662 342 4670:** O aquí pueden venir desde temprano, como vean

[8:25 PM] **+52 1 662 335 9011:**
> _+52 1 662 476 3432: ni pa que voy_
WOW no te conocía así tilin 🥀

[8:25 PM] **+52 1 662 476 3432:**
> _+52 1 662 335 9011: WOW no te conocía así tilin 🥀_
[Sticker]

[8:26 PM] **+52 1 662 335 9011:** [Sticker]

[8:27 PM] **+52 1 631 125 1255:**
> _+52 1 662 342 4670: Cerrada Empalme #261_
del rompehielos?

[8:27 PM] **+52 1 631 125 1255:** [Sticker]

[8:27 PM] **+52 1 662 637 5722:** Allá va a haber platos y cubiertos?

[8:28 PM] **+52 1 662 342 4670:**
> _+52 1 631 125 1255: del rompehielos?_
Pues puedo prestar mi casa como gusten

[8:28 PM] **+52 1 662 342 4670:**
> _+52 1 662 637 5722: Allá va a haber platos y cubiertos?_
En mi casa o al norte?, en el norte no sé

[8:28 PM] **+52 1 662 342 4670:** En mi casa siiii

[8:28 PM] **+52 1 662 342 4670:** Pondré 500 de pisto

[8:28 PM] **+52 1 662 342 4670:** Ya me mandó mensaje uno el que nos patrocinará la mot4, JAJJAJAJA

[8:29 PM] **+52 1 662 367 8720:** ?

[8:29 PM] **+52 1 634 109 6592:** [Sticker]

[8:29 PM] **+52 1 662 342 4670:** Pero lleguen orneados o váyanse al campo a fumar aquí en mi casa nooo

[8:29 PM] **+52 1 662 365 9837:** [Sticker]

[8:29 PM] **+52 1 662 342 4670:** Por cierto en mi casa hay 2 baños, por si llegan con las pisto y así no tendrían que hacer mucha fila

[8:29 PM] **+52 1 631 125 1255:** no es de q, mañana el rompehielos de la carrera?

[8:29 PM] **+52 1 662 367 8720:** si querían hacer una fiesta a parte, la pondrían haber hecho en cualquier fecha menos mañana

[8:30 PM] **+52 1 662 367 8720:** pero bueno, no somos sus papás, hagan lo que quieran

[8:30 PM] **+52 1 662 342 4670:**
> _+52 1 662 367 8720: si querían hacer una fiesta a parte, la pondrían haber hecho en cualquier fecha menos mañana_
Yo digo afteerrr, es de que más tardeee y así

[8:30 PM] **+52 1 662 342 4670:** Pero bueno, ya vendrán 2 de que más tardecito

[8:31 PM] **+52 1 631 125 1255:** ps siempre q no sea de q, a la misma hora creo q tdbn

[8:31 PM] **+52 1 631 125 1255:** pq si se me hace medio wason hacerla el mismo dia q el rompehielos

[8:31 PM] **+52 1 631 125 1255:** jaja lol

[8:31 PM] **+52 1 631 125 1255:** [Sticker]

[8:31 PM] **+52 1 662 367 8720:**
> _+52 1 662 342 4670: Yo digo afteerrr, es de que más tardeee y así_
están a 20 km de distancia…

[8:32 PM] **+52 1 662 367 8720:** [Sticker]

[8:32 PM] **+52 1 662 327 9060:** En un carro si entran 8 personas bien acomodadas

[8:33 PM] **+52 1 662 342 4670:**
> _+52 1 662 327 9060: En un carro si entran 8 personas bien acomodadas_
/9j/4AAQSkZJRgABAQAASABIAAD/4QCMRXhpZgAATU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAOgAQADAAAAAQABAACgAgAEAAAAAQAAAGSgAwAEAAAAAQAAAGQAAAAA/+0AOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/AABEIAGQAZAMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2wBDAAYGBgYGBgoGBgoOCgoKDhIODg4OEhcSEhISEhccFxcXFxcXHBwcHBwcHBwiIiIiIiInJycnJywsLCwsLCwsLCz/2wBDAQcHBwsKCxMKChMuHxofLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi7/3QAEAAf/2gAMAwEAAhEDEQA/AOCxH3akxH/erQN/cKMlI/ypPt9xgEInPA4NepqcBIkJubOCMdN5yR2HNSTRg/LMPLtYv4e7kf0/nVfU72eJ1tbdtrFcuQOmfSs2SaWXHmuWx0zWcpcpE6qjoSXNy9zJvbgDhR6Cq9FFczdzjbbd2FFFFAgooooAKKKKAHRSPACsWwAnPzRo3P1YE1L9qn/6Z/8AfmL/AOJqCinzMv2ku5//0PN9x9acsjqQQTkHIplNZtqlvSvQV3oj5JTk3ox6yPM7zyHLOev04p9WbSznliHlgYXgknHNWv7NuvRfzoqU05N3PX9hfVszOa1tH0+O/u1jncRx7lUs3AG44yfYdTSpp1wpy238/wD61XbKCa3ZhIV2t3B5z27Vy4qlJUpOluejlNCh9bp/Wn7l9f0v5Xtc1dV0axs7yWxjeOdYzgSxcA8Z4Pt071xc0TQytEedpxmuxYeWodyApGQfXHpXO3EckrszOgLHPWvPyyFVuTqXS8z6TiyjgXGksM059XG23nbT0MvBpcH0rTW0kcAbk496l+wzAk7k5PrXseyXc+K+rmOFJ6CkwfStg2E2chk9OtINPmC43p19f/rUeyXcf1dGUEc8gGjY/wDdNbP2KYcFkz9f/rUv2OX+8n5//Wp+yj3F7A//0fNqjBEswjHIHJ+vYUhJkOF4XufX6URgLcALx8tepGNtXufMUIpTV9zeXcumv2PmD+lUGbJ4zWpahGsWEjbRv6n8KiNraA83AH4Uj2SqCmA2DTQVUnI6/wAjV5YrRRgXH6U1obJjk3H6U7isaV9zoloF6eU/H/bRq4oRSF846V3lysI0m1RXynlv83tvNYqw2ZGTOfTgVnHUuRmQxnZk+uakGN2QPetNYrEAoJj+X/1qjEVgOk7fl/8AWq7k2KQGWJC5zTijBMYHXNXlisl4Ezfl/wDWp22xxgysc+3/ANandCsQ6ns+0AsucqKzv3f9z9a2L5FaVTz9wf1ql5S+9SUf/9LzCSVIlxkA9gacEaK4Qlw4ccHGDwM9PTng1AzTJCW2ELI2RnlWBAG1wDxxyKks4wsqKxJwMDJz+Ar2XFQjZ7s+ciowcU92zfiz/Z0uOzA/yqi3J65rWt/KW2m8xSy5GQKhMlg3Jik/P/69YnqlIM2dwHXik3MFPHU1fDafwRHJ6/55pMacxPyyCncViaO5mnsRA0YUW6FQc53bmLDjHHFUAXx0H51oRzWaRlE34cY6VERYjj96aUdBvUpBXD7sdaQhsleOeau5sOm2X/P407bp452ufx/+vTuKxUG/vimlXJ5x0q4z2KDPlyHA9f8A69V/tumqf9VJ+f8A9ehyInOMPiZcu+HT/cFVc09tS06XDSK4IGOnb8DTftulej/l/wDXqbi9vS/mR//T8rkDIEh8xZF6443jHQNgkYHapIv9Yv1qH5y29zliME4AJ9zjqangSSWeOKJS7uwVVHUsxwAPqa9atNSldHys581VWNhY55FZhgCMbjz1qv5h55616dafDjxFbQXLXSQbjGrITcbUTaSX34UknHA/h5JJ4FYVpp1vd+G7rW0A+0W82Fhwu14kRWkI4zlQ27rjA6Vh7VHv+zZxwkYcA0bzzz1rsNO063vdB1HWrgCI2qEwIu394yFTITlT8qhlHGOTVSTT9ShtGvZLBAiRiVl3oZFjbo7Rg71U5HJWq9or2FyPc5oSMBgGnq7EMc9K6yDRtVmTedPALRCaNd0e+RCu7KJu3Nx12g46dap29lqV1brc21lGySKzRjegeRUzuZIyQ7gYPQHoaPaLuLkZzoYnLZxQZW9avrfZxiGPBGRSreswyIo/yq9SdDNaQlSCazpCC3XNdE1/Iv8Ayzj/ACpVv5cj5Ixn2pO5z4jDqrbWxzQBPQUbW9DXeROGiRzgFlB/OpNy+oqTm/s1fzH/1PK6s2VzJZXsF5CAXglSRQehKMGA/SqoORz171JGSJFI5Oa9Jroz46N4zR9Sj4heEL60eKaWQiWEmSLynJAYYKEgYz264968Us9Xg02ytvLVmaHUHmaFgSWtnhEbKWxg5XKn35rHspfLkcyEL8pxnjmg390MjcvA9KzVFLQ+ndVvU6C7v9LhS807TZHezi06S0tWZGBlkkkSRmIxwWOeuBhRV03nh+x/tAWDQLDcafNDCFhla53tGBiWRhgEkEcEg8dAK5A6jdjuv5UDUbog8rx7UexD2h6Ezafa63p2q3N3sNpZWMjxbHaQ+XGHVYyAVw3Q5Ixk1gWF5plxbwDW5YJrdBKWhaGRbqDczMEt5Y+GXJyNzADJyBWLaXc8olMjbiiDBOSflGAOSeABgCqw1G727sr+VJUu7G6hSjViArA8CgKdpODmrq6jdE4LKPwpV1C6YEllGPatjIoBTg5Bz2oVSTyDj6VeGo3WCdy/lSf2ld+q/lQBswophjyP4RUnlp6UkLs8KO3VlBNSVIz/1fLZBiTjuKFJDAjqDRL/AKwfT+tIOor05dD5CfxI2D8zKD0xUbgbyBUg++v0pj/fNUfQEyqNxHpioV/1n41Ov32/CoB/rPxoYjRtes//AFz/AMaoQgEHNX7XrP8A9c/8aowdDSW43sGAJcdqhqb/AJa1DQwHkDYD60ynt/q1/GmUAdRb/wDHvH/uj+VTVDb/APHvH/uj+VTVBR//2Q==: Location: 29.004308700561523, -110.92276000976562 — https://maps.google.com/?q=29.004308700561523,-110.92276000976562

[8:34 PM] **+52 1 662 342 4670:** Pues aquí estaremos de que yo y uno de la carrera desde temprano, ya si gustan venir más noche o en la madrugada también son bienvenidos, pueden traer pisto y así, yo compraré un 500

[8:34 PM] **+52 1 662 342 4670:** + lo otro

[8:34 PM] **+52 1 662 342 4670:** [Sticker]

[8:35 PM] **+52 1 662 637 5722:** La cena dónde va a ser?

[8:35 PM] **+52 1 631 125 1255:** pal norte

[8:35 PM] **+52 1 662 637 5722:** but qué colonia o q

[8:35 PM] **+52 1 631 125 1255:** ah nose w

[8:35 PM] **+52 1 631 125 1255:** no ando coordinando esa madre

[8:35 PM] **+52 1 631 125 1255:** @rompehielos organizadores

[8:35 PM] **+52 1 631 125 1255:** ayuda

[8:36 PM] **+52 1 662 367 8720:** lomas del norte

[8:36 PM] **+52 1 662 637 5722:** [album message]

[8:36 PM] **+52 1 662 637 5722:** [Image] Va a estar bien lejos el after jaja

[8:36 PM] **+52 1 662 637 5722:** _This message was deleted_

[8:37 PM] **+52 1 662 245 0227:** que grande, con el comprobante

[8:38 PM] **+52 1 662 365 9837:** [Sticker]

[8:38 PM] **+52 1 631 125 1255:**
> _+52 1 662 245 0227: que grande, con el comprobante_
iba pagando el uber rumbo al after para no andar a las carreras mañana

[8:39 PM] **+52 1 631 125 1255:** jaja q ondeados se ponen

[8:39 PM] **+52 1 631 125 1255:** [Sticker]

[8:40 PM] **+52 1 631 125 1255:** fua, no era ese sticker

[8:41 PM] **+52 1 662 111 6493:**
> _+52 1 631 125 1255: fua, no era ese sticker_
pero bn q lo dejaste w

[8:41 PM] **+52 1 662 373 9949:**
> _+52 1 631 125 1255: fua, no era ese sticker_
Y pa acabarla de chingar es mentira

[8:41 PM] **+52 1 662 245 0227:** ya era demasiado tarde para quitarlo

[8:41 PM] **+52 1 662 373 9949:**
> _+52 1 662 111 6493: pero bn q lo dejaste w_
Si lo borraba perdía aura

[8:41 PM] **+52 1 631 125 1255:** en efecto

[8:44 PM] **+52 1 662 342 4670:**
> _+52 1 662 637 5722: [album]_
Mujeres se pueden quedar a dormir en mi cuarto/sala… hombres afuera JAJAJAJAJA

[8:44 PM] **+52 1 662 342 4670:** Ahí les saco un sofá cama por si se quedan botados xd

[8:45 PM] **+52 1 662 342 4670:** [Sticker]

[8:57 PM] **+52 1 662 224 3927:** Bonita noche hackers 🌙. Realmente no quiero sonar paternalista ni condescendiente con ningún miembro de esta hermosa comunidad que hasta donde sé todos somos adultos pensantes aquí. Recuerden cuidarse a ustedes mismos y entre ustedes. Es importante que mantengan su integridad física, emocional y mental. Piensen antes de actuar para no ponerse en riesgo ustedes ni poner en riesgo a otra persona. Si llegan a consumir estupefacientes sepan que sus acciones bajo la influencia de cualquier sustancia no les exime de la responsabilidad de las consecuencias. Diviértanse y tengan cuidado por favor 👍

[8:57 PM] **+52 1 662 224 3927:** [Sticker]

[8:59 PM] **+52 1 662 335 9011:** [Sticker]

[9:15 PM] **+52 1 662 637 5722:** oigan pero sí va a haber desechables para la cena?

[9:30 PM] **+52 1 662 449 3477:** sii

[9:38 PM] **+52 1 662 299 4587:** [Sticker]

[9:51 PM] **+52 1 662 405 5709:**
> _+52 1 662 637 5722: [album]_
un poquito más al sur y la hacen en obregon w

[9:52 PM] **+52 1 644 422 2240:**
> _+52 1 662 405 5709: un poquito más al sur y la hacen en obregon w_
esa onda

[9:52 PM] **+52 1 644 422 2240:** [Sticker]

[10:23 PM] **+52 1 662 637 5722:** [Sticker]

---

## September 18, 2026

[8:48 AM] **+52 1 662 501 3191:** [Sticker]

[8:54 AM] **+52 1 662 467 9029:** [Image] @Primero

Hola. A los 1ro que iran al rompehielos ajeno a la a la universidad y piensan tomar,  les encargo que traigan su INE si quieren evitar que los ande interrogando :]

Y a los que cachemos con sustancias raras les voy a tomar foto 🌺

[8:55 AM] **+52 1 662 399 2340:**
> _+52 1 662 467 9029: Image: @Primero

Hola. A los 1ro que iran al rompehielos ajeno a la a la universidad y piensan tomar,  les encargo que traigan su INE si quieren evitar que los ande interrogando :]

Y a los que cachemos con sustancias raras les voy a tomar foto 🌺_
Ey pero si va haber rocola de iPhone?

[8:56 AM] **+52 1 662 340 5659:**
> _+52 1 662 467 9029: Image: @Primero

Hola. A los 1ro que iran al rompehielos ajeno a la a la universidad y piensan tomar,  les encargo que traigan su INE si quieren evitar que los ande interrogando :]

Y a los que cachemos con sustancias raras les voy a tomar foto 🌺_
apoco si muy antro

[8:56 AM] **+52 1 633 335 6651:** [Forwarded] apoco si muy antro

[8:56 AM] **+52 1 662 399 2340:** Van a poner de cadenero al niño del post

[8:56 AM] **+52 1 662 637 5722:**
> _+52 1 662 399 2340: Ey pero si va haber rocola de iPhone?_
yo tengo una bocina pequeña

[8:57 AM] **+52 1 662 637 5722:** [Image]

[8:58 AM] **+52 1 662 399 2340:**
> _+52 1 662 637 5722: Image_
Algo bello

[9:45 AM] **Amado Rosas:**
> _+52 1 662 467 9029: Image: @Primero

Hola. A los 1ro que iran al rompehielos ajeno a la a la universidad y piensan tomar,  les encargo que traigan su INE si quieren evitar que los ande interrogando :]

Y a los que cachemos con sustancias raras les voy a tomar foto 🌺_
fourloko cuenta como sustancia rara?

[9:50 AM] **+52 1 662 395 2865:**
> _Amado Rosas: fourloko cuenta como sustancia rara?_
mientras no lo vomites afuera del edificio

[10:15 AM] **+1 (702) 203-9803:** Alguien de aqui tiene tijeras? Que me preste

[10:17 AM] **+52 1 662 369 3580:**
> _+1 (702) 203-9803: Alguien de aqui tiene tijeras? Que me preste_
Yo tengo

[10:17 AM] **+52 1 662 369 3580:** [Sticker]

[10:17 AM] **+1 (702) 203-9803:** Omg

[10:18 AM] **+52 1 662 369 3580:**
> _+1 (702) 203-9803: Omg_
Eee solo k estoy en clase con el profe villa

[11:11 AM] **+52 1 662 342 9577:** Dónde va a ser la fiesta a la noche?

[11:11 AM] **+52 1 662 342 9577:** [Sticker]

[11:33 AM] **+52 1 662 102 9392:** ._.

[11:33 AM] **+52 1 662 295 4218:** A q hora van a pasar la ubicación?

[11:36 AM] **+52 1 662 139 3528:** Oigan vamos a estar entregando libretas para los de primero

[11:36 AM] **+52 1 662 139 3528:** Enfrente del edificio

[11:37 AM] **+52 1 662 139 3528:** @nuevo_ingreso

[11:45 AM] **+52 1 645 107 9121:**
> _+52 1 662 139 3528: Enfrente del edificio_
otra vez?

[11:45 AM] **+52 1 662 139 3528:**
> _+52 1 645 107 9121: otra vez?_
Estamos al lado

[11:45 AM] **+52 1 662 139 3528:** En el hexágono

[11:45 AM] **+52 1 662 467 9029:**
> _+52 1 662 295 4218: A q hora van a pasar la ubicación?_
Ni yo sé, pero les aviso que es muy al norte

[11:52 AM] **+52 1 662 637 5722:** Habrá dónde calentar la comida?

[11:55 AM] **+52 1 662 467 9029:**
> _+52 1 662 637 5722: Habrá dónde calentar la comida?_
@~Jerry's cerrajería

[12:33 PM] **+52 1 662 467 9029:** Ya pasé la ubicacion del rompehielos ajeno a la universidad en los avisos 🗣️🗣️

[1:22 PM] **+52 1 645 107 9121:** por qué tan lejos

[1:30 PM] **+52 1 662 467 9029:** Esq nadie más puso casa

[1:30 PM] **+52 1 662 467 9029:** :(

[1:34 PM] **+52 1 662 450 9504:** Pal siguiente año voy a poner el rancho de mi abuelo

[1:34 PM] **+52 1 662 450 9504:** [Sticker]

[1:35 PM] **+52 1 662 365 9837:** [Sticker]

[1:42 PM] **+52 1 662 107 1052:** Saben si hoy hay clase de procesamiento de imagen ?

[1:42 PM] **+52 1 662 373 9949:**
> _+52 1 662 107 1052: Saben si hoy hay clase de procesamiento de imagen ?_
yo te puedo decir que no sé

[1:43 PM] **+52 1 634 109 6592:**
> _+52 1 662 107 1052: Saben si hoy hay clase de procesamiento de imagen ?_
Hasta el lunes, igual dijo que estará ahí por si hay dudas de la tarea

[1:43 PM] **+52 1 662 107 1052:** Thankx

[5:00 PM] **+52 1 662 637 5722:** raza no se hizo el pozole :c

[5:01 PM] **+52 1 662 637 5722:** [Image] But va a ser gallina pinta 🤙🏾

[5:07 PM] **+52 1 645 115 6843:** [Image] y ahora que paso?

[5:08 PM] **+52 1 662 164 8356:**
> _+52 1 645 115 6843: Image: y ahora que paso?_
Bruh

[5:22 PM] **+52 1 662 460 2019:**
> _+52 1 645 115 6843: Image: y ahora que paso?_
[Sticker]

[5:26 PM] **+52 1 662 142 7436:**
> _+52 1 645 115 6843: Image: y ahora que paso?_
Fue @~richardo 🦦

[5:27 PM] **+52 1 645 107 9121:**
> _+52 1 662 142 7436: Fue @~richardo 🦦_
esta vez si fue uno de primer semestre

[5:27 PM] **+52 1 662 142 7436:** Y @~oSCiel tambien fue

[5:27 PM] **+52 1 645 107 9121:** si también yo

[5:27 PM] **+52 1 662 142 7436:** [Sticker]

[5:29 PM] **+52 1 662 355 6273:** [Sticker]

[6:10 PM] **+52 1 662 398 3314:**
> _+52 1 645 115 6843: Image: y ahora que paso?_
[Sticker]

[6:23 PM] **+52 1 662 142 7436:**
> _+52 1 662 355 6273: Sticker_
Fue @~Leo

[6:47 PM] **+52 1 662 355 6273:**
> _+52 1 662 142 7436: Fue @~Leo_
[Sticker]

[8:13 PM] **+52 1 662 460 2019:**
> _+52 1 662 355 6273: Sticker_
[Sticker]

[8:14 PM] **+52 1 662 460 2019:** Me quedo con ese sticker

[8:57 PM] **+52 1 662 637 5722:** ya empezó la fiesta

[8:57 PM] **+52 1 662 637 5722:** ?

[8:57 PM] **+52 1 662 345 5958:** Pues yo voy llegando y ya hay algunas personas

[8:57 PM] **+52 1 662 345 5958:** [Sticker]

[8:58 PM] **+52 1 662 637 5722:**
> _+52 1 662 345 5958: Pues yo voy llegando y ya hay algunas personas_
q hay de comida

[8:58 PM] **+52 1 662 637 5722:** 👀

[8:58 PM] **+52 1 662 418 1934:** De cuales sabritas faltan

[8:58 PM] **+52 1 662 418 1934:** [Sticker]

[8:58 PM] **+52 1 662 345 5958:**
> _+52 1 662 637 5722: q hay de comida_
Desconozco, no he visto ni preguntado nada

[8:59 PM] **+52 1 662 345 5958:** [Sticker]

[9:27 PM] **+52 1 662 367 8720:**
> _+52 1 662 637 5722: q hay de comida_
pepihuates, duros, donitas

[9:28 PM] **+52 1 662 367 8720:** [Sticker]

[9:28 PM] **+52 1 662 367 8720:** para botanear

[9:28 PM] **+52 1 662 449 3477:**
> _+52 1 662 418 1934: De cuales sabritas faltan_
las tuyas

[9:29 PM] **+52 1 662 418 1934:**
> _+52 1 662 449 3477: las tuyas_
Para ver de cuáles llevo ps

[9:29 PM] **+52 1 662 418 1934:** [Sticker]

[9:30 PM] **+52 1 662 418 1934:** 3 tonayan voy a llevar así bn rico

[9:30 PM] **+52 1 662 449 3477:** las que gustes said

[9:30 PM] **+52 1 662 449 3477:** igual se te criticarán los gustos

[9:32 PM] **+52 1 662 418 1934:** [Sticker]

[9:32 PM] **+52 1 662 418 1934:** Oki

[9:35 PM] **+52 1 662 342 4670:** [Image]

[9:36 PM] **+52 1 662 342 4670:** Cuando le quieran caer de allá para acá, aquí andamos

[9:36 PM] **+52 1 662 342 4670:** /9j/4AAQSkZJRgABAQAASABIAAD/4QCMRXhpZgAATU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAOgAQADAAAAAQABAACgAgAEAAAAAQAAAGSgAwAEAAAAAQAAAGQAAAAA/+0AOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/AABEIAGQAZAMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2wBDAAYGBgYGBgoGBgoOCgoKDhIODg4OEhcSEhISEhccFxcXFxcXHBwcHBwcHBwiIiIiIiInJycnJywsLCwsLCwsLCz/2wBDAQcHBwsKCxMKChMuHxofLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi7/3QAEAAf/2gAMAwEAAhEDEQA/AOCxH3akxH/erQN/cKMlI/ypPt9xgEInPA4NepqcBIkJubOCMdN5yR2HNSTRg/LMPLtYv4e7kf0/nVfU72eJ1tbdtrFcuQOmfSs2SaWXHmuWx0zWcpcpE6qjoSXNy9zJvbgDhR6Cq9FFczdzjbbd2FFFFAgooooAKKKKAHRSPACsWwAnPzRo3P1YE1L9qn/6Z/8AfmL/AOJqCinzMv2ku5//0PN9x9acsjqQQTkHIplNZtqlvSvQV3oj5JTk3ox6yPM7zyHLOev04p9WbSznliHlgYXgknHNWv7NuvRfzoqU05N3PX9hfVszOa1tH0+O/u1jncRx7lUs3AG44yfYdTSpp1wpy238/wD61XbKCa3ZhIV2t3B5z27Vy4qlJUpOluejlNCh9bp/Wn7l9f0v5Xtc1dV0axs7yWxjeOdYzgSxcA8Z4Pt071xc0TQytEedpxmuxYeWodyApGQfXHpXO3EckrszOgLHPWvPyyFVuTqXS8z6TiyjgXGksM059XG23nbT0MvBpcH0rTW0kcAbk496l+wzAk7k5PrXseyXc+K+rmOFJ6CkwfStg2E2chk9OtINPmC43p19f/rUeyXcf1dGUEc8gGjY/wDdNbP2KYcFkz9f/rUv2OX+8n5//Wp+yj3F7A//0fNqjBEswjHIHJ+vYUhJkOF4XufX6URgLcALx8tepGNtXufMUIpTV9zeXcumv2PmD+lUGbJ4zWpahGsWEjbRv6n8KiNraA83AH4Uj2SqCmA2DTQVUnI6/wAjV5YrRRgXH6U1obJjk3H6U7isaV9zoloF6eU/H/bRq4oRSF846V3lysI0m1RXynlv83tvNYqw2ZGTOfTgVnHUuRmQxnZk+uakGN2QPetNYrEAoJj+X/1qjEVgOk7fl/8AWq7k2KQGWJC5zTijBMYHXNXlisl4Ezfl/wDWp22xxgysc+3/ANandCsQ6ns+0AsucqKzv3f9z9a2L5FaVTz9wf1ql5S+9SUf/9LzCSVIlxkA9gacEaK4Qlw4ccHGDwM9PTng1AzTJCW2ELI2RnlWBAG1wDxxyKks4wsqKxJwMDJz+Ar2XFQjZ7s+ciowcU92zfiz/Z0uOzA/yqi3J65rWt/KW2m8xSy5GQKhMlg3Jik/P/69YnqlIM2dwHXik3MFPHU1fDafwRHJ6/55pMacxPyyCncViaO5mnsRA0YUW6FQc53bmLDjHHFUAXx0H51oRzWaRlE34cY6VERYjj96aUdBvUpBXD7sdaQhsleOeau5sOm2X/P407bp452ufx/+vTuKxUG/vimlXJ5x0q4z2KDPlyHA9f8A69V/tumqf9VJ+f8A9ehyInOMPiZcu+HT/cFVc09tS06XDSK4IGOnb8DTftulej/l/wDXqbi9vS/mR//T8rkDIEh8xZF6443jHQNgkYHapIv9Yv1qH5y29zliME4AJ9zjqangSSWeOKJS7uwVVHUsxwAPqa9atNSldHys581VWNhY55FZhgCMbjz1qv5h55616dafDjxFbQXLXSQbjGrITcbUTaSX34UknHA/h5JJ4FYVpp1vd+G7rW0A+0W82Fhwu14kRWkI4zlQ27rjA6Vh7VHv+zZxwkYcA0bzzz1rsNO063vdB1HWrgCI2qEwIu394yFTITlT8qhlHGOTVSTT9ShtGvZLBAiRiVl3oZFjbo7Rg71U5HJWq9or2FyPc5oSMBgGnq7EMc9K6yDRtVmTedPALRCaNd0e+RCu7KJu3Nx12g46dap29lqV1brc21lGySKzRjegeRUzuZIyQ7gYPQHoaPaLuLkZzoYnLZxQZW9avrfZxiGPBGRSreswyIo/yq9SdDNaQlSCazpCC3XNdE1/Iv8Ayzj/ACpVv5cj5Ixn2pO5z4jDqrbWxzQBPQUbW9DXeROGiRzgFlB/OpNy+oqTm/s1fzH/1PK6s2VzJZXsF5CAXglSRQehKMGA/SqoORz171JGSJFI5Oa9Jroz46N4zR9Sj4heEL60eKaWQiWEmSLynJAYYKEgYz264968Us9Xg02ytvLVmaHUHmaFgSWtnhEbKWxg5XKn35rHspfLkcyEL8pxnjmg390MjcvA9KzVFLQ+ndVvU6C7v9LhS807TZHezi06S0tWZGBlkkkSRmIxwWOeuBhRV03nh+x/tAWDQLDcafNDCFhla53tGBiWRhgEkEcEg8dAK5A6jdjuv5UDUbog8rx7UexD2h6Ezafa63p2q3N3sNpZWMjxbHaQ+XGHVYyAVw3Q5Ixk1gWF5plxbwDW5YJrdBKWhaGRbqDczMEt5Y+GXJyNzADJyBWLaXc8olMjbiiDBOSflGAOSeABgCqw1G727sr+VJUu7G6hSjViArA8CgKdpODmrq6jdE4LKPwpV1C6YEllGPatjIoBTg5Bz2oVSTyDj6VeGo3WCdy/lSf2ld+q/lQBswophjyP4RUnlp6UkLs8KO3VlBNSVIz/1fLZBiTjuKFJDAjqDRL/AKwfT+tIOor05dD5CfxI2D8zKD0xUbgbyBUg++v0pj/fNUfQEyqNxHpioV/1n41Ov32/CoB/rPxoYjRtes//AFz/AMaoQgEHNX7XrP8A9c/8aowdDSW43sGAJcdqhqb/AJa1DQwHkDYD60ynt/q1/GmUAdRb/wDHvH/uj+VTVDb/APHvH/uj+VTVBR//2Q==: Location: 29.004308700561523, -110.92276000976562 — https://maps.google.com/?q=29.004308700561523,-110.92276000976562

[9:37 PM] **+52 1 662 637 5722:**
> _+52 1 662 342 4670: Cuando le quieran caer de allá para acá, aquí andamos_
Cáiganle pacá mejor

[9:38 PM] **+52 1 662 418 1934:** Sipues q onda

[9:38 PM] **+52 1 662 418 1934:** Caiganle con todo y paketaxo azul

[9:43 PM] **+52 1 662 206 3493:** donde es el rompehielos

[9:43 PM] **+52 1 662 418 1934:** Rompehielos ajeno a la universidad 🗣️🗣️

https://maps.app.goo.gl/6uV4uf8SQ9XJE8B49?g_st=ic

Cda. Piedra Serena 10, Lomas del Nte., 83105 Hermosillo, Son.

[9:45 PM] **+52 1 662 299 4587:** https://maps.app.goo.gl/KKDr9Jvy72mGSDSc9?g_st=iw

[10:14 PM] **+52 1 662 637 5722:** A qué hora es la degustación de comida

[10:14 PM] **+52 1 662 637 5722:** ?

[10:21 PM] **+52 1 662 399 2340:** No piden nada para entrar ala cerrada?

[10:21 PM] **+52 1 662 637 5722:**
> _+52 1 662 399 2340: No piden nada para entrar ala cerrada?_
no es cerrada

[10:23 PM] **+52 1 662 106 3537:** @~😼 Alex CF sigues sobrio?

[10:24 PM] **+52 1 662 342 4670:**
> _+52 1 662 399 2340: No piden nada para entrar ala cerrada?_
En la mía no brouuuu

[10:25 PM] **+52 1 662 342 4670:** Llégale andamos pisteando, aquí hay pizzas

[10:25 PM] **+52 1 662 342 4670:** [Sticker]

[10:41 PM] **+52 1 633 134 8806:**
> _+52 1 662 106 3537: @~😼 Alex CF sigues sobrio?_
lo perdimos

[10:41 PM] **+52 1 662 450 9504:** Que esta pasando alla?

[10:41 PM] **+52 1 662 450 9504:** XD

[10:45 PM] **+52 1 662 342 4670:** [Video] Ya trajeron más cheve chamacoooos

[10:45 PM] **+52 1 662 637 5722:**
> _+52 1 662 450 9504: Que esta pasando alla?_
stan jugando mario kart

[10:45 PM] **+52 1 662 637 5722:**
> _+52 1 662 342 4670: Video: Ya trajeron más cheve chamacoooos_
mario kart > cheve

[10:46 PM] **+52 1 662 342 4670:**
> _+52 1 662 637 5722: mario kart > cheve_
Mario kart < cheve

[10:46 PM] **+52 1 662 342 4670:** [Sticker]

[10:49 PM] **+52 1 662 106 3537:** video del rompe ice para comparar

[10:51 PM] **+52 1 662 342 4670:** [Video]

[10:52 PM] **+52 1 662 467 9029:** @all SI ALGUIEN PUEDE PRESTAR UNA PARRILLA ELECTRICA LO AGRADECEREMOS MUCHO CON COSAS Y PREMIOS GRATIS

[11:06 PM] **+52 1 662 637 5722:** alguien kiere algo del six

[11:06 PM] **+52 1 662 637 5722:** ?

[11:09 PM] **+52 1 662 399 2340:**
> _+52 1 662 637 5722: alguien kiere algo del six_
Ya andas ahí?

[11:09 PM] **+52 1 662 637 5722:**
> _+52 1 662 399 2340: Ya andas ahí?_
sí

[11:10 PM] **+52 1 662 476 3432:** Eh pues fuga al after

[11:10 PM] **+52 1 662 476 3432:** [Sticker]

[11:10 PM] **+52 1 662 399 2340:**
> _+52 1 662 637 5722: sí_
Un 6 de indio y aquí te lo pago

[11:12 PM] **+52 1 662 342 4670:** [Video] Nos trajeron cigarros tmbn amigos caiganleee

[11:18 PM] **+52 1 662 637 5722:**
> _+52 1 662 399 2340: Un 6 de indio y aquí te lo pago_
te tardaste pa ya me vine

[11:19 PM] **+52 1 644 404 0378:** Ajale

[11:30 PM] **+52 1 662 342 4670:** [Image] Ya andamos medio p2

[11:35 PM] **+52 1 662 522 5777:**
> _+52 1 662 342 4670: Image: Ya andamos medio p2_
Por esa cuadra asaltaron a un compa

[11:38 PM] **+52 1 662 342 4670:** A mi ya me conocen bro, me hacen paro

[11:42 PM] **+52 1 662 342 4670:** [Video]

[11:42 PM] **+52 1 662 341 2644:** [Image]

[11:42 PM] **+52 1 662 341 2644:** El primero de la noche

[11:43 PM] **+52 1 662 448 8831:** Eso es color forloko

[11:44 PM] **+52 1 633 134 8806:**
> _+52 1 662 341 2644: Image_
fue el chino?

[11:48 PM] **+52 1 662 402 3568:**
> _+52 1 662 341 2644: Image_
fue el chino?

[11:48 PM] **+52 1 662 139 8934:** en mi defensa yo andverti que una mas y iba a valer verga

[11:49 PM] **+52 1 662 139 8934:** y no se quien verga me echo mas alcohol en lugar de agua

[11:49 PM] **+52 1 662 139 8934:** neta perdon weyes

[11:49 PM] **+52 1 662 139 8934:** que verguenza la ptm

[11:49 PM] **+52 1 662 139 8934:** [Sticker]

[11:49 PM] **+52 1 644 404 0378:** Es mugre o  también mojaron el sillón?

---

## September 19, 2026

[12:07 AM] **+52 1 662 206 3493:**
> _+52 1 662 467 9029: @all SI ALGUIEN PUEDE PRESTAR UNA PARRILLA ELECTRICA LO AGRADECEREMOS MUCHO CON COSAS Y PREMIOS GRATIS_
encontraron parrilla?

[12:12 AM] **+52 1 662 637 5722:** Onta el premio de la comida

[12:12 AM] **+52 1 662 637 5722:** ?

[12:17 AM] **+52 1 662 342 4670:** [Image]

[12:50 AM] **+52 1 662 637 5722:** saquen botella

[1:26 AM] **+52 1 662 637 5722:** Hey está por aquí al bato al que le jugué ajedrez? xd

[1:26 AM] **+52 1 662 637 5722:** [Sticker]

[1:27 AM] **+52 1 662 637 5722:** Alv, aprobado por mí 👌🏽

[1:32 AM] **+52 1 662 637 5722:** Se me perdió el premio

[1:32 AM] **+52 1 662 637 5722:** :c

[1:42 AM] **+52 1 662 342 4670:** [Video] WEY ANDAN HACIENDO LAGARTIJAS EN EL CAMPO DE GALAAAAA A LA 1 AM PURO DEPORTISTA POR AQUÍ

[1:48 AM] **+52 1 662 637 5722:** Hey alguien se quiso ir robar los totopos y lo detuve

[1:48 AM] **+52 1 662 637 5722:** No me acuerdo quien fue xd

[1:52 AM] **+52 1 645 107 9121:**
> _+52 1 662 637 5722: Hey alguien se quiso ir robar los totopos y lo detuve_
perdón fuí yo

[1:52 AM] **+52 1 645 107 9121:** no lo vuelvo a hacer

[1:54 AM] **+52 1 662 637 5722:** Hey les gustó la gallina pinta? 🫶🏽

[1:58 AM] **Julio Camargo:** Hello

[1:58 AM] **Julio Camargo:** Buenas noches, soy Fernanda Llanes en el cel de Julio

[1:59 AM] **Julio Camargo:** Al que me envió mensaje de venir caiganle

[1:59 AM] **Julio Camargo:** Cerrada Empalme #262

[1:59 AM] **Julio Camargo:** #261***

[1:59 AM] **+52 1 662 637 5722:** Oigan me robé los duros perdón ;c

[1:59 AM] **Julio Camargo:** [Voice message]

[2:02 AM] **+52 1 662 637 5722:** Hey

[2:02 AM] **+52 1 662 637 5722:** Llevo 3 al after

[2:05 AM] **+52 1 662 342 4670:**
> _+52 1 662 637 5722: Llevo 3 al after_
Cáiganle

[2:05 AM] **+52 1 662 342 4670:** Hay cheve aún

[2:05 AM] **+52 1 662 342 4670:** Y cigarros

[2:05 AM] **+52 1 662 399 2340:**
> _+52 1 662 342 4670: Y cigarros_
Ya nomás por eso le caigo

[2:06 AM] **+52 1 662 399 2340:** Alguien va ir al after que me de raite

[2:07 AM] **+52 1 662 637 5722:** Hey se me perdió lñem premio xd

[2:07 AM] **+52 1 662 637 5722:** _This message was deleted_

[2:09 AM] **+52 1 662 637 5722:** _This message was deleted_

[2:11 AM] **+52 1 662 399 2340:** La dirección del after

[2:12 AM] **+52 1 662 342 4670:**
> _+52 1 662 399 2340: La dirección del after_
Cerrada Empalme #261

[2:12 AM] **+52 1 662 637 5722:** _This message was deleted_

[2:12 AM] **+52 1 662 637 5722:** _This message was deleted_

[2:14 AM] **+52 1 662 637 5722:** _This message was deleted_

[2:31 AM] **+52 1 662 637 5722:** _This message was deleted_

[2:32 AM] **+52 1 662 342 4670:**
> _+52 1 662 637 5722: Vamos al after, jalan o qué_
Amontónense en el carro pues jajajajja

[2:33 AM] **+52 1 662 399 2340:**
> _+52 1 662 637 5722: Vamos al after, jalan o qué_
Dónde???

[2:33 AM] **+52 1 662 637 5722:** _This message was deleted_

[2:33 AM] **+52 1 662 399 2340:** Andan??

[2:33 AM] **+52 1 662 637 5722:** _This message was deleted_

[2:33 AM] **+52 1 662 637 5722:** _This message was deleted_

[2:33 AM] **+52 1 662 342 4670:** /9j/4AAQSkZJRgABAQAASABIAAD/4QCMRXhpZgAATU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAOgAQADAAAAAQABAACgAgAEAAAAAQAAAGSgAwAEAAAAAQAAAGQAAAAA/+0AOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/AABEIAGQAZAMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2wBDAAYGBgYGBgoGBgoOCgoKDhIODg4OEhcSEhISEhccFxcXFxcXHBwcHBwcHBwiIiIiIiInJycnJywsLCwsLCwsLCz/2wBDAQcHBwsKCxMKChMuHxofLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi7/3QAEAAf/2gAMAwEAAhEDEQA/AOFy39ymsWKkFau+VZ/8/P6UeVZtx9pPPHSvUucFh1yskn2YR8syY/lUioUJsrQ/P1ml/uj0Hv6elPnu7awMcbhnkVdoA9D39O1Z094rR+RbL5cZ5PqxPrUOXKrsUqkYhdXCFBa23EKf+PGqNFFczbbuzilJyd2FFFFIkKKKKACky45jYo2CAVJB54PSlooGnbVFi4vrG5lM+pCYzN2jCbQBwAC2SeBknjk1D5+hf3Lj8ov8KZgUYHpWntDo+sPsf//Q89aYNxjFTQzxLNG0gO1Tk4qlTHO1CfavRTbdj5mOLq3WpO8v2md7pv4ydvso4FFCIFRV9AKdhaipBuTZ3SpSbuNrW0ewjv7tY53Ece5VLNwBuOMn2HU1nJGrc5q9YXMdq5Dn5XAz7EdK5sTSqeyk6e56GUUaP1un9b+C+v6X8r2udNqujWNneS2MbxzrGcCWLgHjPB9uneuKmiMMrRHkqcV1U11BBEs0jDa4JXH8WDjj8a5W5njklaXPLkmuDLYVm5Od0vM+l4tpYJxpLCuLn1cbbedtPQjoqRfKYgA5Bp6pGe/J6V63smfE+xkQUVLtjGRnPpQFTaCTjJo9kw9jIioq2I4sf/XpfLi/yafsWL2LP//R82phG91j7dT9BQz4O1eW/wA9aLb5ZX3fMa9SEbe8z5jDQ99Nm+jR29pFJ5auzkg5phvsHb5EdPaNpbGEKCcEnjn1qh5E/wDzzb8jUnsmiLtx/wAsoxSLeyEZEcftxVUQSlRlHB+hpjW9wGOI2x9DVWQtTf1SeT+yLKVQu7a46cffNcklzO7cqv5V1d4jnRbONlO7a/BHP3zWELSTadsTflWaSZbbQ6C7mQL8qc+oqwuozM2NqflUX2afyseW2fpUYtbjBzE2e3FXZE3ZZGozEE7U49v/AK9SR38jvGpVPmODxVVLWbHzRNn6VPHbzB1byyMMD+tFkF2WZbp0lZAq4BwOKj+2Sf3V/KobvIuX47j+QqvuPpTshan/0vMvliXJ79+pJpLdt0z9R2weCMeoqvI5EazhyrZJUYyoI42nuGxz6VcgLXFyZCNvy4Azk4z3PH0HtXsOHLG8nqz52lDlknJ6s3xM8VhE0ZI+Yg4/GqpvbrdjeR+A/wAKtpbyTWKxp1Vyfw5qBtOuicgA/jWR6g0Xdwc5lPt0/wAKb9rudufNOfTj/CpRp9xxlB+dMNhd4A2Dj3FGgalx725nsI1chfJyocHJbLZ6YwODiqguZuP3p/SrotpBZmLZ8xbOOKqfY7n/AJ5D8xQkkDuyJLq4JIaVqb9quOMyt15qz9jueojGfqKQWN1knYvPvT0FqR/aJTk+a350JcTGQASMRkd/erAsrj+6PzpyWVwGDMFGD60aBqR3YBuHJ/zxVfavpVu8trt7hniXKnHcelVfsl//AHP1FCkgsf/T8qka3kZTAuwgkuoBXGOgI6ZHr6VatX2S/UVWaR5pS7tuwAoO3bx16e31NWbRHkuEjjUu7kKqjqWbgAfU169aV53PmHK9ePyNZrhTELc9N27I6/Sq4Ybepz9a9Mj+GuvrZXC3UdurFVdH8/CxkHLbsLkkAYH8PJJPArm7Pw7a3nhy51dLk/aIJsKnG1oVRWkOOuV3bs56DpXP7WJ7ns2c0HX1YfiaTzWCkBmyfc109h4ctLnRdR1W4utpt0/0cLgB2Qr5hbOcqoZehHJqnJ4bv4rdrqQBY0QStym9Y26O0e7eqnI5K1XtI3sTyPcyPPPHzN+Zo83PzZb8z/jW3H4U1eVVZYj88YlRSU3uhXduRd+5+DztBx061HB4fvLm3Sa3w6ShnjwUDyKmdxSMsHcDByVB6Ue0j3DkkYolOSSW68cmntMDwST+NTi1tivFypB5/wA80n2W0HW5H5f/AF6q5NilM4ZTgnJ9zWazMGIyfzNbxtbMjH2kflUX9n2DEk3JP4Um7nFiqE5tchkLc3CDasrgegY077Xdf89n/wC+jWxJp+m27bJpX3Yz+H4Co/s2kf8APWT/AD+FI5/qlfv+J//U8rq5p9xJZ30F5CAXgkWRQehKEMB+lU6mt8eaMnFeja+h8hQ/iR9T6iPxC8IXlhIJ5ZNkkR8yPynJG4YKEgY3duuPevE7PWbbTbO2EYLNDqDzNC2SWtnhEbKWxg5XKn35rMszGYJvMY7eCTio2XTn5Mj/AJf/AFqhUkro+ldRvU37vUdKgW90zTpHazi06S1tGZSDLJJIkjMRjgsc9cDCirhvvDtkNQFg8CwXGnzRQhYZWufMeMDE0jDAJIxwSDx0Arlf+JfxmR+Pb/61NC6dg/vH59v/AK1HskHtGehzS6baapp2qXd35f2O1sZXj2OZD5cYZVjIBUhuhyRjJrnrG+0q4ggGtzW8ttGJS0LRSLdQbmZglvLHwy5ORuYAZOQBWSDbyW0hMsjrhVLMSSAoAUDPYDgCqXl6b/z0f8v/AK1JUu7H7TsUV+7wMfKAaerFV6ZFXAmnAECR+fb/AOtRs07bt8x8fT/61bXMrFBiW+b8KcCzHgdsVd2adj/WPj6f/WoC6cpyJX/L/wCtRcLDdT8v7QN+c7R0rPzB6GtHUxEbgbyQdo6fjWfiD+8aQz//1fKV6VatVDTAH3qqnT8TVu0/14/GvUn8bPk4r998zTMrwgpHwH6/hUBY8+9Pm+8tRUM90c/3zSryCvakf7xoTrQBfh4sbge4/pVAn5QKvxf8eNx9R/Ss8/dFJDYAkA4704MQuBTO1L2piDJxjtSUUUgLmq/8fI/3B/WsytPVf+Pkf7g/rWZUlH//2Q==: Location: 29.004405975341797, -110.92272186279297 — https://maps.google.com/?q=29.004405975341797,-110.92272186279297

[2:33 AM] **+52 1 662 637 5722:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAwADAQEBAAAAAAAAAAAAAAMEAQIFBwgG/8QAOhAAAgEDAAYFCgUFAQEAAAAAAQIDAAQRBRIhMWFxExQyUbEGM0FCgaHB0fDxByJDcpFSYoKS4RUj/8QAGgEBAQEAAwEAAAAAAAAAAAAAAQACAwQFBv/EACkRAAIBAwMBBwUAAAAAAAAAAAABEQIhMQMEBUESFCJRYYHRBhMyM3H/2gAMAwEAAhEDEQA/APpBbCEb9ZuZx4U1baFf01PMZ8aQL4MP/nFIx+u6s9Pcv2LfH7j9q1cLFSqqjCgAcBW1RYvX9aNPr20dVmbt3Lchn50QMlF0M20o/tNItLiJbZA8igjIxnbvoFhFnLM7HiRS9HwxyRMZFDMGxt5Cm0BeRzX0C+sTyFIuboTQsqRvjeSRuwc1csUadlFXkMUTLrROvepFEoYZFDNctEgjhBAGMk78fxTNW9b10Tl9GttHNm0XgT45prTxLvkT+aWCwT9Vmbt3Lchn51kWEZOXZ2PEit2vYF9YnkDWnXg3m4pG9nyquVhgs4B6h/2NFL6zcHdbHHE0VXKwywObOLgur/Gz4VRXLsopJY2CTGNFYjA/n41R1BG2ySOx41NXJNwUNNEvakQe2lNewL6xPIGsrZwL6meZNMWGJezGg5LRYbk/X1bzcbueFfifKDy/s/J+5mtYIWu7zWy8anVWM9zN38AD7K/ZeUN5Jo/QGk72EAy21rLMoO7KoSPCvl29uHiieZyZJWOSzHJZidpNdLd7l6SVNGWe9wnF6e9dWprPw09PM9asvxY6W4Vb/R7WsJODJDJ0urxIKg45ZPCvRrMm/tYrmC+EsEqhkeM5DA9xGK+VdH3rzymOQDdkEV7R+CelGWy0pYzuehgeOWIYJxr62sBwymeZNcW13WpVX9us7nMcPt9HQ7zt7JZUnoFnapLriTOUbGBuqxbOBfUzzJNRwXKxzzMqswc5GPrjVHWZ27Fs3M5r03J8moKVijTsxoOQreo83r+iNPr20dXuX7dxj9o+1EGpLKKi6iDtaZye+iqxSyfR86QmUSEgHBGwnO//AJVJv4s4VXY8MVHo1QbhVkAb8hG0Z2gj/tdcAAYAAFNUSZpmCTrUzdi3bmc/Ksa163qInP71bWrOqdplXmcUSag517YTX9nPa3Uw6GeNonC+lWGD3d9fOflDoW40NpK40ZpFMvHubGBKnquOB9xyPRX0w11AP1FPLb4V+L/EvQ8PlBonXtVJv7VWeFsYLbspyOP5xXU3e3etTKyj2uE5JbLW7Nf4VZ9PX5PBoLaK21mQY2bST6K96/CryafQ+g3ub+HVvb1hIUcbY0A/Kp7jtJPPHor8H+FOghpTSbaTngM1pZkdGpH5XlxkZ/aMHHeR3V7V0l426JFHH71wbHbv9tXsej9RclS33PSws/Bgfk0mR/Un14VbXLmScXERkcB22Ar6PrNUdTZvOXDsOFem0fJplTOq9pgOZxSmuoF/UU8tvhS1sIRv1m5nHhWbWCIwqWjUtuJIztFFhuYN/CDsLH2UVSEUDAVQOAoqsVzjIZEuhqjVl6Q7DuBOdnvq/ortu1Mqjh9qkvT0V+zHdrI55bB8K6LXMK/qKeRz4VpmUhPUmbzk8jfXHNZWwgXeGPM48KGv4Ru1m5DHjWOus3m4JGouPhHLbQrujU8xmkaRQC2ygA1WB2D2fGjpbtuzCqjj960njumhcyOmqBkqOG3uqWSeDOhdF2GibMw6Ltkt4JHMxVc7WbaTtq5mCjLEAcTXPt7ZpYVYzvqnZqjOz305bCEHJ1m5n5UJJWNOuqt9p3Yq+ljLQsjqxVs4Bzx+FdCoby2iS2YouCMenNVwtrxI3eoNTwCyb0m32dKvc59+3406k6yxzSF3VVYA7T6frFAjqKQbqEfqD2baKoKUc2+gEDgRknXU7TvyPvXQhggaNHEakMAdu2or2YzGM9GyAEjJG/P2ptq90beNYlTUUaoY8NnfW3MGFEl6oq9lQOQxW1R9Fdt25lUf2/ajqRbzk8jfXHNZg1JUzonbZV5nFJkuYCrKZAQRjZt8K1WxgXeGPM48KYttCu6JfaM1WK5FaXawwhHVi2cgDFO63K3m7ZzxOflRY/lmuE9AbI/k/wDKsJCjJIA40vIKYIZjdyRMGjRVxt7/ABrS2jnlhXVm1UGwAeiq3urddhmj5A5qKzukgiZWDk5yMD0VXgHElHUtbzk0je355rZbGBfVJ9vypLaR/ohb/IgeGaU+kpM4AhQ9xJb5VQymkvFtCB5pDzGaK53W7ptoLY/tiJFFUMe0izSgza5/pZT78fGk2FzFFAySSKpVjsJ27du721PJYzLG0jLGSoLbWJPhRawdYdxr6oUA7Bt25+VMKAlyXNfwDcXY8FPxpbaRHqQv/kQPDNbro+IdppG5tjwxTFsrcfpK37vzeNFh8RE+kpM4AiTmc/Ktes3UnZL/AOEez3g11UjRBhEVRwGKySFGWIA41SvIofmcXo5mm1cSCVtpy2rkezlTBo6VjlhEOJJY+FPuJUW9ikDqQBg4OcfWac19Au4seQx40y+gQuohdHH15v8AVceOa0htUN1JFIXYKMjbjP8AHOn9dLeagkb64ZpBkm64GWMLI4wFPd9Cq5W6Fi2duP0lP7vzeNORFQYRVUcBipdS8bfIijh9qOqSN5y4cjuGfnWfc1/EWUVH/wCfD6S5PecfKiqxXK2AZSDuIxXK0OSZBxjBPu+dFFKwweUPvLySFiFCHHeKn65Owzr45AUUU0oKmLjlklfVeR8Z9DGr0sIthYux4miip2Cm4q8gjiMOouwtggnOavWNE7CKvIYoorLwbWTaorzZdWxG/OPeKKKlkngtooooEKKKKiP/2Q==: Location: 29.128884, -110.9875794 — https://maps.google.com/?q=29.128884,-110.9875794

[2:33 AM] **+52 1 662 342 4670:**
> _+52 1 662 637 5722: Andamos en mi casa_
Mikasa tú casa brouuuu

[2:33 AM] **+52 1 662 399 2340:** Para ir al after

[2:33 AM] **+52 1 662 637 5722:** _This message was deleted_

[2:33 AM] **+52 1 662 637 5722:** _This message was deleted_

[2:34 AM] **+52 1 662 342 4670:**
> _+52 1 662 399 2340: Para ir al after_
Acóplate broouuuuu

[2:35 AM] **+52 1 662 637 5722:** _This message was deleted_

[2:46 AM] **+52 1 662 467 9029:** QUE?

[2:46 AM] **+52 1 662 467 9029:** A no mames

[2:47 AM] **+52 1 662 467 9029:** Jodidos

[2:48 AM] **+52 1 662 335 9011:** 🥀

[2:48 AM] **+52 1 662 335 9011:** Perdón fui yo
La batería quería ir de viaje dice

[2:48 AM] **+52 1 662 335 9011:** [Sticker]

[2:52 AM] **+52 1 662 350 5885:** que buen pre amigos, a que hora empieza el rompehielos bien?

[2:52 AM] **+52 1 662 350 5885:** [Sticker]

[2:52 AM] **+52 1 662 350 5885:** [Sticker]

[2:53 AM] **+52 1 662 342 4670:**
> _+52 1 662 350 5885: que buen pre amigos, a que hora empieza el rompehielos bien?_
De qué ya we

[2:56 AM] **+52 1 662 342 4670:**
> _+52 1 662 350 5885: que buen pre amigos, a que hora empieza el rompehielos bien?_
Tengo un 12 ya nomás we

[2:57 AM] **+52 1 662 342 4670:** Ya todo lo demás se acabó

[2:57 AM] **+52 1 662 342 4670:**
> _+52 1 662 342 4670: Tengo un 12 ya nomás we_
Y cigarros

[3:37 AM] **+52 1 662 399 2340:** Que casa es ?

[3:37 AM] **+52 1 662 399 2340:** @~Fernanda Llanez

[3:38 AM] **+52 1 662 342 4670:** Es en una esquinaaa

[3:38 AM] **+52 1 662 342 4670:** Vienes aparteee???

[3:38 AM] **+52 1 662 399 2340:** Con un compa

[3:38 AM] **+52 1 662 342 4670:** /9j/4AAQSkZJRgABAQAASABIAAD/4QCMRXhpZgAATU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAOgAQADAAAAAQABAACgAgAEAAAAAQAAAGSgAwAEAAAAAQAAAGQAAAAA/+0AOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/AABEIAGQAZAMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2wBDAAYGBgYGBgoGBgoOCgoKDhIODg4OEhcSEhISEhccFxcXFxcXHBwcHBwcHBwiIiIiIiInJycnJywsLCwsLCwsLCz/2wBDAQcHBwsKCxMKChMuHxofLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi7/3QAEAAf/2gAMAwEAAhEDEQA/AOCxH3akxH/erQN/cKMlI/ypPt9xgEInPA4NepqcBIkJubOCMdN5yR2HNSTRg/LMPLtYv4e7kf0/nVfU72eJ1tbdtrFcuQOmfSs2SaWXHmuWx0zWcpcpE6qjoSXNy9zJvbgDhR6Cq9FFczdzjbbd2FFFFAgooooAKKKKAHRSPACsWwAnPzRo3P1YE1L9qn/6Z/8AfmL/AOJqCinzMv2ku5//0PN9x9acsjqQQTkHIplNZtqlvSvQV3oj5JTk3ox6yPM7zyHLOev04p9WbSznliHlgYXgknHNWv7NuvRfzoqU05N3PX9hfVszOa1tH0+O/u1jncRx7lUs3AG44yfYdTSpp1wpy238/wD61XbKCa3ZhIV2t3B5z27Vy4qlJUpOluejlNCh9bp/Wn7l9f0v5Xtc1dV0axs7yWxjeOdYzgSxcA8Z4Pt071xc0TQytEedpxmuxYeWodyApGQfXHpXO3EckrszOgLHPWvPyyFVuTqXS8z6TiyjgXGksM059XG23nbT0MvBpcH0rTW0kcAbk496l+wzAk7k5PrXseyXc+K+rmOFJ6CkwfStg2E2chk9OtINPmC43p19f/rUeyXcf1dGUEc8gGjY/wDdNbP2KYcFkz9f/rUv2OX+8n5//Wp+yj3F7A//0fNqjBEswjHIHJ+vYUhJkOF4XufX6URgLcALx8tepGNtXufMUIpTV9zeXcumv2PmD+lUGbJ4zWpahGsWEjbRv6n8KiNraA83AH4Uj2SqCmA2DTQVUnI6/wAjV5YrRRgXH6U1obJjk3H6U7isaV9zoloF6eU/H/bRq4oRSF846V3lysI0m1RXynlv83tvNYqw2ZGTOfTgVnHUuRmQxnZk+uakGN2QPetNYrEAoJj+X/1qjEVgOk7fl/8AWq7k2KQGWJC5zTijBMYHXNXlisl4Ezfl/wDWp22xxgysc+3/ANandCsQ6ns+0AsucqKzv3f9z9a2L5FaVTz9wf1ql5S+9SUf/9LzCSVIlxkA9gacEaK4Qlw4ccHGDwM9PTng1AzTJCW2ELI2RnlWBAG1wDxxyKks4wsqKxJwMDJz+Ar2XFQjZ7s+ciowcU92zfiz/Z0uOzA/yqi3J65rWt/KW2m8xSy5GQKhMlg3Jik/P/69YnqlIM2dwHXik3MFPHU1fDafwRHJ6/55pMacxPyyCncViaO5mnsRA0YUW6FQc53bmLDjHHFUAXx0H51oRzWaRlE34cY6VERYjj96aUdBvUpBXD7sdaQhsleOeau5sOm2X/P407bp452ufx/+vTuKxUG/vimlXJ5x0q4z2KDPlyHA9f8A69V/tumqf9VJ+f8A9ehyInOMPiZcu+HT/cFVc09tS06XDSK4IGOnb8DTftulej/l/wDXqbi9vS/mR//T8rkDIEh8xZF6443jHQNgkYHapIv9Yv1qH5y29zliME4AJ9zjqangSSWeOKJS7uwVVHUsxwAPqa9atNSldHys581VWNhY55FZhgCMbjz1qv5h55616dafDjxFbQXLXSQbjGrITcbUTaSX34UknHA/h5JJ4FYVpp1vd+G7rW0A+0W82Fhwu14kRWkI4zlQ27rjA6Vh7VHv+zZxwkYcA0bzzz1rsNO063vdB1HWrgCI2qEwIu394yFTITlT8qhlHGOTVSTT9ShtGvZLBAiRiVl3oZFjbo7Rg71U5HJWq9or2FyPc5oSMBgGnq7EMc9K6yDRtVmTedPALRCaNd0e+RCu7KJu3Nx12g46dap29lqV1brc21lGySKzRjegeRUzuZIyQ7gYPQHoaPaLuLkZzoYnLZxQZW9avrfZxiGPBGRSreswyIo/yq9SdDNaQlSCazpCC3XNdE1/Iv8Ayzj/ACpVv5cj5Ixn2pO5z4jDqrbWxzQBPQUbW9DXeROGiRzgFlB/OpNy+oqTm/s1fzH/1PK6s2VzJZXsF5CAXglSRQehKMGA/SqoORz171JGSJFI5Oa9Jroz46N4zR9Sj4heEL60eKaWQiWEmSLynJAYYKEgYz264968Us9Xg02ytvLVmaHUHmaFgSWtnhEbKWxg5XKn35rHspfLkcyEL8pxnjmg390MjcvA9KzVFLQ+ndVvU6C7v9LhS807TZHezi06S0tWZGBlkkkSRmIxwWOeuBhRV03nh+x/tAWDQLDcafNDCFhla53tGBiWRhgEkEcEg8dAK5A6jdjuv5UDUbog8rx7UexD2h6Ezafa63p2q3N3sNpZWMjxbHaQ+XGHVYyAVw3Q5Ixk1gWF5plxbwDW5YJrdBKWhaGRbqDczMEt5Y+GXJyNzADJyBWLaXc8olMjbiiDBOSflGAOSeABgCqw1G727sr+VJUu7G6hSjViArA8CgKdpODmrq6jdE4LKPwpV1C6YEllGPatjIoBTg5Bz2oVSTyDj6VeGo3WCdy/lSf2ld+q/lQBswophjyP4RUnlp6UkLs8KO3VlBNSVIz/1fLZBiTjuKFJDAjqDRL/AKwfT+tIOor05dD5CfxI2D8zKD0xUbgbyBUg++v0pj/fNUfQEyqNxHpioV/1n41Ov32/CoB/rPxoYjRtes//AFz/AMaoQgEHNX7XrP8A9c/8aowdDSW43sGAJcdqhqb/AJa1DQwHkDYD60ynt/q1/GmUAdRb/wDHvH/uj+VTVDb/APHvH/uj+VTVBR//2Q==: Location: 29.004308700561523, -110.92276000976562 — https://maps.google.com/?q=29.004308700561523,-110.92276000976562

[3:38 AM] **+52 1 662 342 4670:** [Image]

[3:40 AM] **+52 1 662 342 4670:**
> _+52 1 662 399 2340: Que casa es ?_
/9j/4AAQSkZJRgABAQAASABIAAD/4QCMRXhpZgAATU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAABIAAAAAQAAAEgAAAABAAOgAQADAAAAAQABAACgAgAEAAAAAQAAAGSgAwAEAAAAAQAAAGQAAAAA/+0AOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/AABEIAGQAZAMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2wBDAAYGBgYGBgoGBgoOCgoKDhIODg4OEhcSEhISEhccFxcXFxcXHBwcHBwcHBwiIiIiIiInJycnJywsLCwsLCwsLCz/2wBDAQcHBwsKCxMKChMuHxofLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi7/3QAEAAf/2gAMAwEAAhEDEQA/AOCxH3akxH/erQN/cKMlI/ypPt9xgEInPA4NepqcBIkJubOCMdN5yR2HNSTRg/LMPLtYv4e7kf0/nVfU72eJ1tbdtrFcuQOmfSs2SaWXHmuWx0zWcpcpE6qjoSXNy9zJvbgDhR6Cq9FFczdzjbbd2FFFFAgooooAKKKKAHRSPACsWwAnPzRo3P1YE1L9qn/6Z/8AfmL/AOJqCinzMv2ku5//0PN9x9acsjqQQTkHIplNZtqlvSvQV3oj5JTk3ox6yPM7zyHLOev04p9WbSznliHlgYXgknHNWv7NuvRfzoqU05N3PX9hfVszOaMGprp104gTlS56Kpyfr7VW+2W8kbPE/CnnjkZGaxlyR0bLjg29UPwaMGq63ySMAjqc8c1raQINbdLKCdIbp/uRzfKH9Ar9Nx7BsfWpi4PqN4OSKODS4PpW7caRe2sptroCKSM4ZWyGH1BFRfYZgSdycn1rb2S7mf1cxwpPQUmD6VsGwmzkMnp1pBp8wXG9Ovr/APWo9ku4/q6MoI55ANGx/wC6a2fsUw4LJn6//Wpfscv95Pz/APrU/ZR7i9gf/9HzaowRLMIxyByfr2FISZDheF7n1+lEYC3AC8fLXqRjbV7nzFCKU1fc3l3Lpr9j5g/pUdlAl5fRWzOUEjbc+/oPrVm1CNYsJG2jf1P4VraJp0Auvtpw4iBEbntI3YD2Hf3rnxFTkpuSPoMPS9pUUWST+BI7bZNDL5kjD94znuOTgelcPr13Z22uwtp8IcxxqrpjhyM9QK7nXvFmm2e1H3mdPvRL8wfHQ+3865Twza2/iDVrrWb87URwdg4zxntzgCvIhOUV7SR7FWEJ/uoHGXs0iSpDLA1oGO/BJyd2ORnnGK7ay8OJfWka2SkkHazgZI3dCen51F400WZdupRH7TA7hBxh0J+6MD8q2PDXiGCBUhg2pJ9x0Y7dwHfmqnUclzRM6VFRbjM9Ut/Dh8Q6N/wj+q3CTaxYx77S4PDSwjA2yeoBO3P0PrnxSWKSCd4pkKPGxVlI5UqcEH6V7VpWr2kXiHS52k3FpRbq69N0wK4+hP8ASsf4n6RZWPiQ3e8xi9jEhAHG4fK3bvgGu3A1nKNpHFjqKjK8TysDLEhc5pxRgmMDrmryxWS8CZvy/wDrU7bY4wZWOfb/AOtXoXRwWIdT2faAWXOVFZ37v+5+tbF8itKp5+4P61S8pfepKP/S8wklSJcZAPYGnBGiuEJcOHHBxg8DPT054NQM0yQlthCyNkZ5VgQBtcA8ccipLOMLKisScDAyc/gK9lxUI2e7PnIqMHFPds34s/2dLjswP8qoi4tbKV7++u2ijWMosagl3djn5R07cmta38pbabzFLLkZAqvJp+m64raY+YXn+WKV/uxy/wABbnhSeGPYHNclaHNBxPaoz5ZKR5Lc3bT3UlzuJLk4JPOO1ehfD/UbW0nnlvWJJwwXsQwKsTjOcHFcJNpV5Y301lqkLwNaPsnRhgq3p+Pr6c1VgvZba/juLH90ysNnfHbnPUGvMqx5o2PQoz5ZqTPpHWry2sNAa7jiXZFh0QjaGYng46185XUzSSZPBBzx617D4qlupPDEz3LhnwmSOMcjgV42yS3JEkK52j5gOtY4RWi2b4yTlJWPYfhPq9zfeKtO0eNDIC/mS7uVVYgXDj3BAx9a9Y+Mrq19psK43CORj9Cy4/kaX4IeAp9AsJPE2rxmO8vkCxRsMNHB15HYucHHYAe9cx481mx1vxFNMu547cCCMqeCEJyRz3Yn8K9DDQtK6POxE242bOCG/vimlXJ5x0q4z2KDPlyHA9f/AK9V/tumqf8AVSfn/wDXrvcjgnOMPiZcu+HT/cFVc09tS06XDSK4IGOnb8DTftulej/l/wDXqbi9vS/mR//T8rkDIEh8xZF6443jHQNgkYHapIv9Yv1qH5y29zliME4AJ9zjqangSSWeOKJS7uwVVHUsxwAPqa9atNSldHys581VWNhY55FZhgCMbjz1qvvPPPWvTrT4ceIraC5a6SDcY1ZCbjaibSS+/Ckk44H8PJJPArCtNOt7vw3da2gH2i3mwsOF2vEiK0hHGcqG3dcYHSsPao9/2bNC0l8N+OLBNC8WSGzv0UR2+oLgFlHCrLng47Z6+oPXmNQ/Z/8AGFvc7tOntryHqrhjG3tlWGPyY1rafp1ve6DqOs3AWI2qEwIoX94yFTITlT8qhlHGOTWvYa5410GxNxaAx28UYlMLSI5SJujmEkuqnI5wK56lOMm7M2hUcUrmtdfDDxFqulGxuEiilK8NJJlVfHXCZzjtXQeCPgvonhaRNT1iX+0byP5l3LthjI7hTncR6t+QqnB42+IM0WTZQBmiE0Y+TfIhXdlE8zLcddoOOnWuSvNe8aeIrQSz/vYJVZkiWRIzKqZ3FIsh3AwegPSsaWGUNEzapiHLdHcePviNbpBLovh6UPKwKzXCH5UB4Koe7H1HA+vTwTzW7HFX1vc4xDHgjI+lKt6zDIij/KvQhDlVkcMpczuzNaQlSCazpCC3XNdE1/Iv/LOP8qVb+XI+SMZ9qp3OXEYdVba2OaAJ6Cja3oa7yJw0SOcAsoP51JuX1FSc39mr+Y//1PK6s2VzJZXsF5CAXglSRQehKMGA/SqoORz171JGSJFI5Oa9Jroz46N4zR9Sj4heEL60eKaWQiWEmSLynJAYYKEgYz264968Us9Xg02ytvLVmaHUHmaFgSWtnhEbKWxg5XKn35rHspfLkcyEL8pxnjmg390MjcvA9KzVFLQ+ndVvU6C7v9LhS807TZHezi06S0tWZGBlkkkSRmIxwWOeuBhRV03nh+x/tAWDQLDcafNDCFhla53tGBiWRhgEkEcEg8dAK5A6jdjuv5UDUbog8rx7UexD2h6Ezafa63p2q3N3sNpZWMjxbHaQ+XGHVYyAVw3Q5Ixk1gWF5plxbwDW5YJrdBKWhaGRbqDczMEt5Y+GXJyNzADJyBWLaXc8olMjbiiDBOSflGAOSeABgCqw1G727sr+VJUu7G6hSjViArA8CgKdpODmrq6jdE4LKPwpV1C6YEllGPatjIoBTg5Bz2oVSTyDj6VeGo3WCdy/lSf2ld+q/lQBswophjyP4RUnlp6UkLs8KO3VlBNSVIz/1fLZBiTjuKFJDAjqDRL/AKwfT+tIOor05dD5CfxI2D8zKD0xUbgbyBUg++v0pj/fNUfQEyqNxHpioV/1n41Ov32/CoB/rPxoYjRtes//AFz/AMaoQgEHNX7XrP8A9c/8aowdDSW43sGAJcdqhqb/AJa1DQwHkDYD60ynt/q1/GmUAdRb/wDHvH/uj+VTVDb/APHvH/uj+VTVBR//2Q==: Live location: 29.004308700561523, -110.92276000976562 — https://maps.google.com/?q=29.004308700561523,-110.92276000976562

[3:47 AM] **+52 1 662 399 2340:**
> _+52 1 662 342 4670: [location]_
Algo bello ahí le caemos

[4:02 AM] **+52 1 662 342 4670:** [Image]

[5:16 AM] **+52 1 644 404 0378:** Que desmadre

[6:41 AM] **+52 1 662 399 2340:** [Image] Si nos amanecimos raza le hubieran caída al after

[6:41 AM] **+52 1 662 399 2340:** Jajaja

[8:23 AM] **+52 1 662 637 5722:**
> _+52 1 662 399 2340: Image: Si nos amanecimos raza le hubieran caída al after_
yo fui

[8:23 AM] **+52 1 662 637 5722:** Voy reviviendo

[8:23 AM] **+52 1 662 637 5722:** Raza creo que accidentalmente me clavé algo

[8:24 AM] **+52 1 662 637 5722:** [Image] De quién es esta madre y pq la tengo yo?

[8:24 AM] **+52 1 662 449 3477:** Hola compañeras buenos dias me alegro que fueran al rompe hielo, ojala les haya gustado el evento

[8:24 AM] **+52 1 662 449 3477:** [Sticker]

[8:32 AM] **+52 1 662 335 9011:**
> _+52 1 662 449 3477: Hola compañeras buenos dias me alegro que fueran al rompe hielo, ojala les haya gustado el evento_
[Sticker]

[8:32 AM] **+52 1 662 335 9011:** [Sticker]

[8:45 AM] **+52 1 662 637 5722:** Raza a mi +1 se le perdió una mochila negra con naranja, sí la ven me avisan

[8:56 AM] **You:**
> _+52 1 662 637 5722: Image: De quién es esta madre y pq la tengo yo?_
Se me olvidó

[8:59 AM] **+52 1 662 637 5722:**
> _You: Se me olvidó_
cómo terminó en mis cosas bro?

[8:59 AM] **+52 1 662 637 5722:** Haha te lo llevo el lunes

[9:00 AM] **+52 1 662 637 5722:** otro pedo la birria 👌🏽 algo muy bello

[9:49 AM] **+52 1 662 332 3680:** No había bolsas para la basura?

[9:50 AM] **+52 1 662 332 3680:** Traigo un desmadre en el carro

[9:50 AM] **+52 1 662 332 3680:** [Sticker]

[10:45 AM] **+52 1 662 637 5722:**
> _+52 1 662 332 3680: No había bolsas para la basura?_
Yo dejé una

[10:52 AM] **+52 1 662 699 4499:** alguien sabe si abren la biblioteca central hoy?

[10:52 AM] **+52 1 662 699 4499:** pregunta bn random

[10:55 AM] **+52 1 662 115 2482:** Sí abre los sábados, si mal no recuerdo

[10:55 AM] **+52 1 662 115 2482:** Pero creo que cierran más temprano, como a las 3-4

[10:56 AM] **+52 1 662 699 4499:** en serio?

[10:56 AM] **+52 1 662 699 4499:** :00

[10:59 AM] **+52 1 662 115 2482:** ... Google dice que está cerrado

[10:59 AM] **+52 1 662 115 2482:** Y no puedo encontrar info del horario en la página jaja

[10:59 AM] **+52 1 662 115 2482:** No me creas

[10:59 AM] **+52 1 662 115 2482:** Quizá lo cambiaron

[10:59 AM] **+52 1 662 115 2482:** En algún lado hace un par de años vi que sí abría los sábados

[11:00 AM] **+52 1 662 360 3569:** en las pláticas de la semana de inmersión mencionaron los horarios de las bibliotecas 👀👀

[11:00 AM] **+52 1 631 125 1255:** [Sticker]

[11:00 AM] **+52 1 662 699 4499:**
> _+52 1 662 360 3569: en las pláticas de la semana de inmersión mencionaron los horarios de las bibliotecas 👀👀_
nofui

[11:00 AM] **+52 1 662 350 5885:** shoutout à la alarma de simulacro

[11:01 AM] **+52 1 644 422 2240:** [Sticker]

[11:01 AM] **+52 1 662 350 5885:** [Sticker]

[11:01 AM] **+52 1 662 412 0821:**
> _+52 1 662 350 5885: shoutout à la alarma de simulacro_
Me cague w

[11:01 AM] **Remil:** [Sticker]

[11:01 AM] **+52 1 662 339 4302:** [Sticker]

[11:01 AM] **+52 1 662 426 6490:** [Sticker]

[11:01 AM] **+52 1 662 412 0821:** [Sticker]

[11:01 AM] **+52 1 662 412 0821:** [Sticker]

[11:01 AM] **+52 1 662 332 3680:** [Sticker]

[11:01 AM] **+52 1 662 529 3317:** [Sticker]

[11:02 AM] **+52 1 662 164 8356:** [Sticker]

[11:02 AM] **+52 1 662 450 9504:** [Sticker]

[11:02 AM] **+52 1 662 450 9504:** [Sticker]

[11:02 AM] **+52 1 662 450 9504:** [Sticker]

[11:02 AM] **+52 1 662 450 9504:** [Sticker]

[11:02 AM] **+52 1 662 450 9504:** [Sticker]

[11:02 AM] **+52 1 662 450 9504:** [Sticker]

[11:02 AM] **+52 1 662 501 3191:** [Sticker]

[11:02 AM] **+52 1 662 181 6884:** [Sticker]

[11:02 AM] **+52 1 662 181 6884:** [Sticker]

[11:04 AM] **+52 1 662 358 4523:** [Sticker]

[11:04 AM] **+52 1 55 5473 2571:** [Sticker]

[11:05 AM] **+52 1 662 427 9029:** [Sticker]

[11:12 AM] **+52 1 662 522 5777:** [Sticker]

[11:13 AM] **+52 1 662 395 2196:** [Sticker]

[11:20 AM] **+52 1 662 637 5722:** [Sticker]

[11:21 AM] **+52 1 662 342 9577:** [Sticker]

[9:13 PM] **+52 1 662 360 3569:** **Poll: Hola chicos, ¿quien va querer exponer en contexto regional de 1 a 2 el lunes sobre los artículos?**
- Yo
- Me espero al siguiente tema

---

## September 20, 2026

[10:17 AM] **+52 1 662 369 5386:**
> _+52 1 662 360 3569: [poll_creation]_
[GIF]

[10:17 AM] **+52 1 662 369 5386:** @~Eduardo

[10:19 AM] **+52 1 631 125 1255:** asi como villa llevando clase con edelmira

[10:19 AM] **+52 1 631 125 1255:** [Sticker]

[10:20 AM] **+52 1 631 125 1255:** misma situación

[10:35 AM] **+52 1 662 224 3927:** A mí se me antoja entrar de oyente a clases de otros profes, lit no cap

[10:49 AM] **+52 1 662 335 9011:** [Sticker]

[12:09 PM] **+52 1 662 339 4302:** Hola, aún no se hacen los equipos para las exposiciones de contexto regional de 1 a 2?

[12:09 PM] **+52 1 662 339 4302:** No tengo equipo

[12:09 PM] **+52 1 662 339 4302:** [Sticker]

[12:15 PM] **+52 1 631 125 1255:**
> _+52 1 662 224 3927: A mí se me antoja entrar de oyente a clases de otros profes, lit no cap_
analisis de algoritmo 2 con gutu dicen q fue cine

[12:15 PM] **+52 1 662 399 2340:**
> _+52 1 631 125 1255: analisis de algoritmo 2 con gutu dicen q fue cine_
Todas las clases con gutu son cine 🚬

[12:16 PM] **+52 1 662 224 3927:** Yo rezo en la iglesia de Gutú

[12:16 PM] **+52 1 662 224 3927:** [GIF]

[12:32 PM] **+52 1 662 367 8720:**
> _+52 1 662 339 4302: Hola, aún no se hacen los equipos para las exposiciones de contexto regional de 1 a 2?_
no, pero en clase el profe dijo q era para el lunes 21, pero en teams puso que para el lunes 28 jajaja

[1:24 PM] **+52 1 662 206 6192:**
> _+52 1 662 224 3927: Yo rezo en la iglesia de Gutú_
Álgebra nuestra, que estás en el espacio vectorial, linealizado sea tu producto, venga a nosotros tu base, hágase tu transformación lineal

[1:25 PM] **+52 1 662 224 3927:** En el kernel como en la ortogonalidad

[1:25 PM] **+52 1 662 224 3927:** Danos hoy nuestro eigenvalor de cada día

[1:26 PM] **+52 1 662 224 3927:** Perdona muestras combinaciones lineales

[1:26 PM] **+52 1 662 224 3927:** Como nosotros también perdonamos a los que nos calculan la norma

[1:27 PM] **+52 1 662 224 3927:** No nos dejes caer en el determinante

[1:27 PM] **+52 1 662 224 3927:** Y líbranos del Strang

[1:27 PM] **+52 1 662 206 6192:** [Sticker]

[1:27 PM] **+52 1 662 224 3927:** [GIF]

[1:40 PM] **+52 1 662 299 8290:** [Sticker]

[1:42 PM] **+52 1 662 224 3927:** [Sticker]

[2:01 PM] **+52 1 662 353 5181:**
> _+52 1 662 224 3927: Sticker_
[Sticker]

[2:31 PM] **+52 1 662 522 5777:** [Sticker]

[2:54 PM] **+52 1 662 460 2019:** [Sticker]

[3:01 PM] **+52 1 662 222 7221:** Oigan que nosotros no nos podemos registrar a la beca bienestar?

[3:05 PM] **+52 1 662 341 2644:** si pueden

[3:05 PM] **+52 1 662 341 2644:** pero es dificil quedar

[3:05 PM] **+52 1 662 341 2644:** ya que la unison esta catalogada como una universidad no de tanta importancia

[3:06 PM] **+52 1 662 341 2644:** y por eso tocan menos becas

[3:06 PM] **+52 1 662 222 7221:**
> _+52 1 662 341 2644: pero es dificil quedar_
Es que intente registrarme y ponia que el CCT de nuestra uni no era valida para el registro 👀

[3:06 PM] **+52 1 662 341 2644:** idk

[3:06 PM] **+52 1 662 341 2644:** xd

[3:06 PM] **+52 1 662 222 7221:** XD

[3:06 PM] **+52 1 662 341 2644:** pero para eso esta la beca estatal

[3:06 PM] **+52 1 662 165 5994:** Es que la unison es muy fifí para las becas del bienestar

[3:07 PM] **+52 1 662 341 2644:** ya casi abren la convocatoria de becas y credito sonora

[3:07 PM] **+52 1 662 341 2644:** esa es mas seguro quedar

[3:07 PM] **+52 1 662 450 9504:** Por lo que se, no podemos aplicar a la Jóvenes escribiendo el futuro

[3:07 PM] **+52 1 644 422 2240:**
> _+52 1 662 222 7221: Oigan que nosotros no nos podemos registrar a la beca bienestar?_
Nop, como no somos uni prioritaria este año no lo abrieron

[3:08 PM] **+52 1 644 422 2240:** Solo se abrió para los de continuidad

[3:08 PM] **+52 1 662 450 9504:** Podemos aplicar a gertrudis bocanegra, el 22

[3:09 PM] **+52 1 644 422 2240:**
> _+52 1 644 422 2240: Solo se abrió para los de continuidad_
https://www.instagram.com/p/DdHcNramKAB/

[3:12 PM] **+52 1 662 450 9504:** Continuidad? Osea que si no la tengo no puedo aplicar ahorita?

[3:16 PM] **+52 1 644 422 2240:**
> _+52 1 662 450 9504: Continuidad? Osea que si no la tengo no puedo aplicar ahorita?_
Así es, solo si tenías la beca previamente puedes meter la solicitud, sin contar la de preparatoria

[3:16 PM] **+52 1 662 450 9504:** A pues asi que chiste

---

## September 21, 2026

[8:33 AM] **+52 1 662 449 3477:** en historia 1 pm ya se agarró el tema 1

[10:49 AM] **+52 1 662 369 5386:**
> _+52 1 662 449 3477: en historia 1 pm ya se agarró el tema 1_
?

[11:21 AM] **+52 1 662 449 3477:** por si están interesados en entrar a algún curso del seminario de matemáticas aquí está la liga y info de los cursos 
https://semana.mat.uson.mx/registro/inscripcion/

[11:21 AM] **+52 1 662 449 3477:** [album message]

[11:21 AM] **+52 1 662 449 3477:** [Image]

[11:21 AM] **+52 1 662 449 3477:** [Image]

[11:21 AM] **+52 1 662 449 3477:** [Image]

[11:21 AM] **+52 1 662 449 3477:** [Image]

[11:21 AM] **+52 1 662 449 3477:** [Image]

[11:21 AM] **+52 1 662 449 3477:** [Image]

[11:38 AM] **+52 1 662 467 9029:** Ola, busco quien me pueda feriar $100

[11:38 AM] **+52 1 662 467 9029:** Porfa

[12:07 PM] **+52 1 662 296 3657:** Hola compañeros, mi novia es odontóloga y anda quitando brackets como parte de los tratamientos que está ofreciendo este semestre por si a alguien le interesa, es quitar brackets, limpieza y hacer retenedores por si a alguien le interesa

[12:07 PM] **+52 1 662 296 3657:** Barato, precio unison

[9:21 PM] **+52 1 662 299 4587:** https://www.facebook.com/share/1HbQf5nMbm/?mibextid=wwXIfr

---

## September 22, 2026

[10:26 AM] **+52 1 662 426 6490:** Holi si pueden responder está encuesta

[10:26 AM] **+52 1 662 426 6490:** [Sticker]

[10:26 AM] **+52 1 662 426 6490:** https://docs.google.com/forms/u/0/d/e/1FAIpQLScwVcF7Taataf6h6YwcK_dni4jmxY1JppcrF-MSmW3la4dXng/formResponse

[10:35 AM] **+52 1 662 449 3477:** [Forwarded] [Image]

[10:35 AM] **+52 1 662 449 3477:** [Forwarded] [Image]

[10:35 AM] **+52 1 662 449 3477:** [Forwarded] [Image]

[10:35 AM] **+52 1 662 449 3477:** actividades del seminario

[10:35 AM] **+52 1 662 449 3477:** por si están interesados

[10:36 AM] **+52 1 662 335 9011:** [Sticker]

[10:36 AM] **+52 1 662 448 8831:** Dan puntos Culturest por asistir?

[10:44 AM] **+52 1 662 637 5722:**
> _+52 1 662 449 3477: Image_
en qué aula son las pláticas?

[10:51 AM] **+52 1 662 449 3477:** serian en el auditorio otros son en aulas del 3k1

[10:52 AM] **+52 1 662 295 4218:** Si asistimos nos ponen falta en las materias de esas horas?

[12:03 PM] **+52 1 662 637 5722:** Oigan, y las camisetas?

[12:04 PM] **+52 1 662 449 3477:** ahh recibi menos de 20 formularios asi que la fecha se recorrera ya que se cotizaron 100

[12:05 PM] **+52 1 662 360 3771:**
> _+52 1 662 449 3477: ahh recibi menos de 20 formularios asi que la fecha se recorrera ya que se cotizaron 100_
Significa que todavía se puede enviar ?

[12:06 PM] **+52 1 662 449 3477:** siii

[12:11 PM] **+52 1 631 125 1255:**
> _+52 1 662 449 3477: ahh recibi menos de 20 formularios asi que la fecha se recorrera ya que se cotizaron 100_
pero se pueden mandar a hacer aunq sean esas 20 no?

[12:11 PM] **+52 1 631 125 1255:** nomás serian un poco más cara

[1:16 PM] **+52 1 662 449 3477:**
> _+52 1 662 295 4218: Si asistimos nos ponen falta en las materias de esas horas?_
sii se justificaría

[2:17 PM] **+52 1 662 467 9029:** Ola, alguien tiene bomba de aire?

[2:42 PM] **+52 1 662 449 3477:** amigos que se se hayan ido de verano de investigacion o de intercambio pueden poner su nombre completo por favor, igual si conocen a alguien tmb ponganlo @all

[2:42 PM] **+52 1 662 432 8446:** @~Dante Tostado

[2:42 PM] **+52 1 662 470 9935:** Hola

[2:43 PM] **+52 1 662 470 9935:**
> _+52 1 662 432 8446: @~Dante Tostado_
Como si no se supieran mi nombre we jajajaja

[2:43 PM] **+52 1 662 432 8446:** Que mamón we

[2:43 PM] **+52 1 662 470 9935:** JAJAJAJAJAJA

[2:43 PM] **+52 1 662 470 9935:** Esc

[2:44 PM] **+52 1 662 432 8446:** tráeme un pretzel que andas ahorita en el aeropuerto

[2:44 PM] **+52 1 662 470 9935:**
> _+52 1 662 449 3477: amigos que se se hayan ido de verano de investigacion o de intercambio pueden poner su nombre completo por favor, igual si conocen a alguien tmb ponganlo @all_
Dante Alejandro Tostado Cortes

[2:44 PM] **+52 1 662 470 9935:**
> _+52 1 662 432 8446: tráeme un pretzel que andas ahorita en el aeropuerto_
Ya despegué hermano

[2:44 PM] **+52 1 662 470 9935:** Te traigo un croissant ahorita que aterrice

[2:44 PM] **+52 1 662 432 8446:** mejor nada

[2:44 PM] **+52 1 662 432 8446:** [Sticker]

[2:45 PM] **+52 1 662 449 3477:**
> _+52 1 662 470 9935: Dante Alejandro Tostado Cortes_
saben quienes mas se fueron? de intercambio tmb

[2:45 PM] **+52 1 662 449 3477:** necesitamos esa info de que ya

[2:45 PM] **+52 1 662 470 9935:** Alch ni idea

[2:45 PM] **+52 1 662 360 3569:**
> _+52 1 662 449 3477: amigos que se se hayan ido de verano de investigacion o de intercambio pueden poner su nombre completo por favor, igual si conocen a alguien tmb ponganlo @all_
Denzel Omar Rivera Urias

[2:46 PM] **+52 1 662 360 3569:** Marco Antonio Tadeo Munro Flores

[2:46 PM] **+52 1 662 360 3569:** María Fernanda Hernandez García

[2:46 PM] **+52 1 644 422 2240:**
> _+52 1 662 449 3477: amigos que se se hayan ido de verano de investigacion o de intercambio pueden poner su nombre completo por favor, igual si conocen a alguien tmb ponganlo @all_
Angel Ricardo Valdez Ortiz

[2:46 PM] **+52 1 644 422 2240:** [Sticker]

[2:47 PM] **+52 1 637 123 2727:**
> _+52 1 662 449 3477: saben quienes mas se fueron? de intercambio tmb_
ni idea

[2:47 PM] **+52 1 662 470 9935:**
> _+52 1 662 449 3477: saben quienes mas se fueron? de intercambio tmb_
Ya me acordé

[2:47 PM] **+52 1 662 470 9935:** El @~Omar P

[2:48 PM] **+52 1 662 449 3477:**
> _+52 1 662 449 3477: amigos que se se hayan ido de verano de investigacion o de intercambio pueden poner su nombre completo por favor, igual si conocen a alguien tmb ponganlo @all_
de agosto 2025 a agosto 26

[2:50 PM] **+52 1 644 422 2240:**
> _+52 1 662 449 3477: amigos que se se hayan ido de verano de investigacion o de intercambio pueden poner su nombre completo por favor, igual si conocen a alguien tmb ponganlo @all_
David Armando Angulo Gil

[3:52 PM] **Michelle O:**
> _+52 1 662 449 3477: amigos que se se hayan ido de verano de investigacion o de intercambio pueden poner su nombre completo por favor, igual si conocen a alguien tmb ponganlo @all_
Michell Berenice Altamirano Ocejo

[4:46 PM] **+52 1 645 107 9121:** ya no darán la beca jóvenes escribiendo el futuro a los de nuevo ingreso?

[4:46 PM] **+52 1 645 107 9121:** [Sticker]

[4:48 PM] **+52 1 631 125 1255:** nope

[4:48 PM] **+52 1 631 125 1255:** unison dejo de ser una universidad susceptible

[4:54 PM] **+52 1 662 450 9504:** [Sticker]

[4:55 PM] **+52 1 662 699 4499:**
> _+52 1 631 125 1255: unison dejo de ser una universidad susceptible_
[Sticker]

[4:59 PM] **+52 1 644 404 0378:** Según aún nos podemos postular, pero no es de regla que la recibamos, porque al no tener prioridad como en escuelas rurales y en otras situaciones, se deja a criterio del programa según la información que le brinde la institución.

[5:05 PM] **+52 1 645 107 9121:** [Image]

[5:06 PM] **+52 1 631 125 1255:**
> _+52 1 631 125 1255: unison dejo de ser una universidad susceptible_
[Sticker]

[5:07 PM] **+52 1 631 125 1255:** q ya no esta unison como universidad susceptible, no jala, no more beca, mamo, no nanai, no biyuyo, no more jovenes construyendo el futuro, nos sacaron, no nos quieren

[5:07 PM] **+52 1 631 125 1255:** [Sticker]

[5:08 PM] **+52 1 662 699 4499:**
> _+52 1 631 125 1255: unison dejo de ser una universidad susceptible_
unison si pero sigue habiendo gente en extrema pobreza

[5:08 PM] **+52 1 645 107 9121:** como yo

[5:08 PM] **+52 1 631 125 1255:** nope, unison anteriormente estaba en el listado de universidades susceptibles, despues de las prioritarias nos podia tocar

[5:08 PM] **+52 1 631 125 1255:** ahora dejo de ser susceptible, ya no hay posibilidad que nos toque

[5:08 PM] **+52 1 662 699 4499:** sip por eso, es una tonteria

[5:09 PM] **+52 1 631 125 1255:** dando prioridad a las universidades indigenas, de regiones marginadas y de pobreza extrema

[5:09 PM] **+52 1 662 699 4499:** si es a la q van mas foraneos tmbn

[5:09 PM] **+52 1 631 125 1255:** de q, el chiste de vivimos 10 en una casa y comemos cada q se muere un primo es una realidad para ellos

[5:09 PM] **+52 1 645 107 9121:**
> _+52 1 662 699 4499: si es a la q van mas foraneos tmbn_
yo soy foráneo

[5:10 PM] **+52 1 631 125 1255:** esta la beca gertrudiz bocanegra

[5:10 PM] **+52 1 631 125 1255:** q es el mismo dinero

[5:10 PM] **+52 1 631 125 1255:** pero bimestral

[5:10 PM] **+52 1 662 699 4499:**
> _+52 1 631 125 1255: de q, el chiste de vivimos 10 en una casa y comemos cada q se muere un primo es una realidad para ellos_
es bueno q tengan la prioridad claro, pero seguimos siendo la uni mas grande de sonora, creo wue solo deberian de ser mas selectivos por q tmbn hay casos especiales

[5:10 PM] **+52 1 645 107 9121:**
> _+52 1 631 125 1255: esta la beca gertrudiz bocanegra_
me salvaste

[5:10 PM] **+52 1 631 125 1255:** also, unison tiene varias becas para apoyar a foraneos

[5:10 PM] **+52 1 662 699 4499:**
> _+52 1 631 125 1255: q es el mismo dinero_
es menos q no?

[5:10 PM] **+52 1 631 125 1255:** nope

[5:10 PM] **+52 1 631 125 1255:** segun yo, es lo mismo

[5:11 PM] **+52 1 631 125 1255:**
> _+52 1 631 125 1255: also, unison tiene varias becas para apoyar a foraneos_
una de esas esta en el comedor, creo que es una comida al dia gratis

[5:11 PM] **+52 1 631 125 1255:** o algo asi

[5:11 PM] **+52 1 662 699 4499:**
> _+52 1 631 125 1255: una de esas esta en el comedor, creo que es una comida al dia gratis_
sip esa me la daban

[5:11 PM] **+52 1 645 107 9121:**
> _+52 1 631 125 1255: una de esas esta en el comedor, creo que es una comida al dia gratis_
aún hay convocatoria?

[5:11 PM] **+52 1 662 699 4499:** no nomas es para foraneos

[5:11 PM] **+52 1 631 125 1255:** tambien hay una para transporte, y una de deserción escolar por económica

[5:11 PM] **+52 1 631 125 1255:**
> _+52 1 645 107 9121: aún hay convocatoria?_
creo que ya cerro

[5:11 PM] **+52 1 645 107 9121:** [Sticker]

[5:14 PM] **+52 1 662 100 1205:** y si pongo que no me alcanza pal gta 6 me la dan?

[5:14 PM] **+52 1 662 100 1205:** [Sticker]

[5:15 PM] **+52 1 645 107 9121:**
> _+52 1 662 100 1205: y si pongo que no me alcanza pal gta 6 me la dan?_
vende tu sayo device

[5:15 PM] **+52 1 645 107 9121:** se me olvidó dártelo

[5:15 PM] **+52 1 645 107 9121:** mañana te lo regreso

[5:17 PM] **+52 1 662 100 1205:** simonki we ntp

[5:39 PM] **You:** Hola busco equipo de contexto regional 😁

[5:42 PM] **+52 1 662 339 4302:** Yo también busco equipo

[5:42 PM] **+52 1 662 339 4302:** [Sticker]

[5:42 PM] **+52 1 662 426 6490:** [Sticker]

[5:42 PM] **+52 1 662 426 6490:** yo

[5:43 PM] **+52 1 662 452 0190:** Yo tampoco tengo

[5:45 PM] **+52 1 662 367 8720:**
> _+52 1 662 449 3477: en historia 1 pm ya se agarró el tema 1_
Mi equipo quisiera los artículos del 9 al 16, asumo que tema 1 es del 1 al 8

[5:46 PM] **+52 1 662 449 3477:** es correcto compañera gracias por la aclaración

[5:47 PM] **+52 1 662 367 8720:** [Sticker]

[5:51 PM] **+52 1 662 339 4302:** _This message was deleted_

[5:51 PM] **+52 1 662 339 4302:** Los que no tengan equipo métase plis

[5:51 PM] **+52 1 662 339 4302:** Solo los de contexto de 1 a 2

[5:51 PM] **+52 1 662 339 4302:** [Sticker]

[5:56 PM] **+52 1 662 164 8356:** _This message was deleted_

[7:37 PM] **+52 1 662 449 3477:** [Image] por si estan ineresados todavia hay cupo en esos cursos

[7:37 PM] **+52 1 662 449 3477:** justifican la falta

[7:42 PM] **+52 1 662 326 0064:** A alguien ya le llego correo de confirmacion del registro?

[7:42 PM] **+52 1 662 449 3477:** llegan a spam!!

[7:42 PM] **+52 1 662 326 0064:** me registre hoy en la mañana

[7:42 PM] **+52 1 662 326 0064:** No tenog nada en spam ):

[7:42 PM] **+52 1 662 360 3569:** si te registraste hoy es posible que te hayan rechazado

[7:42 PM] **+52 1 662 326 0064:** rip

[7:43 PM] **+52 1 662 449 3477:** igual puedes ir mañana a ver que show

[7:43 PM] **+52 1 662 449 3477:** normalmenre hay uno que otro que falta

[7:43 PM] **+52 1 662 326 0064:** sii porque queria entrar al de python

[7:43 PM] **+52 1 662 326 0064:** habia 22 cupos cuando me registre ):

[7:44 PM] **+52 1 662 360 3569:**
> _+52 1 662 326 0064: habia 22 cupos cuando me registre ):_
no lo habían actualizado

[7:44 PM] **+52 1 662 326 0064:** fak

[7:44 PM] **+52 1 662 360 3569:** la gente mete solicitud de registro, no es un registro como tal

[7:44 PM] **+52 1 662 326 0064:** con razon

[7:44 PM] **+52 1 662 449 3477:**
> _+52 1 662 326 0064: sii porque queria entrar al de python_
habia como 42 registrados ahi ahorita se les dio acceso de seguro no entraste pero igual puedes checar mañana

[7:45 PM] **+52 1 662 449 3477:** los que si alcanzaron normalmente pedro usa linux por si no le mueven le pueden dar una checadita antes igual no es seguro que use linux pero pues por cualquier cosa

[7:49 PM] **+52 1 662 449 3477:**
> _+52 1 662 449 3477: Image: por si estan ineresados todavia hay cupo en esos cursos_
https://semana.mat.uson.mx/registro

[8:01 PM] **+52 1 662 501 3191:**
> _+52 1 662 449 3477: justifican la falta_
Tú no más por eso te vas a meter

[8:02 PM] **+52 1 662 449 3477:** andas bien aca mijito ni parece que eres tu el que deja la compu abierta toda la clase y se pira

[8:03 PM] **+52 1 662 449 3477:** [Sticker]

[8:03 PM] **+52 1 662 341 2644:** pelea

[8:04 PM] **+52 1 662 501 3191:**
> _+52 1 662 449 3477: andas bien aca mijito ni parece que eres tu el que deja la compu abierta toda la clase y se pira_
Al menos aprobé estadística

[8:04 PM] **+52 1 662 501 3191:** [Sticker]

[8:05 PM] **+52 1 662 335 9011:** No pelien 🥀

[8:05 PM] **+52 1 662 501 3191:** No es cierto Dania se te quiere mucho compañerita, un abrazo 🫂

[8:05 PM] **+52 1 662 449 3477:** a ver quien te hace eventos ogt

[8:06 PM] **+52 1 662 501 3191:**
> _+52 1 662 449 3477: a ver quien te hace eventos ogt_
Por eso se te quiere mucho compañerita, muchas gracias por mantener viva la comunidad LCCiana 🫂

[8:08 PM] **+52 1 662 449 3477:** [Sticker]

[8:08 PM] **+52 1 662 501 3191:**
> _+52 1 662 449 3477: Sticker_
[Sticker]

---

## September 23, 2026

[9:01 AM] **+52 1 662 469 3513:** [Image] lenguajes 8-9am

[9:43 AM] **Remil:** Oigan, dónde está la opción de darse de baja en el nuevo portal?

[9:43 AM] **+52 1 662 139 3528:**
> _Remil: Oigan, dónde está la opción de darse de baja en el nuevo portal?_
Mmmmmm

[9:44 AM] **+52 1 662 139 3528:** Ahí te digo Perame

[9:44 AM] **+52 1 662 448 8831:** eh

[9:44 AM] **+52 1 662 448 8831:** te metes

[9:44 AM] **+52 1 662 139 3528:**
> _+52 1 662 448 8831: te metes_
En reinscripcines

[9:44 AM] **+52 1 662 361 1416:**
> _Remil: Oigan, dónde está la opción de darse de baja en el nuevo portal?_
Reinscripciones

[9:44 AM] **+52 1 662 139 3528:**
> _+52 1 662 139 3528: En reinscripcines_
Y de ahí vaz a bajas voluntarias

[9:44 AM] **Remil:**
> _+52 1 662 139 3528: Y de ahí vaz a bajas voluntarias_
Gracias

[9:44 AM] **+52 1 662 699 4499:**
> _Remil: Oigan, dónde está la opción de darse de baja en el nuevo portal?_
hay w darnos de baja masivamente

[9:45 AM] **+52 1 662 699 4499:** [Sticker]

[9:45 AM] **+52 1 662 139 3528:**
> _Remil: Gracias_
De naadaa

[10:01 AM] **+52 1 662 637 5722:**
> _+52 1 662 699 4499: hay w darnos de baja masivamente_
de la vida para mayor drama

[10:53 AM] **+52 1 662 164 8356:** Hay evento?

[10:55 AM] **+52 1 662 139 3528:**
> _+52 1 662 164 8356: Hay evento?_
Siempre

[10:55 AM] **+52 1 637 117 9366:** Buen día, me comento el profe Waissman de que si en lugar de la clase, mejor asistir a la platica CP1 - Los circulos de la vida de Pedro Miramontes,

[10:56 AM] **+52 1 637 117 9366:** Es a las 13:00

[10:56 AM] **+52 1 637 117 9366:** Reconocimiento de patrones

[10:58 AM] **+52 1 662 299 5544:** [Sticker]

[11:20 AM] **+52 1 662 164 8356:** Hay clases de 13:00 en todo LCC?

[12:53 PM] **+52 1 662 420 8102:** No hay contexto regional de 1 a 2 pm

[1:05 PM] **+52 1 662 449 3477:** [Image] caja culturest para la prenaria del auditorio

[1:56 PM] **+52 1 645 107 9121:** obligatorio todos cambiense a Linux

[2:05 PM] **+52 1 662 326 0064:** Para mañana si los cachamos sin Linux los vamos a secuestrar y cambiaremos sus laps a linux. Si se resisten los sacamos de la carrera

[2:05 PM] **+52 1 662 100 1205:** y si no tengo lap le pongo linux al cel?

[2:05 PM] **+52 1 662 100 1205:** [Sticker]

[2:05 PM] **+52 1 662 399 2340:**
> _+52 1 662 326 0064: Para mañana si los cachamos sin Linux los vamos a secuestrar y cambiaremos sus laps a linux. Si se resisten los sacamos de la carrera_
No usen Linux fuera de la uni gente yo sé lo que les digo

[2:08 PM] **+52 1 631 125 1255:** llega la policia linuxera a golpearte machin por usar linux fuera d la uni

[2:08 PM] **+52 1 631 125 1255:** pq solo lo puedes usar dentro de la uni

[2:08 PM] **+52 1 631 125 1255:** pq asi dice en los términos d linux

[2:08 PM] **+52 1 55 5473 2571:**
> _+52 1 631 125 1255: pq solo lo puedes usar dentro de la uni_
si we, ya me pasó dos veces

[2:28 PM] **+52 1 662 350 4258:** [Document] bit049_13.pdf

[2:35 PM] **+52 1 662 138 7071:** Saben si habrá cálculo?

[2:35 PM] **+52 1 662 138 7071:** Hoy a las 3

[2:47 PM] **+52 1 662 299 5544:**
> _+52 1 662 138 7071: Saben si habrá cálculo?_
Segun yo si

[2:49 PM] **+52 1 662 139 3528:**
> _+52 1 662 138 7071: Saben si habrá cálculo?_
Si

[3:25 PM] **+52 1 662 385 5717:** [Image] Ya se puede usar el baño

[3:25 PM] **+52 1 662 139 3528:**
> _+52 1 662 385 5717: Image: Ya se puede usar el baño_
Hace rato

[3:25 PM] **+52 1 662 385 5717:** Q soberbio aram

[3:43 PM] **+52 1 662 446 0922:**
> _+52 1 662 139 3528: Hace rato_
Lo que es guardar la información para uno mismo

[3:43 PM] **+52 1 662 446 0922:** [Sticker]

[4:17 PM] **+52 1 662 365 9837:** Pibes

[4:17 PM] **+52 1 662 365 9837:** Cuál es el cct

[4:17 PM] **+52 1 662 365 9837:** [Sticker]

[4:19 PM] **+52 1 662 948 4424:**
> _+52 1 662 365 9837: Cuál es el cct_
La beca bienestar no aplica para la unison cawn

[4:19 PM] **+52 1 662 365 9837:** [Sticker]

[4:19 PM] **+52 1 662 365 9837:**
> _+52 1 662 948 4424: La beca bienestar no aplica para la unison cawn_
Esa no es pije

[4:20 PM] **+52 1 662 948 4424:**
> _+52 1 662 365 9837: Esa no es pije_
Cuál pibe

[4:20 PM] **+52 1 662 948 4424:** [Sticker]

[4:20 PM] **+52 1 662 365 9837:** Que le importa

[4:20 PM] **+52 1 662 365 9837:** No la neta no se cual es

[4:20 PM] **+52 1 662 365 9837:** Mi mamá nomás me dijo que lo hiciera

[4:20 PM] **+52 1 662 365 9837:** [Sticker]

[4:53 PM] **+52 1 662 224 3927:**
> _+52 1 662 469 3513: Image: lenguajes 8-9am_
[Image] En la clase de 10 a 11 hicimos este diagrama matando a unos cuantos delfines

[5:20 PM] **+52 1 662 344 2739:**
> _+52 1 662 224 3927: Image: En la clase de 10 a 11 hicimos este diagrama matando a unos cuantos delfines_
Yo tmb quiero

[5:38 PM] **+52 1 631 125 1255:**
> _+52 1 662 365 9837: Cuál es el cct_
Centro de CompuTo

[5:39 PM] **+52 1 631 125 1255:**
> _+52 1 662 948 4424: Cuál pibe_
beatriz bocanegra o algo asi

[5:39 PM] **+52 1 631 125 1255:** gertrudiz bocanegra(?

[5:39 PM] **+52 1 631 125 1255:** sepa

[5:39 PM] **+52 1 631 125 1255:** "nombre de señora" + Bocanegra

[5:40 PM] **+52 1 662 350 5885:**
> _+52 1 631 125 1255: gertrudiz bocanegra(?_
Ese es jeje

[5:40 PM] **+52 1 662 350 5885:** la Gertrudis

[5:40 PM] **+52 1 662 350 5885:** [Sticker]

[6:10 PM] **+52 1 662 457 3406:** @~Dania Vega cómo se llama el curso de las 11:30 ??

[6:10 PM] **+52 1 662 457 3406:** [Sticker]

[6:57 PM] **+52 1 662 139 3528:** Último día para darse de baja

[6:57 PM] **+52 1 662 327 9060:**
> _+52 1 662 139 3528: Último día para darse de baja_
@~Ángel

[6:58 PM] **+52 1 662 142 7436:** Mande

[6:58 PM] **+52 1 662 142 7436:**
> _+52 1 662 327 9060: @~Ángel_
[Sticker]

[6:58 PM] **+52 1 662 142 7436:** Extiendanlo no alcance 🙏🙏🙏

[6:58 PM] **+52 1 662 327 9060:** [Sticker]

[7:26 PM] **+52 1 662 449 3477:**
> _+52 1 662 457 3406: @~Dania Vega cómo se llama el curso de las 11:30 ??_
ni idea hermanito

[7:26 PM] **+52 1 662 449 3477:**
> _+52 1 662 449 3477: Image_
aquí está toda la info

[7:54 PM] **+52 1 645 107 9121:**
> _+52 1 662 399 2340: No usen Linux fuera de la uni gente yo sé lo que les digo_
en el centro de computo debería de haber una regla que dice

[7:54 PM] **+52 1 645 107 9121:** "Solamente se puede usar Linux"

[7:56 PM] **+52 1 662 467 9029:** "...afuera"

[8:12 PM] **+52 1 662 399 2340:**
> _+52 1 645 107 9121: en el centro de computo debería de haber una regla que dice_
Yo instalaba Linux en el centro de cómputo a las 6 pm todos los días

[8:12 PM] **+52 1 662 399 2340:** Después sali a tocar pasto y me aleje de esos caminos

[9:06 PM] **+52 1 662 295 0244:** Oigan

[9:06 PM] **+52 1 662 295 0244:** Si repruebo ingles

[9:06 PM] **+52 1 662 295 0244:** Soy irregular o no

[9:06 PM] **+52 1 662 432 8446:** No

[9:06 PM] **+52 1 662 295 0244:** Alguien que sepa

[9:07 PM] **+52 1 662 432 8446:** Puedes reprobar idiomas y no te afectará la carrera

[9:07 PM] **+52 1 662 139 3528:** No

[9:07 PM] **+52 1 662 139 3528:** Pero si quieres informa directa pregúntale al @~Angel

[9:07 PM] **+52 1 662 295 0244:** Algo bien estaba pensando darla de baja por eso

[9:07 PM] **+52 1 662 295 0244:** Pero si no afecta entonces

[9:07 PM] **+52 1 662 139 3528:** [Sticker]

[9:07 PM] **+52 1 662 295 0244:** Algo bien

[9:18 PM] **+52 1 622 181 8371:** _This message was deleted_

---

## September 24, 2026

[7:39 AM] **+52 1 662 501 3191:**
> _+52 1 662 139 3528: Pero si quieres informa directa pregúntale al @~Angel_
Tal vez no perjudique la carrera pero Bro con esos 500 pesos que gasté en idiomas compraba un mes de Claude 🥀

[7:51 AM] **+52 1 644 422 2240:**
> _+52 1 662 501 3191: Tal vez no perjudique la carrera pero Bro con esos 500 pesos que gasté en idiomas compraba un mes de Claude 🥀_
[Sticker]

[9:21 AM] **+52 1 662 449 3477:** [Image] @~Javier Miranda a ver qué tal están

[9:21 AM] **+52 1 662 449 3477:** [Sticker]

[9:21 AM] **+52 1 662 449 3477:** [unknown message]

[9:23 AM] **+52 1 662 341 2644:**
> _+52 1 662 449 3477: Image: @~Javier Miranda a ver qué tal están_
y porque no me dijiste

[9:23 AM] **+52 1 662 341 2644:** yo también quiero unos

[9:23 AM] **+52 1 662 449 3477:** a mi me los trajeron

[9:23 AM] **+52 1 662 449 3477:** de a ver sabido que eran de ahí digo que no

[9:23 AM] **+52 1 662 449 3477:** [Sticker]

[9:24 AM] **+52 1 662 341 2644:**
> _+52 1 662 449 3477: de a ver sabido que eran de ahí digo que no_
pues dámelos

[9:24 AM] **+52 1 662 341 2644:** [Sticker]

[9:30 AM] **+52 1 662 467 8870:**
> _+52 1 662 449 3477: Image: @~Javier Miranda a ver qué tal están_
Se viene la funa maestra

[9:30 AM] **+52 1 662 467 8870:** Sigan viendo

[9:31 AM] **+52 1 662 128 2906:**
> _+52 1 662 467 8870: Se viene la funa maestra_
La intoxicada maestra diría yo

[9:31 AM] **+52 1 662 128 2906:** Hola Gaspar :DDD

[9:31 AM] **+52 1 662 467 8870:**
> _+52 1 662 128 2906: La intoxicada maestra diría yo_
Chorro 2: trailer oficial

[9:31 AM] **+52 1 662 412 0821:**
> _+52 1 662 449 3477: Image: @~Javier Miranda a ver qué tal están_
La funa fue tan buena que habra segunda parte

[9:31 AM] **+52 1 662 128 2906:**
> _+52 1 662 467 8870: Chorro 2: trailer oficial_
Más marrón que nunca

[9:32 AM] **+52 1 662 467 8870:**
> _+52 1 662 128 2906: Hola Gaspar :DDD_
Ola luis mario

[9:32 AM] **+52 1 662 467 8870:** [Sticker]

[9:32 AM] **+52 1 662 128 2906:**
> _+52 1 662 467 8870: Sticker_
[Sticker]

[9:32 AM] **+52 1 662 432 8446:** Hola Gaspar

[9:37 AM] **+52 1 662 467 8870:** Ola George moon

[9:51 AM] **+52 1 662 449 3477:** necesito a alguien del vai les traje cosas

[9:53 AM] **+52 1 662 432 8446:** Yo

[10:22 AM] **+52 1 662 449 3477:** si están interesados en entrar a un curso pero no se inscribieron ustedes igualmente vayan

[10:22 AM] __+52 1 662 281 6021 joined via invite link__

[11:17 AM] **+52 1 662 342 4670:** Hola, saben si habrá clases con Donald???

[11:53 AM] **+52 1 662 295 0244:** Dijo que si van a las platicas y cursos

[11:53 AM] **+52 1 662 295 0244:** No

[11:54 AM] **+52 1 662 295 0244:** si estan la mayoria si

[12:03 PM] **+52 1 662 164 8356:** habra contexto regional de 1 a 2?

[12:13 PM] **+52 1 662 467 9029:** Oigan los que iban a ayudar con las mamparas

[12:13 PM] **+52 1 662 467 9029:** Ya las encontré

[12:14 PM] **+52 1 662 467 9029:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAUEBgECAwcI/8QAOxAAAgEDAwIDBQUFCAMAAAAAAQIDAAQRBRIhEzEGQVEUIjJhcQcjgZGxFUJSwfAlYnKCkqHR4TNDsv/EABoBAAIDAQEAAAAAAAAAAAAAAAECAAMEBQb/xAAsEQABAwMBBwMEAwAAAAAAAAABAAIRAwQhMQUSE0FRYdEUQoEicZGhBiSx/9oADAMBAAIRAxEAPwD6Ga2jQZlk/QVgG0Bxu5+ppfI7SOWc5JrWqzVK5rrwz9ITpI4iAURCPUAUXAzA/wAhn8qV2s7Qv/dPcU3YB0I8iKZrpWyhWFVvdaWxzAnyGPyrdiFBJ7Co1nKBCFOcg+QJ+dSj2OO9MRlXA4XPqjyVz/lNab265xG3K+ZHkf8Aut/vT5Iv4k1oyv1kzJgkH4R9PXNEKFbOJHRl2oARj4s/yrWxbMH0P/f8636QPxO5/wA2P0rhaxoXlVlB2njI+v8AxUxCHNSnuABh5Rj0LVzmnBjwrseR2z2zW4Cp2Cr/ALVq8kRUqzrg8EZoBErqrFVAViAO3NFRthblUcj1aQg/lRUhSUpooorMuAinNq2+3jPypNTTTWzb49DTs1WyydDyFiEsk8saAHnOCcY/rIqq+K/HtnoVw1pEvtl6vxxxnCx/JmPY/IA/PFPPEV1Jp+n6jeQ/+SG1kmX6qhI/+a+b7ydoonlcmSQnJZjksxPJNU3lw6lAZqV7DYey6d6XVKx+lvLqvWdO+1OCW4C6pp89vCTjqQzdTb9RtU4+mT8q9Bt7u0uIYLmzkWWN8Orpk7lPGc18t2F480pSQDtkEV7H9jF5JLb39lId0NvIkkYPO0uHyB8spn6k1Va3T3P4dRbNsbHoUbf1NtiNQc9l6Z1GPaJz9cCuEahrqQOvlnH5VLqLMoN4m4Aqw5z+P/VdILypXbZCvdYx+AoEsQ+FlP8Ah5rISNBkKqj6Yo6sY/8AYn50EVjrL5Bz9ENFHWT1P4A0VI7KSktFbSI0blWGCK43EgigkkPZVJrNC4JEarsBGkD3F1MlvaocNK/mfQDzNRbfxVokEhjV74gnmQxrt/LOaV+Kpo38U2GmXRAsbVokkBOAd2C7E/MHvU+w8J2R1W1tb2Mb+gZpESUncAkS888DeZDx+lcqpd3D6pZbAQ0wZ6+F7Oz2VZ21FtS6kucJx08pvqC2uqaflZVuLG4VoXeM+RGCD6HBNfPniDRrjR9Rn03UEy6dmxgSJ5OPkf8AY5HlXqfgC4c6rJp5OYbyNlI9GUFg31GDUj7QtMPiHR9NS0tBJqbpJNDIz7SAiqWTAB3bs8DI5AOasbXF/bCtEOBj5XVsnnZN6bdxljxP+5+MyvEIbeK23Mgx6knyr2/7MdCuNI0R7m6j6d1eSK7K3BRBwoI9feYn648qo32WaRFqviOKa7iLWsUckkR8mlTYefXAdT9SK9oMqi+fT44yCLdbgOX45crjGPlnvV1ixoPEcc6Kz+RXpd/UpDAyfC7BpN+2RwhPbA7/AJ1wuwUliJdj35OOO1Zv7i1iniiur23gZwCscjcnJwCfQZ4BPnULUNSgttSWxdrR3R0jYzXWx1Z8HldvbBGMnkmui6tTZlxXlG0KlTDQmhWJGG/LN35yxrYSxgd8fhXA3Nnb6ibR7uFbhyqiNny2T2B9CfIVE1rW7PT/ALgS2814Z4Ymg6nK73APbzAOcUH1qbQS46JmUajyA0apl1l9H/0N/wAUVwvdV02zuXguL+2jlU8oWyV+uO1FA1qYMFw/KgoVSJDT+CpEsUco+8UHHnS+8sbeSGSMzBQykYLCuYRGPEe4/JMmuqwSfuQP/px+tXcMc1kexj9WqpeK7N9RjTVbX750UQ3ipyY3UY3H5EedJ01CJdcsL0rJ0oPZ9wwNx6aoGxz/AHTir/JY38F0t7p8YjuVGGV2G2Vf4Wx+vlXb9oaPu3nSP7R79L2T3t3+PGMZ881xLvY3FqmrSdEkE45r0VntrhUhSrNmAQM8lUfCtnLp0b6rOjJI6mKzQ8GR2GCwH8IGeae3tl1v2MX017+3tFlSSINGCCVUKcOyjHBphDpd5c3RvdRmjNywwqhSViX+Ec/7+dTBpzfvTD8Ex/Ot9CwpUKHAB7k91guL+rXuOOR2A7JLpukwabc2EumaX+z7SOO7MkTyISJJDFg+67d9p7HjGOOKkSvdx60LyOxmuYpLMQkwyRZVhIzch3XyIpqNOTzllP5f8VsNPh8zIf8AMR+lXcBoEAnWeXSFSbh7nbzhOI59Z6yq3qOnXVxf38jQag1vqMEaNFbywDbhdpSTcTjuTlSRyfxkahptzJaeI4oQHa8aIwZkXMgWKJSc545Vu+KfCxtx+4T9XY/zqPdQRCWKKKNVdjksByB/Wfyqv0jDOTmf3Pkp/WVBGBiP1HgKv67aX9xe3SJDO6PeQzxmKWJIDGrRklgSGL+6e/oPKi7sr+S3uLGCzaYPqgvRcpInTaMzB+ctncBxjH7vFW1IIk+CJB9FFdaU2bSSZOft4TNvHgAQMffX8qv6e93pL30J0u7u1lu5bhJ7fpkOrtuGdzA5Gdv4CirBRVraRaIa4x8eFU6qHGXNE/PlV2/1tY9XkjsdL1PUpLZhHO1qiCONiM7dzsu5sMDgZ7060+8h1Cxgu7Vi0EyB0JGDj0IPY/KlzWaWd9qk6NeQw3YUsAybOqVwZIzyysAoznjODjvTHT7ODT7GC0tFKwQoEQFixx8yeSfnWgxCziZUisYGc4Ga5e02/tos+vF7YYut0N3v7M43Y9M8ZrvtYDJBpUyxRSrVdbi069htDaXt1PJC9xttow+EQqGPLAnll4GTzXS11zSruW1it9RtnmuohPDFvw7oQTu2nnGFP5UYKEhMaKUeItZ/ZekSXVpAL66MkcMFur7eq7sFAz5dyfoKS674wktoIbrS0hltJtO9uQvGWbieJGBAI7LIePX6YohpKhcArjUKz++uJZz2+Ff6/rvSHU/GlhbQtFcW9xa3jT+zG2upIoSpKb9xkLFApXtgk5OMUr1HxheHRNRl8P6eqJaafHfNc3UoDKH3HaIwpyfcYdwKIaUpcFf652254IycscDJqtX3iS8ttQuF9ktTaWdxa2tziVuoXn2e9HxgqDIO/Jwe1QfE/SOvtaarNLHbLp3UtEF4bVXm6jCRg+QCyr0yM5xk0A1EuV3oqp2/iywTStLmvdUtLGS6tI5xFeTqJCCMbjwM5wecDnNFTdKm8FH8d6pqWnR2Zt7y4tDMpB6dtGYlYHO6SZwwQY4xgn5Ux8Jx3raNmTxFFrU0km83EZQogwAEBUc9u/GfQVC+0i5htLPT5bnd0+pICG1KSzjYBN20lD7zHbhc8ZJ55qT9n9tpKaTNeaNZR263MzK8scjyCcIxCuGc5IwT+Oe/em9qX3JPe6frjeJ7rxBaWSN7JdJCiyFhNNbIuyRUXGCrF3Yc8kA1O0bRr7StT1M3EXVt7aIWmm/fKGliaQyMMnttyic99lXGoT/fagq/uxjP4/1j8qG9KO7CV6xpmoR61peoaNHaTvbRXEEi3UxiGJDGQcqpzgoeMedR/D/hebRSGhuoJJBpi2gZ0bHVEkkm4gYOzMh4znFWmgc9qG8YhHdCTax4fg1Y6ct1KywWsxnkihLp1X2FVIYMGUAsTjnNLm8Dac1vJbe03a2pS4iiRGGYkmZGYBjknDIWGfNj3q1EYPNYOcccmhvFHdCrg8PWMlzKskt7NdGYXBvTPsmVwmwBWQAAbTtxjnJzk01TR9PRZwbcye0Wy2kxmkaQyxLuwrbic/G3J55qPDqWn2mjy6vPqFqbAnJukkDx/Ft+IZB944pz02zjFEkoABLI9E0pJraYadame2RUhldNzoF+H3jzxk4J9anTRRzoFnijlUHcBIoYA+vNc57u1t4xJPdW8UZYIGeVVBYjIGSe+PKl8GvQSajPaPH0ejcy2zySSooykSS7gO5GH/DBzQyUcBOd7etFJ7fxJolwrMmq2i4OMSv0z2BBAbBIIIIPY0VIKkhYurV9b020Rrqa0czburbrGW+BuBvVgM/TNcPCJnRNZtbi7uLsWmoNDHJcMGfZ0omwcADux7Ciin9qX3J9ULTveMzn4i3P6/zoopOSY6qbSbxbeTWXhjW7i3bbNDZTSIw7hghwaKKg1UOirGjarfadpmlW0Nwzwwand6fiUBi8UccrJuJGcgovIxx3zVi8O3tzd6NoUtzMZZZ7SCWRyACzMgJJwPU0UVY4KsFeRxMR4OuNIHFi0Ul30/4X9mujgeg3Qo2PXPrVzKCa7m1WQsdRg12xtY59x3JCy24aMf3T1HyPPdmiinOqUJZpGi2lxbeFLJQYLebTb55VjVffO6MEnIPJAAJ74HesyEwa/thOxkvIwr92G7SiCcnueAefPvmiigovG/FGpS6ld2s8qJHJ7LGrFCx3nHxMWJJY+ZzRRRWluiqOq//Z: Location: 29.0805356, -110.9629492 — https://maps.google.com/?q=29.0805356,-110.9629492

[12:41 PM] **+52 1 662 432 8446:** **Poll: ¿Les interesa participar en un concurso de programación competitiva en equipo sobre ciencias de datos y ciberseguridad?**
- Si
- No
- Quizás otro semestre
- Nose

[2:50 PM] **+52 1 662 467 9029:** Prestenme $50 porfa

[2:56 PM] **+52 1 662 365 9837:**
> _+52 1 662 467 9029: Prestenme $50 porfa_
[Sticker]
